---
layout: post
title: http1.1-range
draft: false
date: 2018-10-06 11:11:34
categories: 计算机网络
tags: http1.1
permalink:
description:
cover_img:
toc-disable:
comments:
---
# 断点续传概念
断点续传的理解可以分为两部分：一部分是断点，一部分是续传。
- 断点的由来是在下载过程中，将一个下载文件分成了多个部分，同时进行多个部分一起的下载，当某个时间点，任务被暂停了，此时下载暂停的位置就是断点了。
- 续传就更好理解些了，就是当一个未完成的下载任务再次开始时，会从上次的断点继续传送。

# HTTP/1.1和断点续传
HTTP1.1的描述中有几个东西可以支持断点续传

## If-Range
If-Range是另一个起条件判断的请求头. If-Range头用来避免客户端在下载了某资源(比如图片)的一部分后，下次重新下载又从头开始下载。(这对于某些慢速网络来说，也许一辈子也下载不了某完整文件)。

If-Range的使用格式为:If-Range: Etag|Http-Date
即If-Range中的内容可以为最初收到的ETag头或者是Last-Modfied中的最后修改时候。服务端在收到续传请求时，通过If-Range中的内容进行校验，校验一致时返回206的续传回应，不一致时服务端则返回200回应，回应的内容为新的文件的全部数据。
```
If-Range: "df6b0-b4a-3be1b5e1"
If-Range: Tue, 8 Jul 2008 05:05:56 GMT
```
逻辑上来讲，上面2种方式分别和If-Match,If-Unmodified-Since的工作原理一样，他们的值正是服务器返回的Etag和Last-Modified值。

## Range
请求资源的部分内容（不包括响应头的大小），单位是byte，即字节. 
```
Range : bytes=50-          意思是从第50个字节开始到最后一个字节
Range : bytes=-70          意思是最后的70个字节
Range : bytes=50-100    意思是从第50字节到100字节 
```
**Range 请求的一些注意事项:**
- bytes=start-end，即是包含请求头的start及end字节的，所以，下一个请求，应该是上一个请求的end+1 - nextEnd.
- 不支持 Range 请求的 server 要用“Accept-Ranges: none”对 client 表明心意且返回整个资源以及响应状态码为 200 OK；server 也可以主动告诉 client “Accept-Ranges: bytes”，且返回 206 Partial Content 的状态码和断点后的资源。

## Accept-ranges
Accept-ranges是一个响应头，服务器发送这个头来告诉客户端它支持Range(范围)请求.
```
Accept-Ranges: bytes
```

## Content-Range
这是一个响应头，说明了服务器提供的内容的字节范围和整个资源的长度。例如:
```
Content-Range: bytes 0-10/3103
Content-Length: 11 //表示这次服务器响应了11个字节的数据（0-10）
```
这个表示，服务器响应了前(0-10)个字节的数据，该资源一共有(3103)个字节大小。

# 工作方式
下面的代码显示了IIS发送给客户端的用于响应一个初始下载请求的一些头信息，他向客户端传递了被请求的文档的周详信息。
```
HTTP/1.1 200 OK
Connection: close
Date: Tue, 19 Oct 2004 15:11:23 GMT
Accept-Ranges: bytes
Last-Modified: Sun, 26 Sep 2004 15:52:45 GMT
ETag: "47febb2cfd76c41:2062"
Cache-Control: private
Content-Type: application/x-zip-compressed
Content-Length: 2844011
```

在接收这些头信息之后，假如下载被中断了，IE浏览器在后来的下载请求中会把Etag值和Range头信息发送回服务器。下面的代码显示了尝试恢复被中断下载时IE发送给服务器的一些头信息。
```
GET http://192.168.100.100/download.zip HTTP/1.0
Range: bytes=822603-
Unless-Modified-Since: Sun, 26 Sep 2004 15:52:45 GMT
If-Range: "47febb2cfd76c41:2062"
```
请注意，If-Range 元素包含服务器可用于标识要重新发送的文件的原始 ETag 值。您还会看到 Unless-Modified-Since 元素包含了最初下载的开始日期和时间。服务器将利用此信息来确定自最初下载开始后该文件是否已被修改过。如果已被修改，则服务器将从头开始重新下载。这些头信息表明IE缓存了IIS提供的实体标签，并在If-Range头信息中把他发送回服务器了，这是确保下载从准确相同的文档恢复的一种途径。不幸的是，并非任何的浏览器的工作方式都相同。客户端发送的用于验证文档的其他HTTP头信息可能是If-Match、If-Unmodified-Since或Unless-Modified-Since。很明显，该规范对于客户端软件必须支持哪些头信息，或必须使用哪些头信息没有明确的规定。因此，有些客户端根本就没有使用头信息，而IE只使用If-Range和Unless-Modified-Since。您最好用代码检查这些信息。采用这种方式的时候，您的应用程式能够在很高的层次遵循HTTP规范，并能够使用多种浏览器。Range头信息指明了被请求的字节范围--在例子中他是服务器应该恢复文档流的起始点。

当IIS接收到恢复下载的请求类型时，他发回包含下面的头信息的响应信息：
```
HTTP/1.1 206 Partial Content
Content-Range: bytes 822603-2844010/2844011
Accept-Ranges: bytes
Last-Modified: Sun, 26 Sep 2004 15:52:45 GMT
ETag: "47febb2cfd76c41:2062"
Cache-Control: private
Content-Type: application/x-zip-compressed
Content-Length: 2021408
```
请注意上面的代码和最初的下载请求的HTTP响应有点差别--恢复下载的请求是206而最初下载的请求是200。这表明通过线路传递进来的内容是部分文档。这一次Content-Range头信息指出了被传递字节的精确数量和位置。