---
layout: post
title: IO多路复用之select内核源码
draft: false
date: 2018-05-05 15:02:58
categories: Linux
tags: 
- Linux
- IO多路复用
- select函数
- 内核
permalink:
description:
cover_img:
toc-disable:
comments:
---
内核版本4.15
# sys_select()

```
SYSCALL_DEFINE5(select, int, n, fd_set __user *, inp, fd_set __user *, outp, fd_set __user *, exp, struct timeval __user *, tvp)
{
	struct timespec64 end_time, *to = NULL;
	struct timeval tv;
	int ret;

	if (tvp) {/*如果设置了超时值*/  
		if (copy_from_user(&tv, tvp, sizeof(tv)))
			return -EFAULT;

		to = &end_time;
		/*得到timespec格式的未来超时时间*/
		if (poll_select_set_timeout(to,
				tv.tv_sec + (tv.tv_usec / USEC_PER_SEC),
				(tv.tv_usec % USEC_PER_SEC) * NSEC_PER_USEC))
			return -EINVAL;
	}

	ret = core_sys_select(n, inp, outp, exp, to);
	// 复制剩余时间到用户空间 
	ret = poll_select_copy_remaining(&end_time, tvp, 1, ret);

	return ret;
}
```
sys_select函数中的三个文件描述符集fd的参数类型都为fd_set

```
#define __FD_SETSIZE	1024
typedef struct {
	unsigned long fds_bits[__FD_SETSIZE / (8 * sizeof(long))];
} __kernel_fd_set;
typedef __kernel_fd_set		fd_set;
```
可以发现fd_set的数据结构其实就是一个long型数组，这个数组的长度为: 1024/(8*4) = 32，即每个fd_set变量的内存大小为32*4=128bytes。但根据__FD_SETSIZE的定义表明fd的个数为1024，即inp、outp、exp分别能监测的最大fd个数默认为1024。而128bytes怎么能存储得下1024个long型元素呢？
原因在于内核里fd_set采用了bitmap的存储方式，如果第i位bit为1，则该位表示的大小便为2^i，128bytes = 1024bit，刚好可以表示1024个fd。
sys_select函数的主要工作是将表示超时时间的内存从用户态拷贝到内核态，再将超时时间的表示形式由timeval转换为timespec64（前者的单位为“秒”和“微秒”，而后者支持“秒”和“纳秒”）。
```
struct timeval {
	__kernel_time_t		tv_sec;		/* seconds */
	__kernel_suseconds_t	tv_usec;	/* microseconds */
};

struct timespec {
	__kernel_time_t	tv_sec;			/* seconds */
	long		tv_nsec;		/* nanoseconds */
};
```
接下来将工作交给core_sys_select函数处理


# core_sys_select()
```
int core_sys_select(int n, fd_set __user *inp, fd_set __user *outp,
			   fd_set __user *exp, struct timespec64 *end_time)
{
	fd_set_bits fds;
	/*
 	* Scalable version of the fd_set.
	typedef struct {
		unsigned long *in, *out, *ex;
		unsigned long *res_in, *res_out, *res_ex;
	} fd_set_bits;
	*/
	void *bits;
	int ret, max_fds;
	size_t size, alloc_size;
	struct fdtable *fdt;
	/* Allocate small arguments on the stack to save memory and be faster */
	/*在栈上分配小块参数，以节省内存及提高速度。SELECT_STACK_ALLOC 定义为256*/
	/**

       @ include/linux/poll.h
       #define FRONTEND_STACK_ALLOC     256
	   #define SELECT_STACK_ALLOC    FRONTEND_STACK_ALLOC

    **/
	long stack_fds[SELECT_STACK_ALLOC/sizeof(long)];//256/4=64bytes，64*32=2048bit

	ret = -EINVAL;
	if (n < 0)
		goto out_nofds;

	/* max_fds can increase, so grab it once to avoid race */
	/* max_fds是可以增长的，因此这里对其加锁以避免竞争 */
	rcu_read_lock();
	fdt = files_fdtable(current->files);
	max_fds = fdt->max_fds;
	rcu_read_unlock();
	/* 如果传入的n大于当前进程最大的文件描述符，给予修正 */
	if (n > max_fds)
		n = max_fds;

	/*
	 * We need 6 bitmaps (in/out/ex for both incoming and outgoing),
	 * since we used fdset we need to allocate memory in units of
	 * long-words. 
	 * 共需要分配6个fdset：用户传入的in, out, exception以及要返回给用户的res_in,res_out和res_exception。
	 * 根据传入的n值，计算保存所有fd需要多少字节（每fd占1bit），然后判断是在栈上分配内存还是在堆中分配内存。
	 */
	size = FDS_BYTES(n); 
	/*
	  
 	// How many longwords for "nr" bits?
 	
       #define FDS_BITPERLONG	(8*sizeof(long))
       #define FDS_LONGS(nr)	(((nr)+FDS_BITPERLONG-1)/FDS_BITPERLONG)
       #define FDS_BYTES(nr)	(FDS_LONGS(nr)*sizeof(long))
	*/
	bits = stack_fds;
	if (size > sizeof(stack_fds) / 6) { /* 每个文件描述符需要6个bitmap */
		/* Not enough space in on-stack array; must use kmalloc */
		/* 如果stack_fds数组的大小不能容纳下6个的fd_set,则使用kvmalloc重新分配一个大的数组 */
		ret = -ENOMEM;
		if (size > (SIZE_MAX / 6))
			goto out_nofds;

		alloc_size = 6 * size;
		bits = kvmalloc(alloc_size, GFP_KERNEL);
		if (!bits)
			goto out_nofds;
	}
	fds.in      = bits;
	fds.out     = bits +   size;
	fds.ex      = bits + 2*size;
	fds.res_in  = bits + 3*size;
	fds.res_out = bits + 4*size;
	fds.res_ex  = bits + 5*size;
	
	if ((ret = get_fd_set(n, inp, fds.in)) ||
	    (ret = get_fd_set(n, outp, fds.out)) ||
	    (ret = get_fd_set(n, exp, fds.ex)))
		goto out;
	
	/*
	static inline
	int get_fd_set(unsigned long nr, void __user *ufdset, unsigned long *fdset)
	{
		nr = FDS_BYTES(nr);
		if (ufdset)
			return copy_from_user(fdset, ufdset, nr) ? -EFAULT : 0;

		memset(fdset, 0, nr);
		return 0;
	}
	*/
	zero_fd_set(n, fds.res_in);
	zero_fd_set(n, fds.res_out);
	zero_fd_set(n, fds.res_ex);
	/* 对这些存放返回状态的字段清0 
	static inline
	void zero_fd_set(unsigned long nr, unsigned long *fdset)
	{
		memset(fdset, 0, FDS_BYTES(nr));
	}
	*/

	ret = do_select(n, &fds, end_time);

	if (ret < 0)
		goto out;
	if (!ret) {
		ret = -ERESTARTNOHAND;
		if (signal_pending(current))
			goto out;
		ret = 0;
	}
	/* 拷贝res_in, res_out和res_ex用户态的in, out, exp*/
	if (set_fd_set(n, inp, fds.res_in) ||
	    set_fd_set(n, outp, fds.res_out) ||
	    set_fd_set(n, exp, fds.res_ex))
		ret = -EFAULT;
out:
	if (bits != stack_fds) /* 如果有申请空间，那么释放fds对应的空间 */
		kvfree(bits); 
 out_nofds:
	return ret; /* 返回就绪的文件描述符的个数 */
}
```
# do_select
```
static int do_select(int n, fd_set_bits *fds, struct timespec64 *end_time)
{
	ktime_t expire, *to = NULL;
	struct poll_wqueues table;
	poll_table *wait;
	/*
	typedef struct poll_table_struct {
		poll_queue_proc _qproc;
		unsigned long _key;
	} poll_table;
	*/
	int retval, i, timed_out = 0;
	u64 slack = 0;
	unsigned int busy_flag = net_busy_loop_on() ? POLL_BUSY_LOOP : 0;
	unsigned long busy_start = 0;

	rcu_read_lock();
	retval = max_select_fd(n, fds);
	rcu_read_unlock();

	if (retval < 0)
		return retval;
	n = retval;

	poll_initwait(&table);
	/*
	  将函数__pollwait函数赋值给&pwq->pt指向的poll_table结构中的函数指针。
      后面的fp->poll将通过调用poll_wait函数来调用此函数。
	*/
	wait = &table.pt;
	/* 如果用户传入的timeout不为NULL，但是设定的时间为0，那么设置poll_table指针wait(即 &table.pt）为NULL；*/
	if (end_time && !end_time->tv_sec && !end_time->tv_nsec) {
		wait->_qproc = NULL;
		timed_out = 1;
	}

	if (end_time && !timed_out)
		slack = select_estimate_accuracy(end_time);

	retval = 0;
	for (;;) {
		unsigned long *rinp, *routp, *rexp, *inp, *outp, *exp;
		bool can_busy_loop = false;

		inp = fds->in; outp = fds->out; exp = fds->ex;
		rinp = fds->res_in; routp = fds->res_out; rexp = fds->res_ex;

		for (i = 0; i < n; ++rinp, ++routp, ++rexp) {
			unsigned long in, out, ex, all_bits, bit = 1, mask, j;
			unsigned long res_in = 0, res_out = 0, res_ex = 0;

			in = *inp++; out = *outp++; ex = *exp++; /* 取值后指向下一个4bytes */
			all_bits = in | out | ex;
			if (all_bits == 0) { /* 此轮循环中的32个描述符不存在监听 */
				i += BITS_PER_LONG;
				continue;
			}

			for (j = 0; j < BITS_PER_LONG; ++j, ++i, bit <<= 1) {/* 每轮循环遍历32个文件描述符后 */
				struct fd f;
				if (i >= n) /* 遍历完所有需要监听的文件描述符（0至n-1），跳出循环 */
					break;
				if (!(bit & all_bits)) /*第bit个fd不需要监听，继续往下遍历*/
					continue;
				f = fdget(i); /* 得到file结构指针，并增加引用计数字段f_count */
				/* 对每一个要求监听的设备fd做一次struct file_operations结构体里的poll操作。 */
				if (f.file) {/* 已打开的文件在内核中用file结构体表示（struct file <include/linux/fs.h>），文件描述符表中的指针指向file结构体。 */
					const struct file_operations *f_op;
					f_op = f.file->f_op;
					mask = DEFAULT_POLLMASK;
					/* #define DEFAULT_POLLMASK (POLLIN | POLLOUT | POLLRDNORM | POLLWRNORM) */
					if (f_op->poll) {
						wait_key_set(wait, in, out,
							     bit, busy_flag); /* 设置当前fd待监测的事件掩码 */
						mask = (*f_op->poll)(f.file, wait);
						/* (*f_op->poll)会返回当前设备fd的状态（比如是否可读可写），根据这个状态，do_select()接着做出不同的动作 */
					}
					fdput(f); /* 释放file结构指针，实际就是减小他的一个引用计数字段f_count */
					if ((mask & POLLIN_SET) && (in & bit)) { //可读
						res_in |= bit; //将返回值中的fd位设为1
						retval++;//已准备好的fd个数+1
						wait->_qproc = NULL; /* 后续有用，避免重复执行__pollwait() */
					}
					if ((mask & POLLOUT_SET) && (out & bit)) { //可写
						res_out |= bit;
						retval++;
						wait->_qproc = NULL;
					}
					if ((mask & POLLEX_SET) && (ex & bit)) { //异常条件
						res_ex |= bit;
						retval++;
						wait->_qproc = NULL;
					}
					/* got something, stop busy polling */
					if (retval) {
						can_busy_loop = false;
						busy_flag = 0;

					/*
					 * only remember a returned
					 * POLL_BUSY_LOOP if we asked for it
					 */
					} else if (busy_flag & mask)
						can_busy_loop = true;

				}
			}
			if (res_in)
				*rinp = res_in;
			if (res_out)
				*routp = res_out;
			if (res_ex)
				*rexp = res_ex;
			cond_resched();
		}
		wait->_qproc = NULL;
		/* 如果不匹配，do_select()发现timeout已经到了或者进程有signal信号打断，也会退出循环，只是返回空的结果给上层应用。 */
		if (retval || timed_out || signal_pending(current))
			break;
		if (table.error) {
			retval = table.error;
			break;
		}

		/* only if found POLL_BUSY_LOOP sockets && not out of time */
		if (can_busy_loop && !need_resched()) {
			if (!busy_start) {
				busy_start = busy_loop_current_time();
				continue;
			}
			if (!busy_loop_timeout(busy_start))
				continue;
		}
		busy_flag = 0;

		/*
		 * If this is the first loop and we have a timeout
		 * given, then we convert to ktime_t and set the to
		 * pointer to the expiry value.
		 */
		if (end_time && !to) {
			expire = timespec64_to_ktime(*end_time);
			to = &expire;
		}

		if (!poll_schedule_timeout(&table, TASK_INTERRUPTIBLE,
					   to, slack))
			timed_out = 1;
	}
    /* 调用poll_freewait，将本进程从所有文件的等待队列中删掉，并删除分配的poll_table_page对象，回收内存，并返回retval值 */
	poll_freewait(&table);

	return retval;
}
```

select为管理所有监测的文件，为每个文件分配了一个poll_table_entry结构。poll_table_entry包含文件信息、等待队列头以及等待队列元素。 

```
struct poll_table_entry {
	struct file *filp; // 指向特定fd对应的file结构体;
	unsigned long key; // 等待特定fd对应硬件设备的事件掩码，如POLLIN、POLLOUT、POLLERR;
	wait_queue_entry_t wait;
	wait_queue_head_t *wait_address;
};
```
poll_table存放在一个poll_wqueues结构体中，poll_wqueues 是 select/poll 对poll_table接口的具体化实现
```
struct poll_wqueues {
	poll_table pt;/* poll_table pt是poll_wqueues对外接口的地址 */
	struct poll_table_page *table; /* 如果inline_entries 空间不足, 从poll_table_page 中分配 */
	struct task_struct *polling_task; /* 调用poll 或select 的进程 */
	int triggered; /* 已触发标记 */
	int error;
	int inline_index;  /* 下一个要分配的inline_entrie 索引 */
	struct poll_table_entry inline_entries[N_INLINE_POLL_ENTRIES];
};
```
