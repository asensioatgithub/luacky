---
title: Socket编程
date: 2017-10-16 15:11:32
categories: 网络编程
tags:
- Socket
copyright:
---
socket起源于Unix，而Unix/Linux基本哲学之一就是“一切皆文件”，都可以用“打开open –> 读写write/read –> 关闭close”模式来操作。Socket就是该模式的一个实现，socket即是一种特殊的文件，一些socket函数就是对其进行的操作（读/写IO、打开、关闭）．
     说白了Socket是应用层与TCP/IP协议族通信的中间软件抽象层，**它是一组接口**。在设计模式中，Socket其实就是一个门面模式，它把复杂的TCP/IP协议族隐藏在Socket接口后面，对用户来说，一组简单的接口就是全部，让Socket去组织数据，以符合指定的协议。
<!--more-->
      同一台主机不同进程可以用进程号来唯一标识，但是在网络环境下进程号并不能唯一标识该进程。TCP/IP主要引入了网络地址、端口和连接等概念来解决网络间进程标识问题。套接字（Socket）是一个指向传输提供者的句柄，TCP/IP协议支持3种类型的套接字，分别是流式套接字、数据报式套接字和原始套接字。
# Socket类型
## Stream Socket
数据流式是一种面向连接的Socket，针对于面向连接的TCP服务应用，使用使用比较高质量的TCP协议。

## Datagram Socket
 数据报式Socket是一种无连接的套接字，对应于无连接的UDP服务应用，相应协议是UDP。
 
## Raw Socket
 除了上面两种常用的套接字类型外，还有一类原始套接字（raw socket），在某些网络应用中担任重要角色。比如我们平时想看一看网络是否通达，就用ping命令测试一下。Ping命令用的是ICMP协议，因此我们不能通过建立一个SOCK_STREAM或SOCK_DGRAM来发送这个包，而只能自己亲自来构建ICMP包来发送。另外一种情况是，许多操作系统只实现了几种常用的协议，而没有实现其它如OSPE、GGP等协议。如果自己有必要编写位于其上的应用，就必须借助raw socket来实现，这是因为操作系统遇到自己不能够处理的数据包，就将这个包交给raw socket处理。
Raw socket的作用主要在三个方面：
```
（1） 通过raw socket来接收和发送ICMP协议包。
（2） 接收发向本机的但TCP/IP栈不能够处理的IP包。
（3） 用来发送一些自己指定源地址特殊作用的IP包。
```
# Socket接口函数
## socket()函数
```c
int  socket(int protofamily, int type, int protocol);//返回sockfd
```

若无错误发生,socket()返回引用套接口的描述字(套接口号)。
否则的话,返回SOCKET_ERROR错误,即-1。

socket函数对应于普通文件的打开操作。普通文件的打开操作返回一个文件描述字，而socket()用于创建一个socket描述符（socket descriptor），它唯一标识一个socket。这个socket描述字跟文件描述字一样，后续的操作都有用到它，把它作为参数，通过它来进行一些读写操作。
正如可以给fopen的传入不同参数值，以打开不同的文件。创建socket的时候，也可以指定不同的参数创建不同的socket描述符，socket函数的三个参数分别为：
**1.protofamily**：
协议族（family）。常用的协议族有:
```
AF_INET	ipv4网络通信
AF_INET6	ipv6网络通信
AF_LOCAL或称AF_UNIX	本地通信
AF_PACKET	链路层通信
...
```
协议族决定了socket的地址类型，在通信中必须采用对应的地址，如AF_INET决定了要用ipv4地址（32位的）与端口号（16位的）的组合、AF_UNIX决定了要用一个绝对路径名作为地址。在Linux系统中AF_*和PF_*是等价的。

**2.type**：
指定socket类型。常用的socket类型有:
```
SOCK_STREAM	流式套接字tcp
SOCK_DGRAM	　数据报式套接字udp
SOCK_RAW	 原始套接字
...
```

**3.protocol**：故名思意，就是指定协议。
```
IPPROTO_TCP
IPPTOTO_UDP
IPPROTO_ICMP
IPPROTO_IGMP
0
...
```
如ICMP、IGMP、IP等协议，只需要把相应的参数改为IPPROTO_ICM、IPPROTO_ IGMP、IPPROTO_IP就可以了。
**注意：**并不是上面的type和protocol可以随意组合的，如SOCK_STREAM不可以跟IPPROTO_UDP组合。当protocol为0时，会自动选择type类型对应的默认协议。

```
socket(AF_INET, SOCK_RAW, IPPROTO_ICMP):
不用构建IP头部分，只发送ICMP头和数据。返回包括IP头和ICMP头和数据。
       raw udp socket(IPPROTO_UDP):
            不用构建IP头部分，只发送UDP头和数据。返回包括IP头和UDP头和数据。
       raw tcp socket(IPPROTO_TCP):
            不用构建IP头部分，只发送TCP头和数据。返回包括IP头和TCP头和数据。
       raw raw socket(IPPROTO_RAW):
            要构建IP头部和要发送的各种协议的头部和数据。返回包括IP头和相应的协议头和数据。 
```

## bind()函数
```c
int bind(
	SOCKET s,	//待捆绑Socket
	struct sockaddr far * name,	 //赋予Socket的主机地址标识
	int len	// name的长度，可用sizeof()获得
);
```
将IP地址和端口号与所创建的Socket号联系起来。调用成功,返回0。
### 主机地址标识
网络环境中的唯一通信端点标识。
包含:协议族、IP地址、端口。(俗称三元组)

关于端口:
```
在TCP/IP中,TCP与 UDP使用彼此独立的 端口;
端口大小:16bit(共2 16 个)
端口分为:
1系统全局端口:1~1023;例,HTTP为TCP/80,FTP为TCP/21、UDP/69,SMTP为TCP/25
2系统自动分配端口:1024~5000;
3自由端口:5000~65535;
```
### 主机地址标识的数据结构
```c
struct sockaddr {//共16个字节
	u_short sa_family;	//协议族
	char sa_data[14];	//主机地址标识(端口号、IP地址)
};

```
```c
struct sockaddr_in{//共16个字节
	short	sin_family;	//协议族
	u_short sin_port;	//16bit端口号,网络字节顺序
	struct in_addr sin_addr;//32bit的IP地址,网络字节顺序
	char sin_zero[8];//未用
};

//设置主机地址
//------------------------------------------------
void SetSockAddr(struct sockaddr_in *A,WORD Port,char *IP)
{
	A->sin_family= AF_INET;//TCP/IP协议
	A->sin_port= htons(Port);//端口号。
	A->sin_addr.s_addr= inet_addr(IP); //IP地址。
}
/*
htons():把16 bit的数字从主机字节顺序转换到网络字节顺序
inet_addr():把一个IP地址格式"A.B.C.D"转换成32 bit的网络字节顺序
*/
```

其中:
```c
struct in_addr{
	u_long s_addr;//32bit的IP地址,网络字节顺序
};
```
**注：**
网络字节顺序:16 bit/32 bit整数存放格式––高字节在前,低字节在后。
Intel CPU的主机字节顺序: 16 bit/32 bit整数存放格式––低字节在前,高字节在后。

## listen()函数
```c
int listen(int sockfd, int backlog)
```
告知内核在sockfd这个描述符上监听是否有连接到来，并设置同时能完成的最大连接数为backlog。3.6节还会继续解释这个参数。当调用listen后，内核就会建立两个队列，一个SYN队列，表示接受到请求，但未完成三次握手的连接；另一个是ACCEPT队列，表示已经完成了三次握手的队列
**sockfd**是调用socket()函数创建的socket描述符
**backlog**已经完成三次握手而等待accept的连接数

## connect()函数
```c
int connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
```
这三个参数和bind的三个参数类型一直，**只不过此处strcut sockaddr表示对端公开的地址。**三个参数都是传入参数。**connect顾名思义就是拿来建立连接的函数，只有像tcp这样面向连接、提供可靠服务的协议才需要建立连接**

## accept()函数
TCP服务器端依次调用socket()、bind()、listen()之后，就会监听指定的socket地址了。TCP客户端调用connect()之后就想TCP服务器发送了一个连接请求。TCP服务器监听到这个请求之后，就会调用accept()函数取接收请求，这样连接就建立好了。之后就可以开始网络I/O操作了，即类同于普通文件的读写I/O操作。
```c
int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
```
accept函数的第一个参数为服务器的socket描述字，第二个参数为指向struct sockaddr *的指针，用于返回客户端的协议地址，第三个参数为协议地址的长度。如果accpet成功，那么其返回值是由内核自动生成的一个全新的描述字，代表与返回客户的TCP连接。

**注意：**accept的第一个参数为服务器的socket描述字，是服务器开始调用socket()函数生成的，称为监听socket描述字；而accept函数返回的是已连接的socket描述字。一个服务器通常通常仅仅只创建一个监听socket描述字，它在该服务器的生命周期内一直存在。内核为每个由服务器进程接受的客户连接创建了一个已连接socket描述字，当服务器完成了对某个客户的服务，相应的已连接socket描述字就被关闭。
## listen、connect、accept流程及三次握手
以AF_INET,SOCK_STREAM,IPPROTO_TCP三个参数实例化的socket为例:
![](/images/socket_connect.png) 
```
1.服务器端在调用listen之后，内核会建立两个队列，SYN队列和ACCEPT队列，其中ACCPET队列的长度由backlog指定。
2.服务器端在调用accpet之后，将阻塞，等待ACCPT队列有元素。
3.客户端在调用connect之后，将开始发起SYN请求，请求与服务器建立连接，此时称为第一次握手。
4.服务器端在接受到SYN请求之后，把请求方放入SYN队列中，并给客户端回复一个确认帧ACK，此帧还会携带一个请求与客户端建立连接的请求标志，也就是SYN，这称为第二次握手
5.客户端收到SYN+ACK帧后，connect返回，并发送确认建立连接帧ACK给服务器端。这称为第三次握手
6.服务器端收到ACK帧后，会把请求方从SYN队列中移出，放至ACCEPT队列中，而accept函数也等到了自己的资源，从阻塞中唤醒，从ACCEPT队列中取出请求方，重新建立一个新的sockfd，并返回。
```
**客户端的connect在三次握手的第二个次返回，而服务器端的accept在三次握手的第三次返回。**
## send/recv和sendto/recvfrom
```c
int sendto(//向一指定目的地发送数据
	SOCKET s,//源套接口
	char *buf,//待发送数据的缓冲区
	int buflen,//缓冲区中数据的长度
	int flags,//调用方式标志位,一般取0
	struct sockaddr FAR *to,//指向目的套接口的主机地址
	int tolen//目的套接口主机地址的长度
);
int recvfrom(//从一个套接口接收数据
	SOCKET s,//接收套接口
	char *buf,//接收数据的缓冲区
	int len,//缓冲区中数据的长度
	int flags//调用方式标志位,一般取0
	struct sockaddr FAR *from, //获取发送套接口的主机地址
	int fromlen//发送套接口的主机地址的长度
);
```
主要用于无连接类型套接口向to参数指定端的套接口发送数据报。对于
SOCK_STREAM类型套接口,to和tolen参数被忽略;这种情况下sendto()等价于
send()。
```
int recv(//从一个套接口接收数据
	SOCKET s,//接收套接口
	char *buf,/接收数据的缓冲区
	int len,///缓冲区中数据的长度
	int flags//调用方式标志位,一般取0
);

```
## close()函数与shutdown()函数
从TCP协议角度来看，一个已建立的TCP连接有两种关闭方式，一种是正常关闭，即四次挥手关闭连接；还有一种则是异常关闭，我们通常称之为连接重置(RESET)。
首先说一下正常关闭时四次挥手的状态变迁，关闭连接的主动方状态变迁是FIN_WAIT_1->FIN_WAIT_2->TIME_WAIT，而关闭连接的被对方的状态变迁是CLOSE_WAIT->LAST_ACK->TIME_WAIT。在四次挥手过程中ACK包都是协议栈自动完成的，而FIN包则必须由应用层通过closesocket或shutdown主动发送，通常连接正常关闭后，recv会得到返回值0，send会得到错误码10058。
一个文件描述符关联着一个实际的文件——不管这个文件是什么，普通文件或网络套接口等等，但是多个打字可以同时与一个文件关联，并且内核维护一个文件引用计数。正常情况下，close函数不武断地释放一个描述字关联的文件，除了这个引用计数为0的时候，并且无论如何，当对一个描述字调用了close函数，用户无法再次使用这个描述字。这是close相对shutdown的两点差别，相应地shutdown是针对socket套接口定制的函数，所以它会做的更好。

shutdown函数不是参考引用计数，它会直接关闭相应的socket套接口，无论引用计数是多少。我们还知道，socket套接口是全双工的，也就是用户可以读，也可以写。存在一个这样的情况，此时用户已经把所有要写的数据都写完了，他想告诉对等端这一点；或者用户把所有要读的数据都读完成了，同样要告诉对等端。此时就是关闭读这一半或写这一半，使用shutdown可以完成这一个。系统定义了3个宏，这3个宏分别用作shutdown的后一个参数：
```
    SHUT_RD：关闭读这一半，此时用户不能再从这个套接字读数据，这个套接口接收到的数据都会被丢弃，对等方不知道这个过程。
    SHUT_WR：相应地关闭写这一半，此时用户不能再向套接字中写数据，内核会把缓存中的数据发送出去，接着不会再发送数据，对等端将会知道这一点。当对等端试图去读的时候，可能会发生错误。
    SHUT_RDWR：关闭读与写两半，此时用户不能从套接字中读或写。它相当于再次调用shutdown函数，并且一次指定SHUT_RD，一次指定SHUT_WR。
```

# 无连接协议的同步模式 
无连接服务器一般都是面向事务处理的。一个请求一个应答就完成了客户程序与服务程序之间的相互作用。
![](/images/socket_udp.png) 
服务器首先启动,通过调用socket()建立一个套接口,
然后bind()将该套接口和本地地址(IP地址和端口)联系在一起,
服务器调用recv()等待接收数据。

客户机通过调用socket()建立一个套接口,
然后bind()将该套接口和本地地址(IP地址和端口)联系在一起,
客户机调用sendto()向服务器发送数据;

服务器的recv()接收到客户机的数据后,
调用sendto()向客户机发送应答数据;

客户机的recv()便接收到了服务器的应答数据;

最后,待数据传送结束后,双方调用closesocket()关闭套接口。
# 有连接协议
![](/images/Socket.jpg) 
      服务器端先初始化Socket，然后与端口绑定(bind)，对端口进行监听(listen)，调用accept阻塞，等待客户端连接。在这时如果有个客户端初始化一个Socket，然后连接服务器(connect)，如果连接成功，这时客户端与服务器端的连接就建立了。客户端发送数据请求，服务器端接收请求并处理请求，然后把回应数据发送给客户端，客户端读取数据，最后关闭连接，一次交互结束。