---
layout: post
title: LeetCode-链表
draft: false
date: 2017-10-14 12:17:34
categories: LeetCode
tags: 
- LeetCode
- 算法
- 连表
permalink:
description:
cover_img:
toc-disable:
comments:
---
# Insertion Sort List
## Description
Algorithm of Insertion Sort:

    Insertion sort iterates, consuming one input element each repetition, and growing a sorted output list.
    At each iteration, insertion sort removes one element from the input data, finds the location it belongs within the sorted list, and inserts it there.
    It repeats until no input elements remain.


Example 1:
```
Input: 4->2->1->3
Output: 1->2->3->4
```
Example 2:
```
Input: -1->5->3->4->0
Output: -1->0->3->4->5
```
## 思路
排序时，链表的插入和删除需要记录前续节点
## 实现
```
class Solution {
public:
    ListNode* insertionSortList(ListNode* head){ 
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* newHead = new ListNode(-1);
        newHead->next = head;
        
        ListNode* node = head->next; // node: 当前排序节点
        ListNode* pre = head;        // pre: 当前排序节点的前序节点

        while(node != NULL) {
            ListNode* cmp = newHead->next;     // 从头遍历已排序节点
            ListNode* preCmp = newHead;        // 同时记录前序节点
            
            while(cmp != node && cmp->val <= node->val) {
                cmp = cmp->next;
                preCmp = preCmp->next;
            }
            
            if(cmp == node) {
                pre = node;
                node = node->next;
            } else {
                pre->next = node->next;
                
                node->next = cmp;
                preCmp->next = node;
                
                node = pre->next;     
            }
        }
        
        return newHead->next;
    }
};
```
# Reverse Linked List
## Decriptiom
Reverse a singly linked list.

Example:
```
Input: 1->2->3->4->5->NULL
Output: 5->4->3->2->1->NULL
```
## 实现
```
class Solution {
public:

    // iteratiom
    ListNode* reverseList(ListNode* head) {
        if(head == NULL || head->next == NULL)
            return head;
        
        ListNode* pre = head;
        ListNode* cur = head->next;
        pre->next = NULL; // 细节: 原始连表的头节点最终变成尾节点，所以将其next赋为空
        
        while(cur) {
            ListNode* next = cur->next;
            
            cur->next = pre;
            pre = cur;
            cur = next;
            
        }
        return pre;
    }
    
    //recursion
    ListNode* reverseList(ListNode* head) {
    	if (!head || !(head -> next)) {
            return head;
        }
        ListNode* node = reverseList(head -> next);
        head -> next -> next = head;
        head -> next = NULL;
        return node;
    }
};
```
# Middle of the Linked List
## Description
Given a non-empty, singly linked list with head node head, return a middle node of linked list.

If there are two middle nodes, return the second middle node.
Example 1:
```
Input: [1,2,3,4,5]
Output: Node 3 from this list (Serialization: [3,4,5])
The returned node has value 3.  (The judge's serialization of this node is [3,4,5]).
Note that we returned a ListNode object ans, such that:
ans.val = 3, ans.next.val = 4, ans.next.next.val = 5, and ans.next.next.next = NULL.
```
Example 2:
```
Input: [1,2,3,4,5,6]
Output: Node 4 from this list (Serialization: [4,5,6])
Since the list has two middle nodes with values 3 and 4, we return the second one.
```
## 实现
```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode* middleNode(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        if(head->next->next == NULL)
            return head->next;
        ListNode* fast = head;
        ListNode* slow = head;
        
        while(fast != NULL && fast->next != NULL) {
            fast = fast->next->next;
            slow = slow->next;
        }
        return slow;
    
    }
};
```
# Remove Nth Node From End of List
## Description
Given a linked list, remove the n-th node from the end of list and return its head.

Example:

Given linked list: 1->2->3->4->5, and n = 2.

After removing the second node from the end, the linked list becomes 1->2->3->5.

Note:

Given n will always be valid.

Follow up:

Could you do this in one pass?
## 思路
前后指针，前指针先移动到第n个结点，然后两个指针同时向后遍历，直到前指针到达链尾，此时后指针指向的目标节点的前序节点。
## 思路
```
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode(int x) : val(x), next(NULL) {}
 * };
 */
class Solution {
public:
    ListNode* removeNthFromEnd(ListNode* head, int n) {
        if(head == NULL)
            return head;
        
        ListNode* newHead = new ListNode(0);
        newHead->next = head;
        ListNode* front = newHead;
        ListNode* back = newHead;
        
        for(int i=0; i<n; i++) {
            front = front->next;
        }

        while(front->next != NULL) {
            front = front->next;
            back = back->next;
        }
        
        back->next = back->next->next;
        return newHead->next;
    }
};
```
# Remove Linked List Elements
## Description
Remove all elements from a linked list of integers that have value val.

Example:

Input:  1->2->6->3->4->5->6, val = 6
Output: 1->2->3->4->5
## 思路
1. 考虑头节点等于val的情况；
2. 如果pre->next->val == val，pre指针不应该向后移动，而是继续判断pre-next的val。
## 实现
```
class Solution {
public:
    ListNode* removeElements(ListNode* head, int val) {
        if(head == NULL) {
            return head;
        }
        
        ListNode* newHead = new ListNode(0);
        newHead->next = head;
        ListNode* pre = newHead;
        while(pre->next) {
            if(pre->next->val == val) {
                pre->next = pre->next->next;
                continue;
            }
            
            pre = pre->next;
        }
        
        return newHead->next;
    }
};
```
# Remove Duplicates from Sorted List

## Description

Given a sorted linked list, delete all duplicates such that each element appear only *once*.

**Example 1:**

```
Input: 1->1->2
Output: 1->2
```

**Example 2:**

```
Input: 1->1->2->3->3
Output: 1->2->3
```

## 实现

```c++
class Solution {
public:
    ListNode* deleteDuplicates(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* pre = head;
        while(pre->next) {
            if(pre->next->val == pre->val) {
                pre->next = pre->next->next;
                continue;
            }
            
            pre = pre->next;
        }
        
        return head;
    }
};
```

# Remove Duplicates from Sorted List II

## Description

Given a sorted linked list, delete all nodes that have duplicate numbers, leaving only *distinct* numbers from the original list.

**Example 1:**

```
Input: 1->2->3->3->4->4->5
Output: 1->2->5
```

**Example 2:**

```
Input: 1->1->1->2->3
Output: 2->3
```

## 思路

tail指针: distinct链表的尾结点。

healper函数: 去除链表头部重复值，即返回链表第一个非重复值的结点。

## 实现

```go
class Solution {
public:
    ListNode* deleteDuplicates(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* dummy = new ListNode(0);
        dummy->next = head;
        ListNode* tail = dummy;
        ListNode* cur = head;
        while(cur) {
            ListNode* ret = helper(cur);
            if(cur == ret) { // 如果当前结点原本就是非重复值结点
                tail = cur;	// 将当前结点加入到结果链表中
                cur = cur->next; // 遍历下一结点
            } else {
                tail->next = ret; // 剔除开头以cur为头结点值为cur->val的结点
                cur = ret; // 继续判断ret，因为ret结点仍然有可能是重复值结点
            }
            
        }
        return dummy->next;
    }
    
    ListNode* helper(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        if(head->val != head->next->val) {
            return head;
        }
        
        int val = head->val;
        ListNode* node = head->next->next;
        while(node && node->val == val) {
            node = node ->next;
        }
 
        return node;

    } 
};
```



# Odd Even Linked List

## Description

Given a singly linked list, group all odd nodes together followed by the even nodes. Please note here we are talking about the node number and not the value in the nodes.

You should try to do it in place. The program should run in O(1) space complexity and O(nodes) time complexity.

**Example 1:**

```
Input: 1->2->3->4->5->NULL
Output: 1->3->5->2->4->NULL
```

**Example 2:**

```
Input: 2->1->3->5->6->4->7->NULL
Output: 2->3->6->7->1->5->4->NULL
```

**Note:**

- The relative order inside both the even and odd groups should remain as it was in the input.
- The first node is considered odd, the second node even and so on ...

## 实现

```c++
class Solution {
public:
    ListNode* oddEvenList(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* dummy = new ListNode(0);
        ListNode* evenTail = dummy;
        ListNode* oddTail = head;
        
        ListNode* cur = head->next;
        while(cur && cur->next) {
            evenTail->next = cur;
            evenTail = evenTail->next;
            
            oddTail->next = cur->next;
            oddTail = oddTail->next;
            
            cur = cur->next->next;
        }
        
        if(cur) {
            evenTail->next = cur;
            evenTail = evenTail->next;
        }
        evenTail->next = NULL;
        oddTail->next = dummy->next;
        return head;
    }
};
```

# Rotate List

## Description

Given a linked list, rotate the list to the right by *k* places, where *k* is non-negative.

**Example 1:**

```
Input: 1->2->3->4->5->NULL, k = 2
Output: 4->5->1->2->3->NULL
Explanation:
rotate 1 steps to the right: 5->1->2->3->4->NULL
rotate 2 steps to the right: 4->5->1->2->3->NULL
```

**Example 2:**

```
Input: 0->1->2->NULL, k = 4
Output: 2->0->1->NULL
Explanation:
rotate 1 steps to the right: 2->0->1->NULL
rotate 2 steps to the right: 1->2->0->NULL
rotate 3 steps to the right: 0->1->2->NULL
rotate 4 steps to the right: 2->0->1->NULL
```

## 思路

链表中查找倒数第k个结点的常用方法：前后指针。

1、前指针先走k步；

2、然后两个指针同时后移知道前指针指向尾结点，此时慢结点指向倒数第k个结点。

此题中由于k是可能大于链表长度的，所以第1步中当前指针遍历到尾结点的时候，重新指向头结点继续遍历。

如果k足够大的时候存在超时的情况，所以需要计算出链表的长度，将k取模。

```c++
class Solution {
public:
    ListNode* rotateRight(ListNode* head, int k) {
        if(head == NULL || head->next == NULL) {
            return head;
        }   
        
        ListNode* slow = head;
        ListNode* fast = head;
        int length = 0;
        while(k-- > 0) {
            length ++;
            if(fast->next == NULL) {
                k = k%length;
                fast = head;
                continue;
            }
            
            fast = fast->next;
        }
        
        while(fast->next) {
            slow = slow->next;
            fast = fast->next;
        }
        
        fast->next = head;
        head = slow->next;
        slow->next = NULL;
        
        return head;
        
    }
};
```

# Palindrome Linked List

## Description

Given a singly linked list, determine if it is a palindrome.

**Example 1:**

```
Input: 1->2
Output: false
```

**Example 2:**

```
Input: 1->2->2->1
Output: true
```

**Follow up:**
Could you do it in O(n) time and O(1) space?

## 思路

1.找到中间结点；

2.反转后半部链表；

3.比较两个链表。

## 实现

```c++
class Solution {
public:
    bool isPalindrome(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return true;
        }
        
        ListNode* mid = findMid(head);
        ListNode* tail = reverseList(mid);
        
        while(head != mid) {
            if(head->val != tail->val) {
                return false;
            }
            
            head = head->next;
            tail = tail->next;
        }
        
        return true;
    }
    
    ListNode* findMid(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* slow = head;
        ListNode* fast = head;
        while(fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        
        return slow;
    }
    
    ListNode* reverseList(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* pre = head;
        ListNode* cur = pre->next;
        pre->next = NULL; // 从中结点处断开，被分成两个独立的链表
        while(cur) {
            ListNode* next = cur->next;
            cur->next = pre;
            pre = cur;
            cur = next;
        }
        
        return pre;
    }
    
};
```

# Reorder List

## Description

Given a singly linked list *L*: *L*0→*L*1→…→*L**n*-1→*L*n,
reorder it to: *L*0→*L**n*→*L*1→*L**n*-1→*L*2→*L**n*-2→…

You may **not** modify the values in the list's nodes, only nodes itself may be changed.

**Example 1:**

```
Given 1->2->3->4, reorder it to 1->4->2->3.
```

**Example 2:**

```
Given 1->2->3->4->5, reorder it to 1->5->2->4->3.
```

## 实现

```
class Solution {
public:
    void reorderList(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return ;
        }
        ListNode* mid = findMid(head);
        ListNode* right = reverseList(mid);
        ListNode* left = head;
        
        ListNode* dummy = new ListNode(0);
        
        ListNode* tail = dummy;
        while(left != mid) {
            tail->next = left;
            left = left->next;
            tail = tail->next;
            
            tail->next = right;
            right = right->next;
            tail = tail->next;
            
        }
    }
    
    ListNode* findMid(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* slow = head;
        ListNode* fast = head;
        while(fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        
        return slow;
    }
    
    ListNode* reverseList(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* pre = head;
        ListNode* cur = pre->next;
        pre->next = NULL;   // 被分成两个独立的链表
        while(cur) {
            ListNode* next = cur->next;
            cur->next = pre;
            pre = cur;
            cur = next;
        }
        
        return pre;
    }
};
```

# Reverse Linked List II

## Description

Reverse a linked list from position *m* to *n*. Do it in one-pass.

**Note:** 1 ≤ *m* ≤ *n* ≤ length of list.

**Example:**

```
Input: 1->2->3->4->5->NULL, m = 2, n = 4
Output: 1->4->3->2->5->NULL
```

## 思路

重点是要记录整个反转链表的前序和后序结点。

## 实现

```
class Solution {
public:
    ListNode* reverseBetween(ListNode* head, int m, int n) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
                
        int length = n-m;
        ListNode* dummy = new ListNode(0);
        dummy->next = head;
        
        ListNode* pre = dummy;
        while(--m) {
            pre = pre->next;
        }
        
        ListNode* tail = pre->next;
        
        while(length--) {
            tail = tail->next;
        }
        pre->next = reverseList(pre->next, tail->next); // 前序结点指向反转之后的头结点
        
        return dummy->next;
    }
    
     ListNode* reverseList(ListNode* head, ListNode* tail) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* pre = head;
        ListNode* cur = pre->next;
        pre->next = tail;  // 反转的时候头结点直接指向后序结点
        while(cur != tail) {
            ListNode* next = cur->next;
            cur->next = pre;
            pre = cur;
            cur = next;
        }
        
        return pre;
    }
};
```

# Add Two Numbers

You are given two **non-empty** linked lists representing two non-negative integers. The digits are stored in **reverse order** and each of their nodes contain a single digit. Add the two numbers and return it as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.

**Example:**

```
Input: (2 -> 4 -> 3) + (5 -> 6 -> 4)
Output: 7 -> 0 -> 8
Explanation: 342 + 465 = 807.
```

## 实现

```c++
class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        ListNode* dummy = new ListNode(0);
        ListNode* tail = dummy;
        
        int sum = 0;
        int add = 0;
        
        while(l1 && l2) {
            sum = l1->val + l2->val + add; 
            ListNode* node = new ListNode(sum%10);
            add = sum/10;
            tail->next = node;
            tail = tail->next;
            
            if(l1) l1 = l1->next;
            if(l2) l2 = l2->next;
        }
        
        while(l1) {
            sum = l1->val + add;
            ListNode* node = new ListNode(sum%10);
            add = sum/10;
            tail->next = node;
            tail = tail->next;
            
            l1 = l1->next;
            
        }
        
        while(l2) {
            sum = l2->val + add;
            ListNode* node = new ListNode(sum%10);
            add = sum/10;
            tail->next = node;
            tail = tail->next;
            
            l2 = l2->next;
        }
        
        if(add) tail->next = new ListNode(add);
        
        return dummy->next;
    }
};
```

# Add Two Numbers II

## Description

You are given two **non-empty** linked lists representing two non-negative integers. The most significant digit comes first and each of their nodes contain a single digit. Add the two numbers and return it as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.

**Follow up:**
What if you cannot modify the input lists? In other words, reversing the lists is not allowed.

**Example:**

```
Input: (7 -> 2 -> 4 -> 3) + (5 -> 6 -> 4)
Output: 7 -> 8 -> 0 -> 7
```

## 实现

```c++
class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        stack<int> s1, s2;
        while (l1) {
            s1.push(l1->val);
            l1 = l1->next;
        }
        while (l2) {
            s2.push(l2->val);
            l2 = l2->next;
        }
        int sum = 0;
        int add = 0;
        ListNode* dummy = new ListNode(0);
        while(!s1.empty() || !s2.empty()) {
            sum = add;
            if (!s1.empty()) {sum += s1.top(); s1.pop();}
            if (!s2.empty()) {sum += s2.top(); s2.pop();}
            add = sum/10;
            ListNode* node = new ListNode(sum%10);
            node->next = dummy->next;
            dummy->next = node;
            
        }
        if(add) {
            ListNode* node = new ListNode(add);
            node->next = dummy->next;
            dummy->next = node;
        }
        return dummy->next;
    }
};
```

# Swap Nodes in Pairs

## Description

Given a linked list, swap every two adjacent nodes and return its head.

**Example:**

```
Given 1->2->3->4, you should return the list as 2->1->4->3.
```

**Note:**

- Your algorithm should use only constant extra space.
- You may **not** modify the values in the list's nodes, only nodes itself may be changed.



## 实现

```c++
class Solution {
public:
    ListNode* swapPairs(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        ListNode* dummy = new ListNode(0);
        dummy->next = head;
        
        ListNode* cur = head;
        ListNode* pre = dummy;
        while(cur && cur->next) { // 同时处理两个结点时常用用法：取并
            pre->next = swapNodes(cur);  
            pre = cur;
            cur = cur->next;
        }
        
        return dummy->next;
    }
    
    ListNode* swapNodes(ListNode* head) {
        if(head == NULL || head->next == NULL) {
            return head;
        }
        
        ListNode* pre = head;
        ListNode* cur = head->next;
        ListNode* post = head->next->next;
        
        pre->next = post;
        cur->next = pre;
        
        return cur;
    }
};
```

# Convert Sorted List to Binary Search Tree

Given a singly linked list where elements are sorted in ascending order, convert it to a height balanced BST.

For this problem, a height-balanced binary tree is defined as a binary tree in which the depth of the two subtrees of *every* node never differ by more than 1.

**Example:**

```
Given the sorted linked list: [-10,-3,0,5,9],

One possible answer is: [0,-3,9,-10,null,5], which represents the following height balanced BST:

      0
     / \
   -3   9
   /   /
 -10  5
```

## 思路

通过快慢指针找到中点后，以中点的值建立树的根节点，然后把原链表断开，分为前后两个链表，再分别对这两个链表递归调用原函数，分别连上左右子节点即可。

## 实现

```c++
class Solution {
public:
    TreeNode *sortedListToBST(ListNode *head) {
        if (!head) return NULL;
        if (!head->next) return new TreeNode(head->val);
        ListNode *slow = head;
        ListNode *fast = head;
        ListNode *last = slow;
        while (fast->next && fast->next->next) {
            last = slow;
            slow = slow->next;
            fast = fast->next->next;
        }
        fast = slow->next;
        last->next = NULL;
        TreeNode *cur = new TreeNode(slow->val);
        if (head != slow) cur->left = sortedListToBST(head);
        cur->right = sortedListToBST(fast);
        return cur;
    }
};
```