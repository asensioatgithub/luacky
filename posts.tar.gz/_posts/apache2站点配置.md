---
title: apache2与myzoo站点配置
date: 2017-11-24 21:04:37
categories: WEB安全
tags:
- web安全
copyright:
---
这篇博客记录了apache2在ubuntu系统下的文件结构，以及用apache2服务器搭建web站点。
# apache2目录解析
/etc/apache2/目录结构如下：
```c
maohao@maohao-HP-15-Notebook-PC:/etc/apache2$ ls
apache2.conf    conf-enabled  magic           mods-enabled  sites-available
conf-available  envvars       mods-available  ports.conf    sites-enabled
```
<!--more-->
## apache2.conf
Apache在启动时会自动读取这个文件的配置信息。而其他的一些配置文件，如 ports.conf等，则是通过Include指令包含进来。
```c
# It is split into several files forming the configuration hierarchy outlined
# below, all located in the /etc/apache2/ directory:
#
#       /etc/apache2/
#       |-- apache2.conf
#       |       `--  ports.conf
#       |-- mods-enabled
#       |       |-- *.load
#       |       `-- *.conf
#       |-- conf-enabled
#       |       `-- *.conf
#       `-- sites-enabled
#               `-- *.conf
```
apache2.conf里面的参数属于core module，这4个常用：
**Timeout** 超时时间
**KeepAlive On/Off** 启动或关闭KeepAlive。如果将KeepAlive设置为On，那么来自同一客户端的请求就不需要再一次连接，避免每次请求都要新建一个连接而加重服务器的负担。即用户完成一次访问后，不会立即断开连接，如果还有请求，那么会继续在这一次 TCP 连接中完成，而不用重复建立新的 TCP 连接和关闭TCP 连接，可以提高用户访问速度。
**MaxKeepAliveRequests** 最大的KeepAlive连接数
**KeepAliveTimeout** 
最大的KeepAlive时间，超时将关闭连接。也就是说，如果第二次请求和第一次请求之间超过KeepAliveTimeOut的时间的话，第一次连接就会中断，再新建第二个连接。  

## sites-available和sites-enabled
/etc /apache2下有一个sites-available目录，里面存放的是网站的配置文件，而sites-enabled目录存放的只是一些指向这里的文件的符号链接，你可以用ls /etc/apache2/sites-enabled/来证实一下。
```shell
maohao@maohao-HP-15-Notebook-PC:/etc/apache2/sites-available$ ls
000-default.conf  default-ssl.conf  myzoo.conf
maohao@maohao-HP-15-Notebook-PC:/etc/apache2/sites-available$ ls ../sites-enabled/
000-default.conf  myzoo.conf
```
如果apache上配置了多个虚拟主机，每个虚拟主机的配置文件都放在 sites-available下，那么对于虚拟主机的停用、启用就非常方便了：当在sites-enabled下建立一个指向某个虚拟主机配置文件的链接时，就启用了它；如果要关闭某个虚拟主机的话，只需删除相应的链接即可，根本不用去改配置文件。
所以可以通过建立删除链接来动态启用和关闭相应的站点:
```c
sudo ln -s /etc/apache2/sites-available/conf_name /etc/apache2/sites-enabled/conf_name
sudo ln -s /etc/apache2/sites-available/conf_name /etc/apache2/sites-enabled/conf_name
```
或者直接用apache2自带的**a2ensite conf_name**和**a2dissite conf_name conf_name**实现配置文件的启用和关闭。

## mods-available和mods-enabled
mods-available、mods-enabled和上面说的sites-available、sites-enabled类似，这两个目录是存放apache功能模块的配置文件和链接的。比如当用apt-get install php5安装了PHP模块后，在这两个目录里就有了php5.load、php5.conf和指向这两个文件的链接。这种目录结果对于启用、停用某个 Apache模块是非常方便的。
```c
maohao@maohao-HP-15-Notebook-PC:/etc/apache2/mods-enabled$ ls
access_compat.load  authz_core.load  deflate.load  mime.load         php5.6.load
alias.conf          authz_host.load  dir.conf      mpm_prefork.conf  setenvif.conf
alias.load          authz_user.load  dir.load      mpm_prefork.load  setenvif.load
auth_basic.load     autoindex.conf   env.load      negotiation.conf  status.conf
authn_core.load     autoindex.load   filter.load   negotiation.load  status.load
authn_file.load     deflate.conf     mime.conf     php5.6.conf
```
load后缀存放模块的路径，conf后缀表示该模块的配置。

## ports.conf
这里面设置了Apache使用的端口。如果需要调整默认的端口设置，需要编辑这个文件。
```c
# If you just change the port or add more ports here, you will likely also
# have to change the VirtualHost statement in
# /etc/apache2/sites-enabled/000-default.conf

Listen 80
Listen 81
<IfModule ssl_module>
        Listen 443
</IfModule>

<IfModule mod_gnutls.c>
        Listen 443
</IfModule>

# vim: syntax=apache ts=4 sw=4 sts=4 sr noet
```
IfModule用于对指定的模块做出标记，指令仅处理匹配的模块，非匹配模块将会忽略。如果你加载了ssl模块，将会侦听443端口(HTTPS)。配置Apache侦听其他的端口，比如说8080，只需要简单的添加：
`Listen 8080`
一旦添加了这条并且重新启动Apache，就会侦听8080端口。

# apache2站点配置
这里以搭建myzoo网站为例。myzoo的运行需要预先安装apache2, mysql, php5： 
```c
sudo apt-get install apache2 php5 mysql php5-mysql
```
首先要在mysql中建立网站所需的数据库和表。请记住数据库的名字和表名，在修改zoobar网站源码时需要。(建议使用名字myzoo，否则需要修改common.php中的16行，将new Database的名字进行修改)
为网站创建数据库：
```c
maohao@maohao-HP-15-Notebook-PC:/var/www$ mysql -u root -p
Enter password: 
mysql> create database myzoo;
mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| challenges         |
| dvwa               |
| keystone           |
| mysql              |
| myzoo              |
| performance_schema |
| security           |
| sys                |
+--------------------+
9 rows in set (0.30 sec)
```
在myzoo数据库里创建Person表:
```c
mysql> use myzoo;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A
mysql>create table Person(PersonID int primary key auto_increment, Password varchar(100),Salt varchar(100),Username varchar(100),Token varchar(100),Zoobars int default 10, Profile varchar(5000));
Database changed
mysql> show tables;
+-----------------+
| Tables_in_myzoo |
+-----------------+
| Person          |
+-----------------+
1 row in set (0.00 sec)
```
创建号之后，在myzoo的includes文件夹中， 修改database.class.php文件，将数据库的用户名、密码和数据库名赋值给相应的变量。
```c
class Database{

        private $db_host = 'localhost';
        private $db_user = 'root';
        private $db_pass = "your_passwd";
        private $db_dbname = "myzoo";
```
数据库配置完后，就开始在apache2中配置myzoo了，首先将myzoo的代码拷贝到/var/www/目录下或者其他任意指定的路径里。
```c
maohao@maohao-HP-15-Notebook-PC:/var/www$ ls
html  myzoo
```
在/etc/apache2/sites-available目录下单独为myzoo创建一个配置文件，命名为`myzoo.conf`
```c
sudo cp 000-default.conf myzoo.conf
```
编辑myzoo.conf文件，并为网站分配一个独立的端口，000-default.conf 的默认http端口为80，这里设定myzoo的端口为81；同时把网站源码根目录所在路径（ /var/www）赋值给变量DocumentRoot **(DocumentRoot末尾不要加 /)**

```c
<VirtualHost *:81>

        ServerAdmin webmaster@localhost
        DocumentRoot /var/www #配置访问跟目录 

```
这里如果之前不是把网站源码放到/var/www目录下，还需到主配置文件apache2.conf中为源码路径添加如下代码:
**允许所有请求访问资源**
```c
<Directory your_path>
        Options Indexes FollowSymLinks 
        AllowOverride None #不允许别人修改我们的页面 
        Require all granted #设置访问权限 
</Directory>
Directory标签对目录进行访问控制设置。Options中：
**Indexes**表示：如果该虚拟目录下没有 index.html，浏览器也会显示该虚拟目录的目录结构，列出该虚拟目录下的文件和子目录。
**FollowSymLinks**表示:就是允许你的网页文件夹下的链接文件链接到首页目录以外的文件。举例来说，如果你把首页目录设置为/var/www/html，那么你的网页程序最多只能访问到/var/www/html目录，上层目录是不可见的。但是你可以通过链接把文件链接到/var/www/html目录以外的文件以访问该文件。
```
将配置好的myzoo.conf文件链接到sites-enbaled目录里，让其生效。查看sites-enabled/已经存在myzoo.conf了。
```c
maohao@maohao-HP-15-Notebook-PC:/etc/apache2$ sudo a2ensite myzoo.conf 
Enabling site myzoo.
To activate the new configuration, you need to run:
  service apache2 reload
maohao@maohao-HP-15-Notebook-PC:/etc/apache2$ ls sites-enabled/
000-default.conf  myzoo.conf
```
同事分配了新的端口号后，还要告知ports.conf，让apache2开始监听该端口。
```
# If you just change the port or add more ports here, you will likely also
# have to change the VirtualHost statement in
# /etc/apache2/sites-enabled/000-default.conf

Listen 80
Listen 81
<IfModule ssl_module>
        Listen 443
</IfModule>

<IfModule mod_gnutls.c>
        Listen 443
</IfModule>

# vim: syntax=apache ts=4 sw=4 sts=4 sr noet
```
重启apache2服务：
```c
sudo service apache2 restart
```
此时，使用http://localhost:81/myzoo应该可以访问zoobar网站。
