---
title: nmap手册
date: 2017-10-09 10:52:08
categories:
tags:
copyright:
---
# 主机发现
## -sn (No port scan)
This option tells Nmap not to do a port scan after host discovery, and only print out the available hosts that responded to the host discovery probes. This is often known as a “**ping scan**”, but you can also request that traceroute and NSE host scripts be run. This is by default one step more intrusive than the list scan, and can often be used for the same purposes. It allows light reconnaissance of a target network without attracting much attention. Knowing how many hosts are up is more valuable to attackers than the list provided by list scan of every single IP and host name.
<!--more--->
Systems administrators often find this option valuable as well. It can easily be used to count available machines on a network or monitor server availability. This is often called a ping sweep, and is more reliable than pinging the broadcast address because many hosts do not reply to broadcast queries.

The default host discovery done with -sn consists of **an ICMP echo request, TCP SYN to port 443, TCP ACK to port 80, and an ICMP timestamp request** by default. 
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -sn 151.101.25.147
Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-09 12:55 CST
Nmap scan report for 151.101.25.147
Host is up (0.26s latency).
Nmap done: 1 IP address (1 host up) scanned in 0.51 seconds
```
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump host 151.101.25.147 tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
12:57:36.868657 IP bogon > 151.101.25.147: ICMP echo request, id 49656, seq 0, length 8
12:57:36.868707 IP bogon.34038 > 151.101.25.147.https: Flags [S], seq 4270696695, win 1024, options [mss 1460], length 0
12:57:36.868724 IP bogon.34038 > 151.101.25.147.http: Flags [.], ack 4270696695, win 1024, length 0
12:57:36.868737 IP bogon > 151.101.25.147: ICMP time stamp query id 20242 seq 0, length 20
12:57:37.081427 IP 151.101.25.147 > bogon: ICMP echo reply, id 49656, seq 0, length 8
12:57:37.082156 IP 151.101.25.147.https > bogon.34038: Flags [S.], seq 3687106019, ack 4270696696, win 28800, options [mss 1300], length 0
12:57:37.082234 IP bogon.34038 > 151.101.25.147.https: Flags [R], seq 4270696696, win 0, length 0
12:57:37.082297 IP 151.101.25.147.http > bogon.34038: Flags [R], seq 4270696695, win 0, length 0
12:57:37.086164 IP 151.101.25.147 > bogon: ICMP time stamp reply id 20242 seq 0: org 00:00:00.000, recv 04:57:36.979, xmit 04:57:36.979, length 20
```
When executed by an unprivileged user, only SYN packets are sent (using a connect call) to ports 80 and 443 on the target.
**通过执行下面的步骤来进行工作：**
1.源系统向目标系统发送一个同步请求，该请求中包含一个端口号。
2.如果添加在上一步中的所请求的端口号是开启的，那么目标系统将通过同步/应答(SYN/ACK)来响应源系统。
3.源系统通过重置(RST)来响应目标系统，从而断开连接。
4.目标系统可以通过重置/应答(RST/ACK)来响应源系统。
**如果被扫描的端口是关闭的，那么将执行下面的步骤：**
1.源系统发送一个同步(SYN)请求到目标系统，该请求中包含一个端口号。
2.目标系统通过重置(RST/ACK)响应源系统，因为该端口是关闭的。

```
maohao@maohao-HP-15-Notebook-PC:~$ nmap -sn 151.101.25.147

Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-09 13:05 CST
Nmap scan report for 151.101.25.147
Host is up (0.34s latency).
Nmap done: 1 IP address (1 host up) scanned in 0.36 seconds

```
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump host 151.101.25.147 
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
13:05:26.549629 IP bogon.56080 > 151.101.25.147.http: Flags [S], seq 968204811, win 29200, options [mss 1460,sackOK,TS val 3271111 ecr 0,nop,wscale 7], length 0
13:05:26.549770 IP bogon.52182 > 151.101.25.147.https: Flags [S], seq 1484533440, win 29200, options [mss 1460,sackOK,TS val 3271111 ecr 0,nop,wscale 7], length 0
13:05:26.893161 IP 151.101.25.147.http > bogon.56080: Flags [S.], seq 2265609368, ack 968204812, win 28560, options [mss 1300,sackOK,TS val 3449698472 ecr 3271111,nop,wscale 9], length 0
13:05:26.893269 IP bogon.56080 > 151.101.25.147.http: Flags [.], ack 1, win 229, options [nop,nop,TS val 3271197 ecr 3449698472], length 0
13:05:26.893325 IP 151.101.25.147.https > bogon.52182: Flags [S.], seq 429009821, ack 1484533441, win 28560, options [mss 1300,sackOK,TS val 3600872172 ecr 3271111,nop,wscale 9], length 0
13:05:26.893353 IP bogon.52182 > 151.101.25.147.https: Flags [.], ack 1, win 229, options [nop,nop,TS val 3271197 ecr 3600872172], length 0
13:05:26.893372 IP bogon.56080 > 151.101.25.147.http: Flags [R.], seq 1, ack 1, win 229, options [nop,nop,TS val 3271197 ecr 3449698472], length 0
13:05:26.893412 IP bogon.52182 > 151.101.25.147.https: Flags [R.], seq 1, ack 1, win 229, options [nop,nop,TS val 3271197 ecr 3600872172], length 
```
 When a privileged user tries to scan targets on a local ethernet network, ARP requests are used unless --send-ip was specified. 
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -sn 192.168.1.113
Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-09 13:07 CST
Nmap scan report for bogon (192.168.1.113)
Host is up (0.00026s latency).
MAC Address: 08:00:27:B3:5F:1E (Oracle VirtualBox virtual NIC)
Nmap done: 1 IP address (1 host up) scanned in 0.31 seconds
```
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump host 192.168.1.113
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
13:07:01.180567 ARP, Request who-has bogon tell bogon, length 28
13:07:01.180813 ARP, Reply bogon is-at 08:00:27:b3:5f:1e (oui Unknown), length 46
```
 The -sn option can be combined with any of the discovery probe types (the -P* options, excluding -Pn) for greater flexibility. If any of those probe type and port number options are used, the default probes are overridden. When strict firewalls are in place between the source host running Nmap and the target network, using those advanced techniques is recommended. Otherwise hosts could be missed when the firewall drops probes or their responses.

In previous releases of Nmap, -sn was known as -sP.
## -Pn (No ping)
This option skips the Nmap discovery stage altogether. Normally, Nmap uses this stage to determine active machines for heavier scanning. By default, Nmap only performs heavy probing such as port scans, version detection, or OS detection against hosts that are found to be up. Disabling host discovery with -Pn causes Nmap to attempt the requested scanning functions against every target IP address specified. So if a class B target address space (/16) is specified on the command line, all 65,536 IP addresses are scanned. Proper host discovery is skipped as with the list scan, but instead of stopping and printing the target list, Nmap continues to perform requested functions as if each target IP is active. To skip ping scan and port scan, while still allowing NSE to run, use the two options -Pn -sn together.
**目标主机某个端口未开启的情况下：**
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -Pn 192.168.1.113

Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-09 17:08 CST
Nmap scan report for bogon (192.168.1.113)
Host is up (0.0087s latency).
All 1000 scanned ports on bogon (192.168.1.113) are closed
MAC Address: 08:00:27:B3:5F:1E (Oracle VirtualBox virtual NIC)

Nmap done: 1 IP address (1 host up) scanned in 1.57 seconds

```
```
maohao@maohao-HP-15-Notebook-PC:~/文档/git/Sniffer-with-pcap$ sudo tcpdump host 192.168.1.113 and port 80
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
17:08:22.266733 IP bogon.38432 > bogon.http: Flags [S], seq 536201290, win 1024, options [mss 1460], length 0
17:08:22.268783 IP bogon.http > bogon.38432: Flags [R.], seq 0, ack 536201291, win 0, length 0
```
**目标主机某个端口开启的情况下：**
```
maohao@maohao-HP-15-Notebook-PC:~/文档/git/Sniffer-with-pcap$ sudo tcpdump host 192.168.1.106 and port 80
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
17:12:59.155833 IP bogon.52120 > bogon.http: Flags [S], seq 1923173049, win 1024, options [mss 1460], length 0
17:12:59.155858 IP bogon.http > bogon.52120: Flags [S.], seq 564188379, ack 1923173050, win 29200, options [mss 1460], length 0
17:12:59.156097 IP bogon.52120 > bogon.http: Flags [R], seq 1923173050, win 0, length 0
```
For machines on a local ethernet network, ARP scanning will still be performed (unless --disable-arp-ping or --send-ip is specified) because Nmap needs MAC addresses to further scan target hosts. In previous versions of Nmap, -Pn was -P0 and -PN.
## -PS <port list> (TCP SYN Ping)
This option sends an empty TCP packet with the SYN flag set. The default destination port is 80 (configurable at compile time by changing DEFAULT_TCP_PROBE_PORT_SPEC in nmap.h). Alternate ports can be specified as a parameter. The syntax is the same as for the -p except that port type specifiers like T: are not allowed. Examples are -PS22 and -PS22-25,80,113,1050,35000. Note that there can be no space between -PS and the port list. If multiple probes are specified they will be sent in parallel.

The SYN flag suggests to the remote system that you are attempting to establish a connection. Normally the destination port will be closed, and a RST (reset) packet sent back. If the port happens to be open, the target will take the second step of a TCP three-way-handshake by responding with a SYN/ACK TCP packet. The machine running Nmap then tears down the nascent connection by responding with a RST rather than sending an ACK packet which would complete the three-way-handshake and establish a full connection. The RST packet is sent by the kernel of the machine running Nmap in response to the unexpected SYN/ACK, not by Nmap itself.

Nmap does not care whether the port is open or closed. Either the RST/ACK or SYN/ACK response discussed previously tell Nmap that the host is available and responsive.

On Unix boxes, only the privileged user root is generally able to send and receive raw TCP packets. For unprivileged users, a workaround is automatically employed whereby the connect system call is initiated against each target port. This has the effect of sending a SYN packet to the target host, in an attempt to establish a connection. If connect returns with a quick success or an ECONNREFUSED failure, the underlying TCP stack must have received a SYN/ACK or RST and the host is marked available. If the connection attempt is left hanging until a timeout is reached, the host is marked as down. 
![](/images/asddd.png) 
```
17:30:22.103257 IP bogon.54269 > bogon.submission: Flags [S], seq 1703271590, win 1024, options [mss 1460], length 0
17:30:22.103328 IP bogon.submission > bogon.54269: Flags [R.], seq 0, ack 1703271591, win 0, length 0
17:30:22.104110 IP bogon.54269 > bogon.microsoft-ds: Flags [S], seq 1703271590, win 1024, options [mss 1460], length 0
17:30:22.104157 IP bogon.microsoft-ds > bogon.54269: Flags [R.], seq 0, ack 1703271591, win 0, length 0
17:30:22.104580 IP bogon.54269 > bogon.http: Flags [S], seq 1703271590, win 1024, options [mss 1460], length 0
17:30:22.104637 IP bogon.http > bogon.54269: Flags [S.], seq 2991689170, ack 1703271591, win 29200, options [mss 1460], length 0
17:30:22.104903 IP bogon.54269 > bogon.http: Flags [R], seq 1703271591, win 0, length 0
17:30:22.105144 IP bogon.54269 > bogon.telnet: Flags [S], seq 1703271590, win 1024, options [mss 1460], length 0
17:30:22.105188 IP bogon.telnet > bogon.54269: Flags [S.], seq 1858982626, ack 1703271591, win 29200, options [mss 1460], length 0
17:30:22.105504 IP bogon.54269 > bogon.telnet: Flags [R], seq 1703271591, win 0, length 0
17:30:22.105942 IP bogon.54269 > bogon.ftp: Flags [S], seq 1703271590, win 1024, options [mss 1460], length 0
17:30:22.105996 IP bogon.ftp > bogon.54269: Flags [R.], seq 0, ack 1703271591, win 0, length 0
```
如果目标主机的某个端口未打开
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -PS22 151.101.25.147

Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-09 17:53 CST
Note: Host seems down. If it is really up, but blocking our ping probes, try -Pn
Nmap done: 1 IP address (0 hosts up) scanned in 2.10 seconds
```
# Port Scanning Techniques
## -sS (TCP SYN scan)
SYN scan is the default and most popular scan option for good reasons. It can be performed quickly, scanning thousands of ports per second on a fast network not hampered by restrictive firewalls. It is also relatively unobtrusive and stealthy(相对低调和隐蔽)since it never completes TCP connections. SYN scan works against any compliant TCP stack rather than depending on idiosyncrasies of specific platforms as Nmap's FIN/NULL/Xmas, Maimon and idle scans do. It also allows clear, reliable differentiation between the open, closed, and filtered states.

This technique is often referred to as half-open scanning, because you don't open a full TCP connection. You send a SYN packet, as if you are going to open a real connection and then wait for a response. A SYN/ACK indicates the port is listening (open), while a RST (reset) is indicative of a non-listener. If no response is received after several retransmissions, the port is marked as filtered. The port is also marked filtered if an ICMP unreachable error (type 3, code 0, 1, 2, 3, 9, 10, or 13) is received. The port is also considered open if a SYN packet (without the ACK flag) is received in response. This can be due to an extremely rare TCP feature known as a simultaneous open or split handshake connection (see https://nmap.org/misc/split-handshake.pdf).
**这是一个基本的扫描方式,它被称为半开放扫描，因为这种技术使得Nmap不需要通过完整的握手，就能获得远程主机的信息。执行-sS需要privileged权限，因为-sS扫描不会像操作系统进行tcp连接时建立完整会话，nmap需要权限自行构造syn包进行扫描**
**If a scan type is not specified, and has privileged access, the TCP SYN scan is used by default.**
所以`maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap 192.168.1.113`和`maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -sS 192.168.1.113`具有相同的效果．
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap 192.168.1.113
Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-10 19:29 CST
Nmap scan report for bogon (192.168.1.113)
Host is up (0.0069s latency).
Not shown: 999 closed ports
PORT   STATE SERVICE
22/tcp open  ssh
MAC Address: 08:00:27:B3:5F:1E (Oracle VirtualBox virtual NIC)
Nmap done: 1 IP address (1 host up) scanned in 1.55 seconds
```
目标服务器开启了ssh服务：A SYN/ACK indicates the port is listening (open)
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump port 22
[sudo] maohao 的密码： 
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
19:40:10.433081 IP bogon.64701 > bogon.ssh: Flags [S], seq 996631261, win 1024, options [mss 1460], length 0
19:40:10.434739 IP bogon.ssh > bogon.64701: Flags [S.], seq 230762162, ack 996631262, win 29200, options [mss 1460], length 0
19:40:10.434784 IP bogon.64701 > bogon.ssh: Flags [R], seq 996631262, win 0, length 0
```
目标服务器没有开启https服务：a RST (reset) is indicative of a non-listener（closed）
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump port 443
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
19:40:43.975405 IP bogon.58792 > bogon.https: Flags [S], seq 4256481083, win 1024, options [mss 1460], length 0
19:40:43.976092 IP bogon.https > bogon.58792: Flags [R.], seq 0, ack 4256481084, win 0, length 0
```
在目标主机中通过命令`ipatbles -A INPUT -p tcp -dport 80 -j DROP`，过滤80端口．If no response is received after several retransmissions, the port is marked as filtered. 
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap 192.168.1.113
Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-10 19:45 CST
Nmap scan report for bogon (192.168.1.113)
Host is up (0.014s latency).
Not shown: 998 closed ports
PORT   STATE    SERVICE
22/tcp open     ssh
80/tcp filtered http
MAC Address: 08:00:27:B3:5F:1E (Oracle VirtualBox virtual NIC)
```
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo tcpdump port 80
tcpdump: verbose output suppressed, use -v or -vv for full protocol decode
listening on wlp3s0, link-type EN10MB (Ethernet), capture size 262144 bytes
19:45:14.440949 IP bogon.54201 > bogon.http: Flags [S], seq 81505599, win 1024, options [mss 1460], length 0
19:45:14.542337 IP bogon.54202 > bogon.http: Flags [S], seq 81440062, win 1024, options [mss 1460], length 0
```
**Advantages** 
-sS never actually creates a TCP session, so it’s not logged by the destination
**Disadvantage**
Requires nmap have privileged access to the system
**When to use the TCP SYN Scan**
-sS works on all systems
It is a clean scan type
It provides *open*, *closed*, *filterd* port information
**-sS只能探测出三种结果：open, closed, filterd**
## -sT (TCP connect scan)
**TCP connect scan is the default TCP scan type when SYN scan is not an option. This is the case when a user does not have raw packet privileges.** Instead of writing raw packets as most other scan types do, Nmap asks the underlying operating system to establish a connection with the target machine and port by issuing the connect system call. This is the same high-level system call that web browsers, P2P clients, and most other network-enabled applications use to establish a connection. It is part of a programming interface known as the Berkeley Sockets API. Rather than read raw packet responses off the wire, Nmap uses this API to obtain status information on each connection attempt.

When SYN scan is available, it is usually a better choice. Nmap has less control over the high level connect call than with raw packets, making it less efficient. The system call completes connections to open target ports rather than performing the half-open reset that SYN scan does. Not only does this take longer and require more packets to obtain the same information, but target machines are more likely to log the connection. A decent IDS will catch either, but most machines have no such alarm system. Many services on your average Unix system will add a note to syslog, and sometimes a cryptic error message, when Nmap connects and then closes the connection without sending data. Truly pathetic services crash when this happens, though that is uncommon. An administrator who sees a bunch of connection attempts in her logs from a single system should know that she has been connect scanned.
**Tcp connect() scan (sT)和上面的Tcp SYN 对应，TCP connect()扫描就是默认的扫描模式.不同于Tcp SYN扫描,Tcp connect()扫描需要完成三次握手,并且要求调用系统的connect().**
**Advantage**
No special privileges are required**(nmap -sT 10.0.1.161等同于 nmap 10.0.1.161)**
**Disadvantage**
The scan will be logged by the target system,由于它要完成3次握手，效率低，速度慢
**When to use**
It is the last resort
**-sS是nmap在root权限下的默认执行方式，-sT是nmap在非root权限下的默认执行方式．**
## -sA (TCP ACK scan) 
This scan is different than the others discussed so far in that it never determines open (or even open|filtered) ports. It is used to map out firewall rulesets, determining whether they are stateful or not and which ports are filtered.

The ACK scan probe packet has only the ACK flag set (unless you use --scanflags). When scanning unfiltered systems, **open and closed ports will both return a RST packet**. Nmap then labels them as unfiltered, meaning that they are reachable by the ACK packet, but whether they are open or closed is undetermined. Ports that don't respond, or send certain ICMP error messages back (type 3, code 0, 1, 2, 3, 9, 10, or 13), are labeled filtered.
**同-sS一样，-sA也需要sudo权限**
```
maohao@maohao-HP-15-Notebook-PC:~$ sudo nmap -sA 192.168.1.113
Starting Nmap 7.01 ( https://nmap.org ) at 2017-10-10 20:26 CST
Nmap scan report for bogon (192.168.1.113)
Host is up (0.00055s latency).
Not shown: 999 unfiltered ports
PORT   STATE    SERVICE
80/tcp filtered http
MAC Address: 08:00:27:B3:5F:1E (Oracle VirtualBox virtual NIC)
Nmap done: 1 IP address (1 host up) scanned in 87.18 seconds
```
**It only provides “filtered” or “unfiltered” disposition**
**Advantages**
It doesn’t open any application sessions, the conversation is simple
**Disadvantage**
Can’t confirm an open port
**When to use**
To identify whether the traffic can go through a firewall
## Stealth Scanning
When scanning systems compliant with this RFC text, any packet not containing SYN, RST, or ACK bits will result in a returned RST if the port is closed and no response at all if the port is open. As long as none of those three bits are included, any combination of the other three (FIN, PSH, and URG) are OK. Nmap exploits this with three scan types:
**Null scan (-sN)**
    Does not set any bits (TCP flag header is 0)
**FIN scan (-sF)**
    Sets just the TCP FIN bit.
**Xmas scan (-sX)**
    Sets the FIN, PSH, and URG flags, lighting the packet up like a Christmas tree.

These three scan types are exactly the same in behavior except for the TCP flags set in probe packets. **If a RST packet is received, the port is considered closed, while no response means it is open|filtered.** 
![](/images/nmap-sf.png) 
![](/images/sf-capture.png) 
所以可以通过-sA和-sF联合判断端口状态
## -sI(IDLE Scan)空闲扫描
为了降低被检测到的机率，我们通常需要转嫁责任，这时可以使用空闲扫描（idle scan），让一个僵尸主机承担扫描任务。
理论基础：
a. 每个IP包都有帧ID，记作IP ID
b. TCP正常建立链接的时候，第一步是主机A从端口X发给主机B端口Y一个 SYN，第二步是B回应A一个SYN/ACK，第三步是A回B一个ACK，连接建立了。如果A没有发给B一个SYN，而B发给A了一个SYN/ACK，那么A就会发给B一个RST
c. 大部分主机的TCP/IP协议实现中，RST中的IP ID是递增的，增加的单位是1，即incremental

**Step 1**
找到一台空闲主机，并从攻击主机发给空闲主机一个SYN/ACK，获得并记录空闲主机的RST的IP ID
**Step2**
在攻击者的主机上虚构一个从空闲主机到目标主机的一个SYN，于是根据目标主机的目标端口状态，如果目标主机的目标端口打开，将会发给空闲主机的一个SYN/ACK，所以空闲主机将会发给目标主机一个RST，否则不会发送RST
**Step3**
再次从攻击主机发给空闲主机SYN/ACK，检查RST的IP ID，如果IP ID比第一步记录下的增加了二，则说明第二步中空闲主机给目标主机发送了一个RST，目标主机的目标端口处于打开状态，否则为没打开.
目标机端口开放
![](/images/idle-scan-open.png)
目标机端口关闭 
![](/images/idle-scan-closed.png)
目标机端口被过滤 
![](/images/idle-scan-filtered.png) 
**由图可知，目标机端口被过滤和关闭的情况下得到的RST一样，所以IDLE扫描只能判断出端口有没有开放。**