---
title: 对称博弈(coin game)
date: 2016-04-19 16:39:13
categories: 博弈论
tags:
- 博弈论
- 算法
- 对称博弈
- coin-game
copyright: true
---
# Problem Description
After hh has learned how to play Nim game, he begins to try another coin game which seems much easier.
![](/images/博弈论.png) 
 <!--more-->
## The game goes like this:
 Two players start the game with a circle of n coins.They take coins from the circle in turn and every time they could take 1~K continuous coins.(imagining that ten coins numbered from 1 to 10 and K equal to 3, since 1 and 10 are continuous, you could take away the continuous 10 , 1 , 2 , but if 2 was taken away, you couldn’t take 1, 3, 4, because 1 and 3 aren’t continuous)The player who takes the last coin wins the game.Suppose that those two players always take the best moves and never make mistakes.
Your job is to find out who will definitely win the game. 
## Input
The first line is a number T(1<=T<=100), represents the number of case. The next T blocks follow each indicates a case.Each case contains two integers N(3<=N<=109,1<=K<=10). 
## Output
For each case, output the number of case and the winner “first” or “second”.(as shown in the sample output) 
## Sample Input
2
3 1
3 2
## Sample Output
Case 1: first
Case 2: second
# 思路
1）若k=1,则一次只能去翻一枚，奇数先手赢，偶数后手赢。
2）若k>1:
a: 先手能一次翻完，先手赢；
b: 先手不能翻完，第一次必定断环。只要后手一次翻完，或将其分为相等数量的两段(后手只需要将这个L拿走中间的1~2个, 剩下的就是一模一样的两个不相邻的链)，之后先手怎么操作后手就怎么操作，后手必赢。
# 代码
```c
int main()
{
    int t,n,k,i;
    cin>>t;
    for(i=1;i<=t;i++) 
    {
        cin>>n>>k;
        if(k==1)
        {
             if(n%2==1)
             {
                   cout<<"Case "<<i<<": first"<<endl;
             }
        else
         {
　          cout<<"Case "<<i<<": second"<<endl;
         }
      }
     else
     {
          if(k>=n)
          {
                cout<<"Case "<<i<<": first"<<endl;
          }
          else
           {
               cout<<"Case "<<i<<": second"<<endl;
           }
      }
   }
  return 0;
}
```
