---
title: Linux用户和用户权限
date: 2017-10-24 19:46:36
categories:	Linux
tags:
copyright:
---
# ls -l
```shell
maohao@maohao-HP-15-Notebook-PC:~$ ls -l
总用量 72
-rw-rw-r-- 1 maohao maohao   34 10月 22 19:53 0
drwxrwxr-x 5 maohao maohao 4096 9月  30 11:29 app
-rw-r--r-- 1 maohao maohao 8980 1月   1  2017 examples.desktop
```
第一列为文件种类及权限。此列共有10个字符，其中第一个字符表示文件的种类。即：
```
   - 普通文件
   b 块特殊文件
   c 字符特殊文件
   d 目录
   l 连接
   p 命名管道（FIFO）
```
<!--mroe-->
而紧跟其后的10个字符，可以分为3块，每3个字符为一块，表示了**此文件（目录）的拥有者**、**拥有者所属组**及**others**的权限。其中，r表示read，w表示write，x表示execute，-表示无权限。

第二列表示硬链接个数（文件每增加一个硬链接，数字会增加1，默认从1开始，1表示无硬链接文件，如果是一个目录，它的默认值应该是2。目录是不能做硬链接的）。

第三列为文件（目录）的拥有者。

第四列为文件（目录）的拥有者所属组。

第五列为文件（目录）的大小，单为为字节。

第六列为文件（目录）创建时间或最后一次访问时间，顺序为月、日、时间，如果该时间离现在过久，则直接显示年份。

第七列为文件名。
# chmod命令
使用方式 : `chmod [-cfvR] [--help] [--version] mode file...`
参数 :
```
-c : 若该档案权限确实已经更改，才显示其更改动作
-f : 若该档案权限无法被更改也不要显示错误讯息
-v : 显示权限变更的详细资料
-R : 对目前目录下的所有档案与子目录进行相同的权限变更(即以递回的方式逐个变更)
--help : 显示辅助说明
--version : 显示版本
```
mode : 权限设定字串，格式如下 : [ugoa...][[+-=][rwxX]...][,...]，其中
u 表示该档案的拥有者，g 表示与该档案的拥有者属于同一个群体(group)者，o 表示其他以外的人，a 表示这三者皆是。
+ 表示增加权限、- 表示取消权限、= 表示唯一设定权限。
r 表示可读取，w 表示可写入，x 表示可执行，X 表示只有当该档案是个子目录或者该档案已经被设定过为可执行。
**范例**
将档案 file1.txt 设为所有人皆可读取 :`chmod ugo+r file1.txt `
将档案 file1.txt 设为所有人皆可读取 :`chmod a+r file1.txt `
将档案 file1.txt 与 file2.txt 设为该档案拥有者，与其所属同一个群体者可写入，但其他以外的人则不可写入 :`chmod ug+w,o-w file1.txt file2.txt `
将 ex1.py 设定为只有该档案拥有者可以执行 :`chmod u+x ex1.py `
将目前目录下的所有档案与子目录皆设为任何人可读取 :`chmod -R a+r * `
**此外chmod也可以用数字来表示**
语法为：`chmod abc file`
其中a,b,c各为一个数字，分别表示User、Group、及Other的权限。
r=4，w=2，x=1
若要rwx属性则4+2+1=7；
若要rw-属性则4+2=6；
若要r-x属性则4+1=7。
**范例**
`chmod a=rwx file `和`chmod 777 file `效果相同
`chmod ug=rwx,o=x file `和`chmod 771 file `效果相同 

# 用户用户组
 whoami查看用户标识
 groups查看所属用户组 
```
maohao@maohao-HP-15-Notebook-PC:/etc$ whoami
maohao
maohao@maohao-HP-15-Notebook-PC:/etc$ groups
maohao adm cdrom sudo dip plugdev lpadmin sambashare
```
```
/etc/passwd	用户相关信息
/etc/shadow	用户安全相关信息，包括密码
/etc/group		组相关信息
/etc/gshadow	组安全相关信息，包括密码
```
## 用户和用户组文件
在linux中，用户帐号，用户密码，用户组信息和用户组密码均是存放在不同的配置文件中的。
**在linux系统中，所创建的用户帐号和其相关信息(密码除外)均是存放在/etc/passwd配置文件中。由于所有用户对passwd文件均有读取的权限，因此密码信息并未保存在该文件中，而是保存在了/etc/shadow的配置文件中。**
在passwd文件中，一行定义一个用户帐号，每行均由多个不同的字段构成，各字段值间用":”分隔，每个字段均代表该帐号某方面的信息。
在刚安装完成的linux系统中，passwd配置文件已有很多帐号信息了，这些帐号是由系统自动创建的，他们是linux进程或部分服务程序正常工作所需要使用的账户，这些账户的最后一个字段的值一般为/sbin/nologin，表示该帐号不能用来登录linux系统。
在passwd配置文件中，从左至右各字段的对应关系及其含义：
```
用户帐号    用户密码    用户ID    用户组ID    用户名全称    用户主目录    用户所使用的shell
root            x                  0             0                root              /root                /bin/bash
```
**由于passwd不再保存密码信息，所以用x占位代表。**
若要使某个用户账户不能登录linux，只需设置该用户所使用的shell为/sbin/nologin即可。比如，对于FTP 账户，一般只允许登录和访问FTP服务器，不允许登录linux操作系统。若要让某用户没有telnet权限，即不允许该用户利用telnet远程登录和访问linux操作系统，则设置该用户所使用的shell为/bin/true即可。若要让用户没有telnet和ftp登录权限，则可设置该用户的 shell为/bin/false。
在/etc/shells文件中，若没有/bin/true或/bin/false，则需要手动添加：
[root@localhost ～]# echo "/bin/false">>/etc/shells
[root@localhost ～]# echo "/bin/true">>/etc/shells

## 用户密码文件
为安全起见，用户真实的密码采用MD5加密算法加密后，保存在/etc/shadow配置文件中，该文件只有root用户可以读取。
与passwd文件类似，shadow文件也是每行定义和保存一个账户的相关信息。第一个字段为用户帐户名，第二个字段为账户的密码。
```
maohao@maohao-HP-15-Notebook-PC:/etc$ sudo cat shadow | grep maohao
maohao:$6$bdJ2jAJ7$ORApbvsRVlKS/e3Arl/uLJhJxKY0bJszOCAKuwC5E0tmIR2Whn01YgbxF1yNLTEb.PTZ7cmny1CDDfUvHbil3/:17167:0:99999:7:::
```
## 用户组帐号文件
用户组帐号信息保存在/etc/group配置文件中，任何用户均可以读取。用户组的真实密码保存在/etc/gshadow配置文件中。
在group中，第一个字段代表用户组的名称，第二个字段为x，第三个为用户组的ID号，第四个为该用户组的用户成员列表，各用户名间用逗号分隔。
```shell
maohao@maohao-HP-15-Notebook-PC:/etc$ cat /etc/group | grep maohao
adm:x:4:syslog,maohao
cdrom:x:24:maohao
sudo:x:27:maohao
dip:x:30:maohao
plugdev:x:46:maohao
lpadmin:x:113:maohao
maohao:x:1000:
sambashare:x:128:maohao
```
id 命令可以显示真实有效的用户 ID(UID) 和组 ID(GID)。UID 是对一个用户的单一身份标识。组 ID（GID）则对应多个UID。
```
maohao@maohao-HP-15-Notebook-PC:/etc$ id
uid=1000(maohao) gid=1000(maohao) 组=1000(maohao),4(adm),24(cdrom),27(sudo),30(dip),46(plugdev),113(lpadmin),128(sambashare)
```
```
用户 pungki 的 UID 号码= 1000, GID 号码= 1000
用户 pungki 是下面的组成员 :
    pungki 的 GID 号码= 1000
    adm 的 GID 号码= 4
    cdrom 的 GID 号码= 24
    sudo 的 GID 号码= 27
    dip 的 GID 号码= 30
    plugdev 的 GID 号码= 46
    lpadmin 的 GID 号码= 108
    sambashare 的 GID 号码= 124
```
```
root@maohao-HP-15-Notebook-PC:/etc# id
uid=0(root) gid=0(root) 组=0(root)
```
**root的用户id为０，普通用户maohao的用户id为1000.**
# setuid
在Linux系统中每个普通用户都可以更改自己的密码，这是合理的设置。
问题是：用户的信息保存在文件/etc/passwd中，用户的密码保存在文件/etc/shadow中，也就是说用户更改自己密码时是修改了/etc/shadow文件中的加密密码，但是，
```shell
maohao@maohao-HP-15-Notebook-PC:/etc$ ll passwd
-rw-r--r-- 1 root root 2792 9月  23 23:10 passwd
maohao@maohao-HP-15-Notebook-PC:/etc$ ll shadow
-rw-r----- 1 root shadow 1615 10月 10 06:08 shadow
```
/etc/passwd文件每个用户都有读权限但是只有root有写权限，/etc/shadow文件只有超级用户root有读写权限，也就是说普通用户对这两个文件都没有写权限无法写入新密码，为什么普通用户可以更改密码呢？
其实，用户能更改密码真正的秘密不在于文件的权限，而在于更改密码的命令passwd 。
```
maohao@maohao-HP-15-Notebook-PC:/etc$ ls -l /usr/bin/passwd
-rwsr-xr-x 1 root root 54256 5月  17 07:37 /usr/bin/passwd
```
passwd命令有一个特殊的权限标记s ，存在于文件所有者的权限位上。这是一类特殊的权限SetUID ，可以这样来理解它：**当一个具有执行权限的文件设置SetUID权限后，用户执行这个文件时将以文件所有者的身份执行。**passwd命令具有SetUID权限，所有者为root（Linux中的命令默认所有者都是root），也就是说当普通用户使用passwd更改自己密码的时候，那一瞬间突然灵魂附体了，实际在以passwd命令所有者root的身份在执行，root当然可以将密码写入/etc/shadow文件（不要忘记root这个家伙是superuser什么事都可以干），命令执行完成后该身份也随之消失。
## 案例
为便于深入理解SetUID ，笔者以touch命令为例做一演示。
普通用户samlee用touch创建文件1.txt ：
```
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ touch 1.txt
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ ls -l | grep 1.txt
-rw-rw-r-- 1 maohao maohao     0 10月 24 21:57 1.txt
```
文件的创建者默认就是所有者，所以文件1.txt的所有者为maohao 。
管理员root给touch命令添加SetUID权限：
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ sudo chmod 4764 /bin/touch
[sudo] maohao 的密码： 
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ ll /bin/touch
-rwsrw-r-- 1 root root 64432 3月   3  2017 /bin/touch*
再用普通用户maohao创建文件2.txt，看到如下结果：
```
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ touch 2.txt
bash: /usr/bin/touch: 权限不够
```
因为maohao并没有执行权限
```
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ sudo chmod 4755 /bin/touch
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ ll /bin/touch
-rwsr-xr-x 1 root root 64432 3月   3  2017 /bin/touch*
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ touch 3.txt
maohao@maohao-HP-15-Notebook-PC:~/文档/脚本$ ls -l | grep 3.txt
-rw-rw-r-- 1 root   maohao     0 10月 24 22:05 3.txt
```
通过这个例子，我们可以再诠释下SetUID的定义，当一个可执行文件（命令touch）设置SetUID权限后，当普通用户maohao执行touch创建新文件时，实际上是以touch命令所有者root的身份在执行此操作，既然是以root身份执行，当然新建文件的所有者为root ，这就是SetUID的作用。

 
# getuid、geteuid
```c
#include <unistd.h>
#include <sys/types.h>
main()
{
    printf("real id is %d, effective id is %d\n", getuid(),geteuid());
}
```