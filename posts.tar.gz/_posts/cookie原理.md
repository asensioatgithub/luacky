---
title: cookie原理
date: 2017-12-11 21:54:55
categories: WEB安全
tags:
- cookie
- session
copyright:
---
Cookie与Session是常用的会话跟踪技术。
**会话**，指用户登录网站后的一系列动作，比如浏览商品添加到购物车并购买。会话（Session）跟踪是Web程序中常用的技术，用来跟踪用户的整个会话。Cookie通过在客户端记录信息确定用户身份，Session通过在服务器端记录信息确定用户身份。
# cookie
## cookie定义
根据 Netscape cookie 草案的描述，Cookie 是 Web 服务器向用户的浏览器发送的一段 ASCII 码文本。创建 Cookie 的最初目的是想让 Web 服务器能够通过多个 HTTP 请求追踪客户。有些复杂的网络应用需要在不同的网页之间保持一致，因为HTTP协议是一种无状态协议，在数据交换完毕后，服务器端和客户端的链接就会关闭，每次交换数据都需要建立新的链接，引入cookie机制，用户就可以自由浏览这个网站的任意页面，弥补HTTP无状态协议的不足。浏览器会把 Cookie 的信息片断以"名 / 值"对 (name-value pairs) 的形式储存保存在本地，这以后，每当向同一个 Web 服务器请求一个新的文档时，Web 浏览器都会发送之站点以前存储在本地的 Cookie。
<!--more-->
## cookie的分类
两种类型的Cookie：
### 会话Cookie
不设置过期时间，则表示这个cookie生命周期为浏览器会话期间，只要关闭浏览器窗口，cookie就消失了。这种生命期为浏览会话期的cookie被称为会话cookie。会话cookie一般不保存在硬盘上而是保存在内存里。
### 持久Cookie
设置了过期时间，浏览器就会把cookie保存到硬盘上，关闭后再次打开浏览器，这些cookie依然有效直到超过设定的过期时间。
存储在硬盘上的cookie可以在不同的浏览器进程间共享，比如两个IE窗口。而对于保存在内存的cookie，不同的浏览器有不同的处理方式。

## Cookie常用属性
```c
String name
	该Cookie的名称。Cookie一旦创建，名称便不可更改
Object value
	该Cookie的值。如果值为Unicode字符，需要为字符编码。如果值为二进制数据，则需要使用BASE64编码
int maxAge
	该Cookie失效的时间，单位秒。如果为正数，则该Cookie在maxAge秒之后失效。如果为负数，该Cookie
	为临时Cookie，关闭浏览器即失效，浏览器也不会以任何形式保存该Cookie。如果为0，表示删除该Cookie。
	默认为–1
boolean secure
	该Cookie是否仅被使用安全协议传输。当设置为true时，表示创建的Cookie 会被以安全的形式向服务器传输，也就是只能在 HTTPS 连接中被浏览器传递到服务器端进行会话验证，如果是 HTTP 连接则不会传递该信息，所以不会被窃取到Cookie 的具体内容。。默认为false
String path
	该Cookie的在服务器中的使用路径，默认的路径值是 cookie 所处的当前目录。如果设置为“/sessionWeb/”，则只有contextPath为“/sessionWeb”的程序可以
	访问该Cookie。如果设置为“/”，则本域名下contextPath都可以访问该Cookie。注意最后一个字符必须为“/”
String domain
	可以访问该Cookie的域名。如果设置为“.google.com”，则所有以“google.com”结尾的域名都可以访问
	该Cookie。注意第一个字符必须为“.”
String comment
	该Cookie的用处说明。浏览器显示Cookie信息的时候显示该说明
int version
	该Cookie使用的版本号。0表示遵循Netscape的Cookie规范，1表示遵循W3C的RFC 2109规范
```
## Cookie的有效期
Cookie的maxAge决定着Cookie的有效期，单位为秒（Second）。Cookie中通过getMaxAge()方法与setMaxAge(int maxAge)方法来读写maxAge属性。
如果maxAge属性为正数，则表示该Cookie会在maxAge秒之后自动失效。浏览器会将maxAge为正数的Cookie持久化，即写到对应的Cookie文件中。无论客户关闭了浏览器还是电脑，只要还在maxAge秒之前，登录网站时该Cookie仍然有效。下面代码中的Cookie信息将永远有效。
```javascript
Cookie cookie = new Cookie("username","helloweenvsfei");   // 新建Cookie
cookie.setMaxAge(Integer.MAX_VALUE);           // 设置生命周期为MAX_VALUE
response.addCookie(cookie);                    // 输出到客户端
```
如果maxAge为负数，则表示该Cookie仅在本浏览器窗口以及本窗口打开的子窗口内有效，关闭窗口后该Cookie即失效。maxAge为负数的Cookie，为临时性Cookie，不会被持久化，不会被写到Cookie文件中。Cookie信息保存在浏览器内存中，因此关闭浏览器该Cookie就消失了。Cookie默认的maxAge值为–1。
如果maxAge为0，则表示删除该Cookie。Cookie机制没有提供删除Cookie的方法，因此通过设置该Cookie即时失效实现删除Cookie的效果。失效的Cookie会被浏览器从Cookie文件或者内存中删除，
例如：
```javascript
Cookie cookie = new Cookie("username","helloworld");   // 新建Cookie
cookie.setMaxAge(0);                          // 设置生命周期为0，不能为负数
response.addCookie(cookie);                    // 必须执行这一句
```
response对象提供的Cookie操作方法只有一个添加操作addCookie(Cookie cookie)。
**注意：
1.要想修改Cookie只能新建一个cookie来覆盖原来的Cookie，达到修改的目的。删除时只需要把maxAge修改为0即可。
2.修改、删除Cookie时，新建的Cookie除value、maxAge之外的所有属性，例如name、path、domain等，都要与原Cookie完全一样。否则，浏览器将视为两个不同的Cookie不予覆盖，导致修改、删除失败。
3.从客户端读取Cookie时，包括maxAge在内的其他属性都是不可读的，也不会被提交。浏览器提交Cookie时只会提交name与value属性。maxAge属性只被浏览器用来判断Cookie是否过期。**

## Cookie的路径
cookie虽然是由一个网页所创建，但并不只是创建cookie的网页才能读取该cookie。在默认情况下，与创建cookie的网页在同一目录或子目录下的所有网页都可以读取该cookie。如：
在同一个服务器上有目录如下：/test/,/test/cd/,/test/dd/，现设一个cookie1的path为/test/，cookie2的path为/test/cd/，那么test下的所有页面都可以访问到cookie1，而/test/和/test/dd/的子页面不能访问cookie2。这是因为cookie能让其path路径下的页面访问。
 如果要使cookie在整个网站下可用，可以将cookieDir指定为根目录，示例如下：
document.cookie="userId=320; path=/";
## Cookie的不可跨域名性
很多网站都会使用Cookie。例如，Google会向客户端颁发Cookie，Baidu也会向客户端颁发Cookie。那浏览器访问Google会不会也携带上Baidu颁发的Cookie呢？或者Google能不能修改Baidu颁发的Cookie呢？

答案是否定的。Cookie具有不可跨域名性，根据Cookie规范，浏览器访问Google只会携带Google的Cookie，而不会携带Baidu的Cookie。Google也只能操作Google的Cookie，而不能操作Baidu的Cookie。这是由**Cookie的隐私安全机制**决定的，**隐私安全机制能够禁止网站非法获取其他网站的Cookie。**
Cookie在客户端是由浏览器来管理的。浏览器能够保证Google只会操作Google的Cookie而不会操作 Baidu的Cookie，从而保证用户的隐私安全。浏览器判断一个网站是否能操作另一个网站Cookie的依据是域名。Google与Baidu的域名 不一样，因此Google不能操作Baidu的Cookie。

## Cookie的作用域
domain的设置，有两点要注意：
1.在setcookie中省略domain参数，那么domain默认为当前域名。
2.domain参数可以设置父域名以及自身，但不能设置其它域名，包括子域名，否则cookie不起作用。
需要注意的是，正常情况下，同一个一级域名(父域名)下的两个二级域名(子域名)如www.helloworld.com和images.helloworld.com也不能交互使用Cookie，因为二者的域名并不严格相同。如果想所有helloworld.com名下的二级域名都可以使用该Cookie，需要设置Cookie的domain参数，例如：
```javascript
Cookie cookie = new Cookie("time","20080808"); // 新建Cookie
cookie.setDomain(".helloworld.com");           // 设置域名
cookie.setPath("/");                              // 设置路径
cookie.setMaxAge(Integer.MAX_VALUE);               // 设置有效期
response.addCookie(cookie);                       // 输出到客户端
```
那么cookie的作用域：
**cookie的作用域是domain本身以及domain下的所有子域名。**
**注意：domain参数必须以点(".")开始。另外，name相同但domain不同的两个Cookie是两个不同的Cookie。**
# session
Session:在计算机中，尤其是在网络应用中，称为“会话控制”。Session 对象存储特定用户会话所需的属性及配置信息。这样，当用户在应用程序的 Web 页之间跳转时，存储在 Session 对象中的变量将不会丢失，而是在整个用户会话中一直存在下去。当用户请求来自应用程序的 Web 页时，如果该用户还没有会话，则 Web 服务器将自动创建一个 Session 对象。当会话过期或被放弃后，服务器将终止该会话。Session 对象最常见的一个用法就是存储用户的首选项。例如，如果用户指明不喜欢查看图形，就可以将该信息存储在 Session 对象中。
# cookie与session的联系与区别
## cookis与session的联系
当程序需要为某个客户端的请求创建一个session时，服务器首先检查这个客户端的请求里是否已包含了一个session标识（称为session id），如果已包含则说明以前已经为此客户端创建过session，服务器就按照session id把这个session检索出来使用（检索不到，会新建一个），如果客户端请求不包含session id，则为此客户端创建一个session并且生成一个与此session相关联的session id，session id的值应该是一个既不会重复，又不容易被找到规律以仿造的字符串，这个session id将被在本次响应中返回给客户端保存。保存这个session id的方式可以采用cookie，这样在交互过程中浏览器可以自动的按照规则把这个标识发送给服务器。一般这个cookie的名字都是类似于SEEESIONID。

但cookie可以被人为的禁止，则必须有其他机制以便在cookie被禁止时仍然能够把session id传递回服务器。经常被使用的一种技术叫做**URL重写**，就是把session id直接附加在URL路径的后面。还有一种技术叫做**表单隐藏字段**。就是服务器
会自动修改表单，添加一个隐藏字段，以便在表单提交时能够把session id传递回服务器。比如：
```
<form name="testform" action="/xxx">
<input type="hidden" name="jsessionid" value="ByOK3vjFD75aPnrF7C2HmdnV6QZcEbzWoWiBYEnLerjQ99zWpBng!-145788764">
<input type="text">
</form>
```
实际上这种技术可以简单的用对action应用URL重写来代替。

## cookie 和session 的区别
1、cookie数据存放在客户的浏览器上，session数据放在服务器上。
2、cookie不是很安全，别人可以分析存放在本地的COOKIE并进行COOKIE欺骗
   考虑到安全应当使用session。
3、session会在一定时间内保存在服务器上。当访问增多，会比较占用你服务器的性能，考虑到减轻服务器性能方面，应当使用COOKIE。
4、单个cookie保存的数据不能超过4K，很多浏览器都限制一个站点最多保存20个cookie。
5、将登陆信息等重要信息存放为SESSION，其他信息如果需要保留，可以放在COOKIE中

