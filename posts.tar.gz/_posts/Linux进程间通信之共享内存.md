---
title: Linux进程间通信之共享内存
date: 2018-02-08 21:17:58
categories: Linux
tags:
copyright:
---
转自：[http://blog.csdn.net/xiejingfa/article/details/50888870](http://blog.csdn.net/xiejingfa/article/details/50888870) 
# 什么是共享内存
顾名思义，共享内存就是两个（或多个）进程共同占有一段内存空间，这些进程可以是有亲缘关系的进程，也可以是完全不相关的进程。同一块物理内存空间被映射到两个进程，两个进程都可以访问这段共享空间从而实现了进程间通信。但是值得注意的是：Linux的共享内存通信只提供了数据交换功能，并没有提供同步机制，需要使用其它机制来同步不同进程对共享内存的读写操作（如信号量）。
<!--more-->
在Linux下，使用`ipcs -m`可以查看系统中共享内存的使用情况。下面是我在自己电脑中使用该命令的结果：
~~~c
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ipcs -m

------------ 共享内存段 --------------
键        shmid      拥有者  权限     字节     连接数  状态 
0x00000000 655360     maohao     600        16777216   2
0x00000000 819201     maohao     600        524288     2          目标
0x00000000 1474562    maohao     600        4194304    2          目标 
0x00000000 950275     maohao     600        67108864   2          目标
0x00000000 1671172    maohao     600        16384      2          目标
0x00000000 1703941    maohao     600        16384      2          目标
0x00000000 1638406    maohao     600        7827456    2          目标
0x00000000 1605639    maohao     600        7827456    2          目标
0x00000000 4325384    maohao     600        524288     2          目标
0x00000000 3899401    maohao     700        149996     2          目标
0x00000000 3047434    maohao     600        57344      2          目标
~~~
对于每一个共享内存，内核会为其定义一个shmid_ds结构体类型。shmid_ds结构体定义在头文件`<sys/shm.h>`中。
~~~c
struct shmid_ds{
      struct ipc_perm shm_perm;/* 操作权限*/
      int shm_segsz;                    /*段的大小（以字节为单位）*/
      time_t shm_atime;          /*最后一个进程附加到该段的时间*/
      time_t shm_dtime;          /*最后一个进程离开该段的时间*/
      time_t shm_ctime;          /*最后一个进程修改该段的时间*/
      unsigned short shm_cpid;   /*创建该段进程的pid*/
      unsigned short shm_lpid;   /*在该段上操作的最后1个进程的pid*/
      short shm_nattch;          /*当前附加到该段的进程的个数*/
/*下面是私有的*/
      unsigned short shm_npages;  /*段的大小（以页为单位）*/
      unsigned long *shm_pages;   /*指向frames->SHMMAX的指针数组*/
      struct vm_area_struct *attaches; /*对共享段的描述*/
}; 
~~~
# 共享内存的相关操作
关于共享内存的操作，主要有shmget、shmat、shmdt、shmctl四个函数，它们都定义在<sys/shm.h>头文件中。下面我们分别介绍一下这几个函数。
## 创建或打开共享内存
我们知道，在Linux中创建或打开一个文件都可以使用open函数。与此类似，shmget调用也可以用来创建或打开一个共享内存区域。原型如下：
~~~c
#include <sys/ipc.h>
#include <sys/shm.h>
int shmget(key_t key, size_t size, int shmflg);
~~~
若成功则返回共享内存的ID标识，否则返回-1。各个参数的含义如下：
**参数key**
参数key表示所要创建或打开的共享内存的键值。无论何时创建一个IPC对象（如调用shmget），都需要指定一个key，它的数据类型是key_t，它有效地为共享内存段命名，shmget()函数成功时返回一个与key相关的共享内存标识符（非负整数），用于后续的共享内存函数。调用失败返回-1。这个key由内核转变为标识符，它可以由以下方法产生：
 * 在创建共享队列时，将该参数指定为IPC_PRIVATE，它保证创建一个新的共享内存区域。注意：IPC_PRIVATE只能用来创建一个新的共享内存区域，而不能用来引用一个已经存在的共享内存区域。
* 可以在一个公共头文件中定义一个客户进程和服务进程都认可的key，然后服务进程用该key创建一个新的共享内存区域。但是这种方法的问题是该key可能已经与另外一个共享内存结合，这时shmget出错返回。
* 使用ftok函数根据路径名和项目id创建一个key，ftok的函数原型为：
~~~c
#include <sys/types.h>
#include <sys/ipc.h>
key_t ftok(const char *pathname, int proj_id);
~~~
**参数size**
参数size以字节为单位制定共享内存区域的长度。

## 附加到进程地址空间
第一次创建完共享内存时，它还不能被任何进程访问，shmat()函数的作用就是用来启动对该共享内存的访问，并把共享内存连接到当前进程的地址空间。它的原型如下：
~~~c
#include <sys/types.h>
#include <sys/shm.h>
void *shmat(int shmid, const void *shmaddr, int shmflg);
~~~
该函数如果调用成功则返回指向共享内存区域的指针，否则返回-1。各参数的含义如下：
**参数shmid**
参数shmid表示需要引入的共享内存标识符，也就是shmget函数的返回值。
**参数 shmflg**
参数 shmflg 是存取权限标志；如果为 0 ，则不设置任何限制权限。在 中定义了几个权限：
~~~c
#define SHM_RDONLY 010000 /* attach read-only else read-write */ 
#define SHM_RND 020000 /* round attach address to SHMLBA */ 
#define SHM_REMAP 040000 /* take-over region on attach */ 
~~~
* 如果指定 SHM_RDONLY ，那么共享内存区只有读取权限。
* 参数 shmaddr 是共享内存的附加点，不同的取值有不同的含义：
    * 如果addr为0，表示由内核来决定第一个可用的附加地址。
    * 如果addr为非0，并且shmflg没有指定SHM_RND值，则附加到addr所指定的地址上。
    * 如果addr为非0，并且shmflg指定了SHM_RND值，则附加到(addr - (addr mod SHMLBA)所指定的地址上。其中，SHM_RND表示“取整”的意思，SHMLBA表示“低边界地址倍数”的意思。
## 分离共享内存
当进程对共享内存区域操作完成后，应该调用shmdt函数将该共享内存区域从当前进程地址空间中分离开来。
~~~c
#include <sys/shm.h>
int shmdt(const void *shmaddr);
~~~
其中参数shmaddr是shmat函数返回的地址指针。如果调用成功该函数返回0，否则返回-1。
shmdt函数只是将指定的共享内存区域与调用进程的地址空间分离，而不是删除共享内存区域。
## 控制共享内存
共享内存是一种特殊的资源，系统提供了一个专门的操作函数用于共享内存的控制。原型如下：
~~~c
#include <sys/ipc.h>
#include <sys/shm.h>
int shmctl(int shmid, int cmd, struct shmid_ds *buf);
~~~
**参数shmid**
参数shmid表示需要操作的共享内存标识符，也就是shmget函数的返回值。
**参数cmd**
参数cmd指明了所要进行的操作类型，主要有以下五种：
* IPC_STAT :	取该共享内存的shmid_ds结构，并存在第三个参数中
* IPC_SET: 		使用buf指定的结构设置相关属性
* IPC_RMID: 	删除指定共享内存，只有当buf中的shm_nattch值为0时才真正删除
* IPC_LOCK: 	在内存中对共享内存加锁（超级用户权限）
* IPC_UNLOCK: 	解锁共享内存（超级用户权限）
**参数buf**
参数buf主要配合参数cmd使用。

## 实例演示
下面我们通过一个实例来演示一下共享内存的使用：
写进程shm_write.c如下：
~~~c
#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <errno.h>

#define BUF_SIZE 4096

int main()
{
    void *shm_addr = NULL;
    char buffer[BUF_SIZE];

    int shmid;
    // 使用约定的键值创建共享内存
    shmid = shmget((key_t) 1234,  BUF_SIZE, 0666 | IPC_CREAT);
    printf("shmid : %u\n", shmid);
    if (shmid < 0)
    {
        perror("shmget error!");
        exit(1);
    }

    // 将共享内存附加到本进程
    shm_addr = shmat(shmid, NULL, 0);
    if (shm_addr == (void *) -1)
    {
        perror("shmat error!");
        exit(1);
    }

    // 写入数据
    bzero(buffer, BUF_SIZE);
    sprintf(buffer, "Hello, My PID is %u\n", (unsigned int) getpid());
    printf("send data: %s\n", buffer);

    memcpy(shm_addr, buffer, strlen(buffer));

    sleep(5);

    // 分离
    if (shmdt(shm_addr) == -1)
    {
        printf("shmdt error!\n");
        exit(1);
    }
}
~~~

读进程shm_read.c如下：
~~~c
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define BUF_SIZE 4096

int main()
{
    void *shm_addr = NULL;

    int shmid;
    // 使用约定的键值打开共享内存
    shmid = shmget((key_t) 1234, BUF_SIZE, IPC_CREAT);
    printf("shmid : %u\n", shmid);
    if (shmid == -1)
    {
        perror("shmget error!");
        exit(1);
    }

    // 将共享内存附加到本进程
    shm_addr = shmat(shmid, NULL, 0);
    if (shm_addr == (void *) -1)
    {
        perror("shmat error!");
        exit(1);
    }

    // 读取数据
    char tmp[BUF_SIZE];
    bzero(tmp, BUF_SIZE);
    memcpy(tmp, shm_addr, BUF_SIZE);
    printf("read from shared memory: %s\n", tmp);

    sleep(5);

    // 分离
    if (shmdt(shm_addr) == -1)
    {
        printf("shmdt error!\n");
        exit(1);
    }

    // 删除共享内存
    if (shmctl(shmid, IPC_RMID, 0) == -1)
    {
        printf("shmctl error!\n");
        exit(1);
    }
}
~~~
我们先运行写进程，输出如下：
~~~c
shmid : 1736715
send data: Hello, My PID is 3122
~~~
此时，我们使用ipcs -m命令查看系统中的确存在标识符为1736715的共享内存区域。如下
~~~
------ Shared Memory Segments --------
key        shmid      owner      perms      bytes      nattch     status 
...(省略无关项)
0x000004d2 1736715    root       666        4096       0
~~~
此时，写进程已经跟共享内存分离，所以nattch为0。
接下来，我们运行读进程。输出如下：
~~~
shmid : 1736715
read from shared memory: Hello, My PID is 3122
~~~
读进程执行完毕后删除了共享内存区域，所以使用ipcs -m命令中发现系统中并没有shmid值等于1736715的共享内存区域。
# 共享内存的优缺点
很明显，由于进程可以直接读写内存，所以采用共享内存进行进程间通信的一个优点就是快速、效率高。像我们前面介绍的匿名管道和命名管道通信方式，需要在用户空间和内核空间之间进行数据拷贝，而共享内存通信方式只在内存中操作，要高效得多。

另外一方面，由于多个进程对同一段内存区域都具有读写权限，在共享内存通信中，进程间的同步问题就显得尤为重要。必须保证同一时刻只有一个进程对共享内存进行写操作，否则会导致数据被覆盖。而共享内存通信又没有提供同步机制，需要使用诸如信号量等手段进行同步控制，这又增加了其复杂性。