---
title: Leetcode-深度优先搜索
date: 2017-10-05 20:55:37
categories: LeetCode
tags:
- LeetCode
- 算法
- 深度优先搜索
copyright:
---
对于本篇文章的主题，如果要抽象出来一个公共思想，应该是如下的样子：
```c
def DFS(solution_Set, buildingAnswer, step)
    # 如果当前构造的解是可用的解，则添加到最终解之中
    if Avaliable(buildingAnswer) :
       solution_Set.add(buildingAnswer)
       return
    # 遍历构造空间，是当前构造解可添加处理操作的空间
    for bs in BuildingSpace:
        # 如果当前遍历的操作对于当前阶段是可行的，则对当前构造解施加操作
        if feasible(bs):                                    
            Process(buildingAnswer, fs)
            # 在当前的处理上进入下一种处理，进一步搜索解
            DFS(solution_Set, buildingAnswer, step + 1)        
            # 恢复本阶段的状态，搜索本阶段另外可施加的状态。
            Restore(buildingAnswer, fs)                         
```
# Palindrome Partitioning 
## Description
 Given a string s, partition s such that every substring of the partition is a palindrome.

Return all possible palindrome partitioning of s.

For example, given s = "aab",
Return

[
  ["aa","b"],
  ["a","a","b"]
]
## 思路
题目要求找到所有可能拆分成回文数的情况，那么肯定是所有的情况都要遍历到，对于每一个子字符串都要分别判断一次是不是回文数，那么肯定有一个判断回文数的子函数，还需要一个DFS函数用来递归，再加上原本的这个函数，总共需要三个函数来求解。
```
                     0
       |             |             |
       a          aa        abc
    |     |         |    
    a   ab      b
    |
    b 
```

## 实现
```c
class Solution {
public:
    vector<vector<string>> partition(string s) {
        vector<vector<string>> res;
        vector<string> out;
        partitionDFS(s, 0, out, res);
        return res;
    }
    void partitionDFS(string s, int start, vector<string> &out, vector<vector<string>> &res) {
        if (start == s.size()) {
            res.push_back(out);
            return;
        }
        for (int i = start; i < s.size(); ++i) {
            if (isPalindrome(s, start, i)) {
                out.push_back(s.substr(start, i - start + 1));
                partitionDFS(s, i + 1, out, res);
                out.pop_back();
            }
        }
    }
    bool isPalindrome(string s, int start, int end) {
        while (start < end) {
            if (s[start] != s[end]) return false;
            ++start;
            --end;
        }
        return true;
    }
};
```
# Permutations
Given a collection of distinct integers, return all possible permutations.
Example:
```
Input: [1,2,3]
Output:
[
  [1,2,3],
  [1,3,2],
  [2,1,3],
  [2,3,1],
  [3,1,2],
  [3,2,1]
]
```
## 思路
逐一向中间集添加元素，并将当中间集元素个数等于 nums 长度的时候，将中间集添加到结果集中，并终止该层递归：
## 实现
```c
class Solution {
public:
    
    vector<vector<int>> permute(vector<int>& nums) {
        vector<vector<int>> res; //存放结果
        vector<bool> visited; //标志数组，用于判断元素是否已被访问
        for(int i=0;i<nums.size();i++)
            visited.push_back(false);
        vector<int> vec; // 用于存放符合要求的排列
        permuteDFS(res, vec, nums ,visited);
        return res;
    }
    void permuteDFS(vector<vector<int>> &res, vector<int> &vec ,vector<int> &nums,vector<bool> &visited){
        if(vec.size() == nums.size()){
            res.push_back(vec);
            return;
        }
        for(int i=0; i<nums.size();i++){
            if(visited[i] == false){
                vec.push_back(nums[i]);
                visited[i] = true;
                permuteDFS(res, vec, nums, visited);
                vec.pop_back();
                visited[i] = false;
            }
        }
    }
};
```
# Unique paths
## Description
A robot is located at the top-left corner of a m x n grid (marked 'Start' in the diagram below).

The robot can only move either down or right at any point in time. The robot is trying to reach the bottom-right corner of the grid (marked 'Finish' in the diagram below).

How many possible unique paths are there?
## 实现
```c
class Solution { 
    public: 
    int uniquePaths(int m, int n) {
        if(m==0||n==0) return 0;
        if(m==1&&n==1) return 1;
        return uniquePaths(m-1,n)+uniquePaths(m,n-1);
    } 
};
```
# Restore IP Addresses
## Description
Given a string containing only digits, restore it by returning all possible valid IP address combinations.

Example:
```
Input: "25525511135"
Output: ["255.255.11.135", "255.255.111.35"]
```
## 思路
必须要走到底部才能判断是否合法，深搜。
## 实现
```c
class Solution {
public:
    vector<string> restoreIpAddresses(string s) {
        vector<string> res;
        vector<int> index; //用于记录插入'.'的位置
        restoreDFS(s, 0, 0, "", res);
        return res;
    }
    
    void restoreDFS(string s, size_t start, size_t step, string ip, vector<string> &result){
        if(start == s.size() && step ==4){
            ip.resize(ip.size()-1);
            result.push_back(ip);
            return ;
        }
        if(step > 4) return;
        int num = 0;
        for(size_t i = start; i<start+3; i++){
            
            num = num*10 + (s[i] - '0');
            if(num <= 255){
                ip +=s[i];
                restoreDFS(s, i+1, step+1, ip+'.', result);
            }
            if(num ==0 ) return; //不允许前缀0
        }
    }
}
```
# Number of Islands
Given a 2d grid map of '1's (land) and '0's (water), count the number of islands. An island is surrounded by water and is formed by connecting adjacent lands horizontally or vertically. You may assume all four edges of the grid are all surrounded by water.
Example 1:
```
Input:
11110
11010
11000
00000

Output: 1
```
Example 2:
```
Input:
11000
11000
00100
00011

Output: 3
```
## 思路
DFS/BFS标零法
## 实现
```
class Solution {
public:
    int numIslands(vector<vector<char>>& grid) {
        if(grid.size()==0) return 0;
        int retval = 0;
        for(int i=0; i<grid.size();i++){
            for(int j=0; j<grid[0].size(); j++){
                if(grid[i][j] == '1'){
                    retval++;
                    dfs_search(grid, i, j);
                }
            }
        }
        return retval;
    }
    
    void dfs_search(vector<vector<char>>& grid, int i, int j){
        grid[i][j] = '0';
        if(i-1>=0 && grid[i-1][j] == '1') dfs_search(grid, i-1, j);
        if(i+1<grid.size() && grid[i+1][j] == '1') dfs_search(grid, i+1, j);
        if(j+1<grid[0].size() && grid[i][j+1] == '1') dfs_search(grid, i, j+1);
        if(j-1>=0 && grid[i][j-1] == '1') dfs_search(grid, i, j-1);
    }
};
```
# Combination Sum
## Description
Given a set of candidate numbers (candidates) (without duplicates) and a target number (target), find all unique combinations in candidates where the candidate numbers sums to target.

The same repeated number may be chosen from candidates unlimited number of times.

Note:
```
    All numbers (including target) will be positive integers.
    The solution set must not contain duplicate combinations.
```
Example 1:
```
Input: candidates = [2,3,6,7], target = 7,
A solution set is:
[
  [7],
  [2,2,3]
]
```
Example 2:
```
Input: candidates = [2,3,5], target = 8,
A solution set is:
[
  [2,2,2,2],
  [2,3,3],
  [3,5]
]
```
## 实现
```c
class Solution {
public:
    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        vector<vector<int>> res;
        vector<int> combin;
        combinationDFS(res, combin, 0 ,0, target, candidates);
        return res;
    }
    void combinationDFS(vector<vector<int>>&res, vector<int> &combin , int start, int sum, int target, vector<int>& candidates){
        if(sum == target){
            res.push_back(combin);
            return;
        }
        for(int i=start; i<candidates.size();i++){
            if(sum+candidates[i]<=target){
                combin.push_back(candidates[i]);
                combinationDFS(res, combin, i, sum+candidates[i], target, candidates);
                combin.pop_back();
            }
        }
    }
};
```
