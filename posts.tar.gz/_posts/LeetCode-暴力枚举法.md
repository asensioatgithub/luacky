---
title: LeetCode-暴力枚举法
date: 2017-09-17 22:34:37
categories: LeetCode
tags: 
- LeetCode
- 算法
copyright:
---
# Subsets
## Description
 Given a set of distinct integers, nums, return all possible subsets.

Note: The solution set must not contain duplicate subsets.

For example,
If nums = [1,2,3], a solution is:
```
[
  [3],
  [1],
  [2],
  [1,2,3],
  [1,3],
  [2,3],
  [1,2],
  []
]
```
<!--more-->
## 递归法
dfs:每个元素，都有两种选择，选或者不选
```c++
class Solution {
public:
    vector<vector<int>> subsets(vector<int>& nums){
        sort(nums.begin(),nums.end());
        vector<vector<int>> result;
        vector<int> path;
        subsets(nums,path,0,result);
        return result;
    }
private:
    static void subsets(vector<int> &S, vector<int> &path, int step, vector<vector<int>> &result){
        if(step==S.size()){
            result.push_back(path);
            return;
        }
        //选(遍历左子节点)
        path.push_back(S[step]);
        subsets(S,path,step+1,result);
        //不选(遍历右子节点)
        path.pop_back();
        subsets(S,path,step+1,result);
    }
};
```
## 二进制法
对于数组[1,2,3]，可以用一个下标0和1表示是否选择该数字，0表示未选择，1表示选中，那么每一组3个0和1的组合表示一种选择，3位共有8种选择，分别是：
000 对应[]
001 对应[3]
010 对应[2]
011 对应[2,3]
100 …
101
110
111
那么上面为1的位表示数组中该位被选中。
那么只需要遍历0到1<< length中的数，判断每一个数中有那几位为1，为1的那几位即会构成一个子集中的一个元素。
```c++
class Solution {
  public:
  vector<vector<int>> subsets(vector<int>& nums) {
        vector<vector<int>> result;
        sort(nums.begin(),nums.end());
        int n=nums.size();
        vector<int> v;
        for(int i=0;i<1<<n;i++){
            for(int j=0;j<n;j++){
                if(1&i>>j) v.push_back(nums[j]);
            }
            result.push_back(v);    
            v.clear();
        }
        return result;
    }
```
## 迭代
# Permutations
## Description
Given a collection of distinct numbers, return all possible permutations.

For example,
[1,2,3] have the following permutations:
```
[
  [1,2,3],
  [1,3,2],
  [2,1,3],
  [2,3,1],
  [3,1,2],
  [3,2,1]
]
```
## 递归
这道题目我们可以用递归来实现，递归在图论中又称为“深度优先搜索”（Depth First Search,DFS），所以在平时我们经常把用到递归的算法简称为DFS。
subsets中的DFS是关于binary tree的，但是这里要扩展到general 的tree，即每一个node的子节点都要遍历一遍DFS
```c++
class Solution {
public:
    vector<vector<int>> permute(vector<int>& nums) {
        sort(nums.begin(),nums.end());
        vector<vector<int>> result;
        vector<int> path;
        DFS(nums,result,path);
        return result;
    }
private:
    void DFS(vector<int> &nums,vector<vector<int>> &result,vector<int> &path){
        if(path.size()==nums.size()){
            result.push_back(path);
            return;
        }
        for(auto i:nums){//这里不像binary tree一样，dfs左右子树就行。这里是要dfs所有的子节点
            auto pos=find(path.begin(),path.end(),i);
            if(pos==path.end()){
                path.push_back(i);
                DFS(nums,result,path);
                path.pop_back();
            }
        }
    }
};
```

# Combinnations
## Description
 Given two integers n and k, return all possible combinations of k numbers out of 1 ... n.

For example,
If n = 4 and k = 2, a solution is:
```
[
  [2,4],
  [3,4],
  [2,3],
  [1,2],
  [1,3],
  [1,4],
]
```
```c++
class Solution {
public:
    vector<vector<int>> combine(int n, int k) {
        vector<vector<int>> result;
        vector<int> path;
        DFS(1,k,n,0,result,path);
        return result;
    }
private:
    //start:开始的数；cur:已经选择的数
    void DFS(int start,int k,int n,int cur,vector<vector<int>> &result,vector<int> &path){
        if(cur==k){
            result.push_back(path);
            return;
        }
        for(int i=start;i<=n;i++){
            path.push_back(i);
            DFS(i+1,k,n,cur+1,result,path);
            path.pop_back();
        }
    }
};
```
# Letter Combinations of a Phone Number 
Given a digit string, return all possible letter combinations that the number could represent.

A mapping of digit to letters (just like on the telephone buttons) is given below.

Input:Digit string "23"
Output: ["ad", "ae", "af", "bd", "be", "bf", "cd", "ce", "cf"].
```c++
class Solution {
public:
    const vector<string> keyboard{"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
    vector<string> letterCombinations(string digits) {
        vector<string> result;
        if(digits.empty()) return vector<string>();
        DFS(digits,result,0,"");
        return result;
    }
private:
    void DFS(string digits,vector<string> &result,int cur,string path){
        if(cur==digits.size()){
            result.push_back(path);
            return;
        }
        for(auto c:keyboard[digits[cur]-'0']){
            DFS(digits,result,cur+1,path+c);
        }
    }
};


#include<iostream>
#include<string>
#include<vector>
#include<stdlib.h>
using namespace std;
class Solution {
public:
    const vector<string> keyboard{"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
    vector<vector<char>> letterCombinations(string digits) {
        vector<vector<char>> result;
        vector<char> path;
        if(digits.empty()) return vector<vector<char>>();
        DFS(digits,result,0,path);
        return result;
    }
private:
    void DFS(string digits,vector<vector<char>> &result,int cur,vector<char> path){
        if(cur==digits.size()){
            result.push_back(path);
            return;
        }
        
        for(auto c:keyboard[digits[cur]-'0']){
        	  path.push_back(c);
            DFS(digits,result,cur+1,path);
            path.pop_back();
        }
    }
};
int main(){
	Solution s;
	vector<vector<char>> result=s.letterCombinations("23");
	vector<vector<char>>::iterator item1 = result.begin();
	while(item1!=result.end()){
	  vector<char>::iterator item2 = (*item1).begin();
	  while(item2!=((*item1).end())){
	  	cout<<*item2;
	  	item2++;
	  }
	  cout<<endl;
	  item1++;
	}
}
```
