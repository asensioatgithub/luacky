---
layout: post
title: Nginx-location的管理与查找
draft: false
date: 2018-11-04 21:15:20
categories:
tags:
permalink:
description:
cover_img:
toc-disable:
comments:
---
被王：lq 图

在完成了http配置的解析和合并之后就是location的组织。
```
static char *
ngx_http_block(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
	......

    /* create location trees */
    
    for (s = 0; s < cmcf->servers.nelts; s++) {

        clcf = cscfp[s]->ctx->loc_conf[ngx_http_core_module.ctx_index];
        // ngx_http_init_location()函数对每个server的location进行排序和分类处理
        if (ngx_http_init_locations(cf, cscfp[s], clcf) != NGX_OK) {
            return NGX_CONF_ERROR;
        }

        if (ngx_http_init_static_location_trees(cf, clcf) != NGX_OK) {
            return NGX_CONF_ERROR;
        }
    }
	......
}
```
首先调用ngx_http_init_locations()函数对每个server的location进行排序和分类处理:
1. 执行 ngx_queue_sort(locations, ngx_http_cmp_locations) 对 locations 进行排序，排序规则比较复杂，请参见 ngx_http_cmp_locations 函数。

2. 然后将 regex location 和 named location 这两种 location 分离出来，分别存储在 cscf->named_locations 和 pclcf->regex_locations 队列里面，这两种 locations 不参与 location tree 的构建。
```
static ngx_int_t
ngx_http_init_locations(ngx_conf_t *cf, ngx_http_core_srv_conf_t *cscf,
    ngx_http_core_loc_conf_t *pclcf)
{
    ngx_uint_t                   n;
    ngx_queue_t                 *q, *locations, *named, tail;
    ngx_http_core_loc_conf_t    *clcf;
    ngx_http_location_queue_t   *lq;
    ngx_http_core_loc_conf_t   **clcfp;
#if (NGX_PCRE)
    ngx_uint_t                   r;
    ngx_queue_t                 *regex;
#endif

    locations = pclcf->locations;

    if (locations == NULL) {
        return NGX_OK;
    }
    /* 按照类型排序location，排序完后的队列：  (exact_match 或 inclusive) (排序好的，如果某个exact_match名字和inclusive location相同，exact_match排在前面)
       |  regex（未排序）| named(排序好的)  |  noname（未排序）*/
    ngx_queue_sort(locations, ngx_http_cmp_locations);  // 比较函数是ngx_http_cmp_locations

    named = NULL;
    n = 0;
#if (NGX_PCRE)
    regex = NULL;
    r = 0;
#endif
    // 这层循环主要是遍历整个locations链表找到regex的起始位置和named的起始位置
    for (q = ngx_queue_head(locations);
         q != ngx_queue_sentinel(locations);
         q = ngx_queue_next(q))
    {
        lq = (ngx_http_location_queue_t *) q;

        clcf = lq->exact ? lq->exact : lq->inclusive;

        /* 由于可能存在nested location，也就是location里面嵌套的location，
        这里需要递归的处理一下当前location下面的nested location */ 
        if (ngx_http_init_locations(cf, NULL, clcf) != NGX_OK) {
            return NGX_ERROR;
        }

#if (NGX_PCRE)

        if (clcf->regex) {
            r++;

            if (regex == NULL) {
                regex = q;
            }

            continue;
        }

#endif

        if (clcf->named) {
            n++;

            if (named == NULL) {
                named = q;
            }

            continue;
        }

        if (clcf->noname) {
            break;
        }
    }

    if (q != ngx_queue_sentinel(locations)) {
        ngx_queue_split(locations, q, &tail);
    }

    /* 如果有named location，将它们保存在所属server的named_locations数组中 */
    if (named) {
        clcfp = ngx_palloc(cf->pool,
                           (n + 1) * sizeof(ngx_http_core_loc_conf_t *));
        if (clcfp == NULL) {
            return NGX_ERROR;
        }

        cscf->named_locations = clcfp;

        for (q = named;
             q != ngx_queue_sentinel(locations);
             q = ngx_queue_next(q))
        {
            lq = (ngx_http_location_queue_t *) q;

            *(clcfp++) = lq->exact;
        }

        *clcfp = NULL;

        ngx_queue_split(locations, named, &tail);
    }

/* 如果有正则匹配location，将它们保存在所属server的http core模块的loc配置的regex_locations 数组中， 
    这里和named location保存位置不同的原因是由于named location只能存在server里面，
    而regex location可以作为nested location */ 
#if (NGX_PCRE)
  
  if (regex) { 
    if (regex) {

        clcfp = ngx_palloc(cf->pool,
                           (r + 1) * sizeof(ngx_http_core_loc_conf_t *));
        if (clcfp == NULL) {
            return NGX_ERROR;
        }

        pclcf->regex_locations = clcfp;

        for (q = regex;
             q != ngx_queue_sentinel(locations);
             q = ngx_queue_next(q))
        {
            lq = (ngx_http_location_queue_t *) q;

            *(clcfp++) = lq->exact;
        }

        *clcfp = NULL;

        ngx_queue_split(locations, regex, &tail);
    }

#endif

    return NGX_OK;
}
```