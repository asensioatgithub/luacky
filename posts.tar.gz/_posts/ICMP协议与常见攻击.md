---
title: ICMP协议与常见攻击
date: 2017-10-01 16:41:54
categories: 计算机网络
tags: 
- ICMP　
copyright:
---
# ICMP协议
ICMP报文主要有两大功能：**查询报文和差错报文**．协议号为１．
差错报文可用来诊断网络故障.我们已经知道,IP协议的工作方式是”best effort”.如果IP包没有被传输到目的地,或者IP包发生错误,IP协议本身不会做进一步的努力.但是上游发送IP包的主机和接力的路由器并不知道下游发生了错误和故障,它们可能继续发送IP包.通过ICMP包,下游的的路由器和主机可以将错误信息汇报给上游,从而让上游的路由器和主机进行调整,需要主要的是,ICMP只提供特定类型的错误汇报,它不能帮助IP协议成为”可靠(reliable)”的协议.
<!--more-->
尽管在大多数情况下，错误的包传送应该给出ICMP报文，但是在特殊情况下，是不产生ICMP错误报文的。如下
```
    1.ICMP差错报文不会产生ICMP差错报文（出IMCP查询报文）（防止IMCP的无限产生和传送）
    2.目的地址是广播地址或多播地址的IP数据报。
    3.作为链路层广播的数据报。
    4.不是IP分片的第一片。
    5.源地址不是单个主机的数据报。这就是说，源地址不能为零地址、环回地址、广播地 址或多播地址。
   这些设置的目的是 防止过去允许ICMP差错报文对广播分组影响带来的广播风暴
```

另一类信息是咨询性质的,比如某台计算机询问路径上的每个路由器都是谁,然后各个路由器同样用ICMP包回答
# ICMP报文格式
不同类型的报文有不同的报文格式，但都拥有固定的类型，代码，检验和字段：
![](/home/maohao/文档/blog/source/images/720RJ8NUMIBI.png) 
**类型**：一个８位类型字段，表示ICMP数据包类型．
**代码**：一个８位代码域，表示指定类型中的一个功能，如果一个类型中只有一个功能，代码域位０．
**检验和**：数据包中ICMP部分上的一个16位检验和．
各种类型的ICMP报文如图所示：
![](/images/ICMP-type.png) 
## 请求会先和回显应答（Echo or Echo Reply Message）
![](/images/ICMP-echo.png) 
## 目的不可达（Destination Unreachable Message）
When a router can not forward or deliver an IP datagram, it sends a destination unreachable message back to the original source.
The format of the packet is the following:
![](/images/ICMP-DUM.png) 
## ICMP重定向
When a router detects a host using a nonoptimal route, it sends the host ICMP redirect message; requesting host change its route
An example:
```
Gateway G1, receives an Internet  datagram from a host ;
G1 checks its routing table and obtains the address of the next gateway, G2, the next hop on the route of the packet;
However, if G2  and the host are on the same network, a redirect message is sent to the host
```
![](/images/ICMP-RM.png) 
例如：
![](/images/icmp-rm-example.png) 
过程分析如下：
```
1). server2如果要与internet通讯，首先是要把报文发送给server1的，因为server2
的网关指向server1的。
2). server1收到报文并检查它的路由表，发现router是发送改报文的下一跳。当它把
报文发送给router时，server1检测到这个报文的发送出去的接口与接收到的接口是相
同的，这样ICMP重定向就触发了。
3). server1认为server2应该把默认路由指向router，所以就发送ICMP重定向报文给
server2，告诉它以后把报文发送给router。
```
# ICMP应用
## Ping
原理是用类型码为0的ICMP发请 求，受到请求的主机则用类型码为8的ICMP回应。ping程序来计算间隔时间，并计算有多少个包被送达。用户就可以判断网络大致的情况。我们可以看到， ping给出来了传送的时间和TTL的数据。
ping还给我们一个看主机到目的主机的路由的机会。这是因为，ICMP的ping请求数据报在每经过一个路由器的时候，路由器都会把自己的ip放到该数 据报中。而目的主机则会把这个ip列表复制到回应icmp数据包中发回给主机。但是，无论如何，ip头所能纪录的路由列表是非常的有限。如果要观察路由， 我们还是需要使用更好的工具，就是要讲到的Traceroute(windows下面的名字叫做tracert)。
## Traceroutr
Traceroute是用来侦测主机到目的主机之间所经路由情况的重要工具，也是最便利的工具。前面说到，尽管ping工具也可以进行侦测，但是，因为ip头的限制，ping不能完全的记录下所经过的路由器。所以Traceroute正好就填补了这个缺憾。
Traceroute的原理是非常非常的有意思，它受到目的主机的IP后，首先给目的主机发送一个TTL=1（还记得TTL是什么吗？）的UDP(后面就 知道UDP是什么了)数据包，而经过的第一个路由器收到这个数据包以后，就自动把TTL减1，而TTL变为0以后，路由器就把这个包给抛弃了，并同时产生 一个主机不可达的ICMP数据报给主机。主机收到这个数据报以后再发一个TTL=2的UDP数据报给目的主机，然后刺激第二个路由器给主机发ICMP数据 报。如此往复直到到达目的主机。这样，traceroute就拿到了所有的路由器ip。从而避开了ip头只能记录有限路由IP的问题。

有人要问，我怎么知道UDP到没到达目的主机呢？这就涉及一个技巧的问题，TCP和UDP协议有一个端口号定义，而普通的网络程序只监控少数的几个号码较 小的端口，比如说80,比如说23,等等。而traceroute发送的是端口号>30000(真变态)的UDP报，所以到达目的主机的时候，目的 主机只能发送一个端口不可达的ICMP数据报给主机。主机接到这个报告以后就知道，主机到了。
# Smurf攻击
Smurf攻击是以最初发动这种攻击的程序名＂Smurf＂来命名的，是DDOS攻击中较为常见的一种．
该攻击方式利用TCP/IP协议自身的缺陷，结合使用IP欺骗和ICMP回复方法，使网络因响应ICMP回复请求而产生大量的数据流量，导致网络严重的拥塞或资源消耗，引起目标系统拒绝位合法用户提供服务，从而对网络安全构成重大威胁．
攻击这在远程机器上或在本网段主机上发送ICMP应答请求服务，其目标主机不是某一个主机的IP地址，而是某一个网络的广播地址，其请求包的源IP不是发起攻击的IP地址，而是加以伪装的将要攻击的主机的IP地址．大量主机收到ICMP应答请求服务包后，按源IP返回请求信息，从而导致受攻击主机的服务性能下降，甚至崩溃．
## Smurf攻击
攻击通常分为以下五步：
```
   1>黑客锁定一个被攻击的主机（通常是一些Web服务器）；
   2>黑客寻找可做为中间代理的站点，用来对攻击实施放大（通常会选择多个，以便更好地隐藏自己，伪装攻击）；
   3>黑客给中间代理站点的广播地址发送大量的ICMP包。这些数据包全都以被攻击的主机的IP地址做为IP包的源地址；
   4>中间代理向其所在的子网上的所有主机发送源IP地址欺骗的数据包；
   5>中间代理主机对被攻击的网络进行响应。
```
## Smurf防范
1 配置路由器禁止IP广播包进网
```
第一种方法是在路由器端加以配置，拒绝接受带有广播地址的ICMP请求包，防止这些分组到达自己的网络．
第二种方法时用户禁止路由器吧网络广播地址映射成为局域网广播地址．制止了这个映射过程，自己的系统就不会再收到这些echo请求．
```
2 配置网络上所有计算机的操作系统，禁止对目标地址为广播地址的ICMP包响应。
3 避免站内主机成为攻击者： 
```
对于从本网络向外部网络发送的数据包，本网络应该将其源地址为其他网络的这部分
数据包过滤掉。比如在哭又端通过向某一ICMP包的源IP发送一个确认包来判断此包
是否是欺骗的IP包，保证内部网络中发出的所有传输信息都具有合法的源地址.
```
# ICMP重定向攻击
ICMP重定向报文是当主机采用非最优路由发送数据报时，路由器会发回ICMP重定向报文来通知主机最优路由的存在。并且重定向报文必须由路由器生成，当主机作为路由器使用时，必须将其内核配置成可以发送重定向报文。

ICMP重定向攻击也可以达到类似ARP欺骗的攻击效果。假设主机A(IP地址为172.16.1.2)经默认路由器(IP地址为172.16.1.1)与另一个网络中的主机D(IP地址为172.16.2.2)通信，与主机A同属一个网络的攻击者(IP地址为172.16.1.4)，通过修改内核设置，充当与主机A直接相连的路由器。攻击者要想监听主机A 的通信内容，可以构造ICMP重定向报文，指示主机A将数据包转发到攻击者的机器上，攻击者对所有的数据进行过滤后再转发给默认路由器，这就是“中间人”攻击。同样，ICMP重定向攻击也可以达到拒绝服务(DoS)攻击的目的。

在实际应用中，无论ARP欺骗抑或是ICMP重定向攻击，都有可能出现攻击者的机器自动发送ICMP 重定向报文给目标主机的情况。这种自动生成的 ICMP 重定向报文与攻击者 发送的伪ICMP 重定向报文有所不同，其原理是同一网段内的攻击者为监听网络而开启了IP 路由功能，对数据包过滤后转发给默认路由器，默认路由器再转发数据包至主机D。但由于IP 寻址的原理，攻击者的机器(在此充当路由器)会发现下一跳路由器(即默认路由器)与源主机处在同一子网中，即有一条更优路由的存在，此时攻击者的机器会自动发送ICMP 重定向报文来指示主机A 通往网外的主机D(172.16.2.2)的最优路由是经由默认路由器而不是经由攻击者的机器，结果是使ARP 欺骗或ICMP 重定向攻击失败。对ARP 欺骗来说，可以通过个人防火墙等手段限制有关 ICMP 报文的出包，但对ICMP 重定向攻击来说，限制ICMP 报文的出包后也就意 味着攻击者也无法发送伪造的ICMP 重定向报文给目标主机，实现起来更为复杂。
# 死亡之ping
ICMP echo request with fragmented packets
Maximum legal size of an ICMP echo request packet:
65536 - 20- 8 = 65507
Fragmentation allows the bypass of the maximum size. For the last piece of the fragment, the following is possible: (offset + size) >65535
Impact: some operating systems will crash
Same attack with different IP protocol