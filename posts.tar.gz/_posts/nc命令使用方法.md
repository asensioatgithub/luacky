---
title: nc命令使用方法
date: 2017-10-22 11:10:27
categories:	Linux
tags: 
- Linux
- netcat
copyright:
---
NetCat，在网络工具中有“瑞士军刀”美誉，其有Windows和Linux的版本。因为它短小精悍（1.84版本也不过25k，旧版本或缩减版甚至更小）、功能实用，被设计为一个简单、可靠的网络工具，可通过TCP或UDP协议传输读写数据。同时，它还是一个网络应用Debug分析器，因为它可以根据需要创建各种不同类型的网络连接。
<!--more-->
# 语法
nc/netcat(选项)(参数)
# 选项 
```
-g<网关>：设置路由器跃程通信网关，最多设置8个； 
-G<指向器数目>：设置来源路由指向器，其数值为4的倍数； 
-h：在线帮助； 
-i<延迟秒数>：设置时间间隔，以便传送信息及扫描通信端口； 
-l：使用监听模式，监控传入的资料； 
-n：直接使用ip地址，而不通过域名服务器； 
-o<输出文件>：指定文件名称，把往来传输的数据以16进制字码倾倒成该文件保存；
-p<通信端口>：设置本地主机使用的通信端口； 
-r：指定源端口和目的端口都进行随机的选择； 
-s<来源位址>：设置本地主机送出数据包的IP地址； 
-u：使用UDP传输协议； 
-v：显示指令执行过程； 
-w<超时秒数>：设置等待连线的时间； 
-z：使用0输入/输出模式，只在扫描通信端口时使用。
```
# 参数
主机：指定主机的IP地址或主机名称；
端口号：可以是单个整数或者是一个范围。
# 实例
## 远程拷贝文件
从server1拷贝文件到server2上。需要先在server2上，用nc激活监听本地指定端口。
server2：
`boram@boram-VirtualBox:~$ nc -l 1234`
server1：将db.json发送给server1的1234端口
`maohao@maohao-HP-15-Notebook-PC:~/文档/blog$ nc 192.168.1.117 1234 < db.json` 
接收到的数据直接输出到server2
```
boram@boram-VirtualBox:~$ nc -l 1234 
{"meta":{"version":1,"warehouse":"2.2.0"},"models":{"Asset":[],"Cache":[],"Category":[],"Data":[],"Page":[],"Post":[],"PostAsset":[],"PostCategory":[],"PostTag":[],"Tag":[]}}boram@boram-VirtualBox:~$ nc -ls^C
```
或者将接收到数据重定向到某个文件中：
`boram@boram-VirtualBox:~$ nc -l 1234 > 1234.txt`
```
boram@boram-VirtualBox:~$ cat 1234.txt
{"meta":{"version":1,"warehouse":"2.2.0"},"models":{"Asset":[],"Cache":[],"Category":[],"Data":[],"Page":[],"Post":[],"PostAsset":[],"PostCategory":[],"PostTag":[],"Tag":[]}}boram@boram-VirtualBox:~$ 
```
**超时控制:**
多数情况我们不希望连接一直保持，那么我们可以使用 -w 参数来指定连接的空闲超时时间，该参数紧接一个数值，代表秒数，如果连接超过指定时间则连接会被终止。
Server
`boram@boram-VirtualBox:~$ nc -l 1234`
```
Client
maohao@maohao-HP-15-Notebook-PC:~/文档/blog$ nc -v -w 5 192.168.1.117 1234
Connection to 192.168.1.117 1234 port [tcp/*] succeeded!
maohao@maohao-HP-15-Notebook-PC:~/文档/blog$   5s后断开链接
```
该连接将在 10 秒后中断。(-w 参数将在服务器端无效果)

## 端口扫描
`boram@boram-VirtualBox:~$ nc -v 192.168.1.106 -z 1-25`
```
boram@boram-VirtualBox:~$ nc -v 192.168.1.106 -z 1-25
nc: connect to 192.168.1.106 port 1 (tcp) failed: Connection refused
. . .
nc: connect to 192.168.1.106 port 20 (tcp) failed: Connection refused
nc: connect to 192.168.1.106 port 21 (tcp) failed: Connection refused
Connection to 192.168.1.106 22 port [tcp/ssh] succeeded!
Connection to 192.168.1.106 23 port [tcp/telnet] succeeded!
nc: connect to 192.168.1.106 port 24 (tcp) failed: Connection refused
nc: connect to 192.168.1.106 port 25 (tcp) failed: Connection refused
```
**z 参数告诉netcat使用0 IO,连接成功后立即关闭连接， 不进行数据交换.**
**扫描本地端口**
`maohao@maohao-HP-15-Notebook-PC:~/文档/blog$ nc -v localhost -z 1-30`
```
nc: connect to localhost port 1 (tcp) failed: Connection refused
. . .
Connection to localhost 22 port [tcp/ssh] succeeded!
Connection to localhost 23 port [tcp/telnet] succeeded!
nc: connect to localhost port 24 (tcp) failed: Connection refused
nc: connect to localhost port 25 (tcp) failed: Connection refused
nc: connect to localhost port 26 (tcp) failed: Connection refused
nc: connect to localhost port 27 (tcp) failed: Connection refused
nc: connect to localhost port 28 (tcp) failed: Connection refused
nc: connect to localhost port 29 (tcp) failed: Connection refused
nc: connect to localhost port 30 (tcp) failed: Connection refused
```