---
title: openssl-apache2部署SSL
date: 2017-12-03 18:25:49
categories:
tags:
copyright:
---
这篇博客记录了如何运用openssl建立CA，并签发服务器和客户端证书实现双向认证，同时使用OCSP进行证书有效性验证。
# openssl命令
该部分对本次部署将会用到的主要命令进行说明。

语法格式：
`openssl command [ command_opts ] [ command_args ]`
<!--more-->
常用command:
```
version    用于查看版本信息
enc        用于加解密
ciphers    列出加密套件
genrsa    用于生成私钥
rsa        RSA密钥管理(例如:从私钥中提取公钥)
req        生成证书签名请求(CSR)
crl        证书吊销列表(CRL)管理
ca         CA管理(例如对证书进行签名)
dgst      生成信息摘要
rsautl    用于完成RSA签名、验证、加密和解密功能
passwd    生成散列密码
rand      生成伪随机数
speed      用于测试加解密速度
s_client  通用的SSL/TLS客户端测试工具
X509       X.509证书管理
verify      X.509证书验证
PKCS#12 Personal Information Exchange Syntax Standard
```
其中，genrsa/req/ca是接下来将会用到的主要命令。

## req指令说明
**-new/x509**
当使用-new选取的时候，说明是要生成证书请求，当使用x509选项的时候，说明是要生成自签名证书。

**-/key/newkey/keyout**
key和newkey是互斥的，key是指定已有的密钥文件，而newkey是指在生成证书请求或者自签名证书的时候自动生成密钥，然后生成的密钥名称有keyout参数指定。
当指定newkey选项时，后面指定rsa:bits说明产生rsa密钥，位数由bits指定。指定dsa:file说明产生dsa密钥，file是指生成dsa密钥的参数文件(由dsaparam生成)

**-in/out/inform/outform/keyform**
in选项指定证书请求文件，当查看证书请求内容或者生成自签名证书的时候使用
out选项指定证书请求或者自签名证书文件名，或者公钥文件名(当使用pubkey选项时用到)，以及其他一些输出信息。
inform、outform、keyform分别指定了in、out、key选项指定的文件格式，默认是PEM格式。

**-config**
参数文件，默认是/etc/ssl/openssl.cnf(ubuntu12.04)，根据系统不同位置不同。该文件包含生成req时的参数，当在命令行没有指定时，则采用该文件中的默认值。

## ca指令说明
该命令是模拟一个CA行为的工具。有了它，你就是一个CA，不过估计是nobody trusted CA。它能够签发证书请求文件以及生成CRL列表。它还维护着一个文本数据库，记录了所有经手颁发的证书及那些证书的状态。
```
-config filename：
		指定配置文件
-in file
		输入的文件，被用于CA中心签名的证书请求文件路径。
-out file
		签名后的证书文件名，不设置的话是默认输出；证书的细节也会给写进去。
-days arg 
		指定签发的证书的有效时间
-keyfile arg
		CA的私钥证书文件
-cert file
		用于签发的根CA证书
-extensions section
		当一个证书被颁发了，配置文件中的section字段两会添加到证书中。
```
**openssl的各个参数都可以在配置文件中指定默认值，而无需在执行命令时特别指出，只需在命令执行时指定参数文件即可。**
# CA的建立
```
mkdir myca
cd myca
mkdir signedcerts private
touch index.txt
touch serial
echo 01 > serial
```
~/myca: contains CA certificate, certificates database, generated certificates, keys, and requests
~/myca/signedcerts : contains copies of each signed certificate
~/myca/private : contains the private key 

## CA配置文件
defult部分指定包含了CA的基本信息，包括后面将会用到的ocsp的url。
ca_dn指定了CA自己的"特征名称"。
```
[ default ]
ocsp_url	= http://192.168.43.178:1234	＃
default_ca	= CA_default		# The default ca section

[ ca_dn ]
countryName	= "CN"
stateOrProvinceName = "JIANGSU"
organizationName= "Example"
commonName	= "myCA"
```
CA_default包含了自建CA的目录信息，在使用CA命令时，会根据目录设置读取相应的文件。
policy_match指定了CA用自己的私钥签名的时候，对请求文件里的distinguished name的匹配策略：
mtach:请求文件的该字段必须和CA证书的相应字段匹配；
supplied:要求请求文件需设定该字段的值；
opitional:可设定或不设定。
```
[ CA_default ]
dir		= /etc/ssl/myca		# Where everything is kept
certificate     = $dir/myca.pem
database	= $dir/index.txt	# database index file.
serial		= $dir/serial
new_certs_dir	= $dir/signedcerts	# default place for new certs.
private_key	= $dir/private/cakey.pem# The private key

# Comment out the following two lines for the "traditional"
# (and highly broken) format.
name_opt 	= ca_default		# Subject Name options
cert_opt 	= ca_default		# Certificate field options
unique_subject	= no
# copy_extensions = copy
default_days	= 3650			# how long to certify for
default_md	= sha256		# 签名默认使用的信息摘要算法
policy		= policy_match

# For the CA policy
[ policy_match ]
countryName		= match
stateOrProvinceName	= optional
organizationName	= supplied
organizationalUnitName	= optional
commonName		= supplied
emailAddress		= optional
```

在申请证书之前通常需要首先生成符合 PKCS#10 标准的证书请求封装格式。openssl 的 req 指令实现了产生证书请求的功能，其相关选项的默认值就来自于这里的设置。该字段只会在CA生成自签名的根证书时用到。
```
##### 证书请求配置的"基本字段"，其它附属字段都以它为入口 #####
[ req ]
#生成的证书中RSA密钥对的默认长度
default_bits		= 2048 	
default_keyfile 	= /etc/ssl/myca/private/cakey.pem
# 如果设为no，那么 req 指令将直接从配置文件中读取证书字段的信息，而不提示用户输入。
prompt = no	
distinguished_name	= ca_dn
# utf8only: 只使用 UTF8 字符串。推荐使用这个，这样可以完美的包含任意字符。
string_mask = utf8only	
#证书请求扩展的字段名，该扩展字段定义了要加入到证书请求中的一系列扩展项。
req_extensions = ca_ext 

[ ca_ext ]
#CA:true表示为CA自己生成请求
basicConstraints	= critical,CA:true
keyUsage		= critical,keyCertSign
```
usr_cert字段用于CA在给其他证书签名的时候需要加到证书里信息。
```
[ usr_cert ]
# These extensions are added when 'ca' signs a request.
basicConstraints=CA:FALSE
authorityInfoAccess	= @issuer_info
authorityKeyIdentifier	= keyid,issuer

[ issuer_info ]
OCSP;URI.0		= $ocsp_url
```
ocsp_ext字段用于CA在生成OCSP服务响应器时候的扩展。为了能够运行OCSP服务，需要生成一个OCSP证书。
```
[ ocsp_ext ]
authorityKeyIdentifier	= keyid,issuer
basicConstraints	= critical,CA:false
extendedKeyUsage	= OCSPSigning
keyUsage		= critical,digitalSignature
subjectKeyIdentifier	= hash
```
## CA证书的生成
**1.生成CA证书的请求**
```
openssl req -new -out myca.csr -config ./myca.cnf
```
req根据配置文件里目录信息，将私钥写入到./private目录中，同时生成请求文件myca.csr。

**2.对 CA 证书请求进行自签名**
```
openssl ca -selfsign -in myca.csr -out myca.pem -config ./myca.cnf
```
OpenSSL 使用前面生成的密钥对对该请求进行自签名。此时，signedcerts目录中会保存一份证书01.pem**(.pem跟crt/cer的区别是它以Ascii来表示，用base64算法转换而来，.cer 好像是二进制的证书)**，序号为当前serial的保存值，之后serial序号也会自加１。同时index.txt将会保存CA签过名的证书的状态、ID、serial、dn等信息：
```
V	271130140538Z		01	unknown	/C=CN/ST=JIANGSU/O=Example/CN=myCA
```
根证书创建完成后，CA的文件结构如下：
```
../myca
├── index.txt
├── index.txt.attr
├── index.txt.attr.old
├── index.txt.old
├── myca.cnf
├── myca.csr
├── myca.pem
├── private
│   ├── cakey.pem
├── serial
├── serial.old
└── signedcerts
    ├── 01.pem
```
## WEB Server证书
**1.生成用户密钥**
```
openssl genrsa -out privateKey.key 2048
```
**2.生成证书请求文件**
```
openssl req -new -key privateKey.key -out myzoo_server.csr -config ./myzoo_config.cnf
```
这里需要web给出自己的配置信息:
```
[ req ]
prompt = no
distinguished_name = server_distinguished_name
[ server_distinguished_name ]
commonName = 192.168.43.178
stateOrProvinceName = JIANGSU
countryName = CN
emailAddress = emilsinclair@163.com
organizationName = USTC
organizationalUnitName = Asensio
```

**3.对用户证书签名**
```
openssl ca -in myzoo_server.csr -out myzoo_server.pem -config /etc/ssl/myca/myca.cnf -extensions usr_cert
```
 -extensions usr_cert加入扩展字段，将CA的信息(主要是ocsp_url)写入到证书里。ocsp客户端才会根据接收到的证书里的ocsp_url进行验证。
**4.web server配置**
进入/etc/apache2/目录，修改该web server的配置文件，指定证书和密钥的存放路径
```
                #   SSLCertificateFile directive is needed.
                SSLCertificateFile      /var/www/myzoo/myzoo_server.pem
                SSLCertificateKeyFile /var/www/myzoo/privateKey.key
                
                ＃SSLCACertificateFile /etc/ssl/myca/myca.pem
                ＃SSLVerifyCLient require
                ＃SSLVerifyDepth  10

```
（下面三行用于双向认证时(服务器认证客户端证书)，暂时不启用。）
之后，重新加载配置文件，并重启apache2。[附apache2配置说明](http://blog.maohao.pro/2017/11/24/apache2%E7%AB%99%E7%82%B9%E9%85%8D%E7%BD%AE/#more) 
## 客户端证书
用同样的步骤生成客户端证书。
```
[ req ]
prompt = no
distinguished_name = server_distinguished_name

[ server_distinguished_name ]
commonName = client.com
stateOrProvinceName = JIANGSU
countryName = CN
emailAddress = emilsinclair@163.com
organizationName = USTC
organizationalUnitName = maohao
```

pem格式还无法导入到“您的证书”里面去，需要将客户端的证书和私钥打包成p12格式(firefox要求客户端的证书格式是p12格式).
```c
sudo openssl pkcs12 -export -out client.pfx -inkey privateKey.key -in client.pem
```
# 证书有效性的管理机制
证书有效性验证，即确认该证书是否已经失效，如证书有效期已过或者私钥泄露。
## CRL
浏览器在验证证书的有效性时就需要去访问证书注销列表（CRL）。这个列表相当于“黑名单”，一旦发现通信对方的证书在这张列表中，就不能通过验证。

 从安全的角度上讲，CRL最好是进行实时更新，即一旦发生证书注销事件就立即更新，以杜绝欺诈案件的得逞。但这种实时更新的代价非常高，要占用大量的网络资源和服务器资源，反过来又会影响到网上交易的进行。因此，业内普遍的做法是定期更新，如CFCA的管理策略是对主服务器的CRL和所有远程镜像CRL每天更新一次。
 
 CRL方法存在一些**缺点**，其一就是CRL不可能实时更新，由于CA每隔一定时间才发布CRL，所以CRL不能及时地反应证书的状态，在安全性上有一定局限；其二，即使定期更新CRL也有麻烦，当注销证书的数量很大及用户基础很大时，CRL常常会越变越大。 每次CRL分发会大量消耗网络带宽和服务器处理能力。
 
## OCSP
针对CRL方法存在的一些缺点，另一种证书有效性的管理和查询方法，即在线查询机制应运而生。
在线证书状态协议（OCSP，Online Certificate Status Protocol）是IETF颁布的用于检查数字证书在某一交易时间是否有效的标准，在RFC 2560中有描述。它为网上业务提供了一种检验数字证书有效性的途径，克服了证书注销列表（CRL）的主要缺陷：必须经常在客户端下载以确保列表的更新。。OCSP实时在线地向用户提供证书状态，其结果是它比CRL处理快得多，并避免了令人头痛的逻辑问题和处理开销。
OCSP在线查询机制的简单过程如下:
![](/images/ocsp.jpg) 
用户的客户机形成查询指定证书状态请求，并将请求转发到一个OCSP应答器(服务器)，应答器建立与CA证书库的连接，并查询CA证书库而获得该证书的状态，应答器返回客户机有关证书有效性信息。**响应信息必须经过数字签名**，以保证这个信息的真实性和完整性（未被篡改）。**签名密钥属于CA**，即颁发这张证书的权威、可信的第三方机构，因此，在任何情况下，用户都能够信任这个信息。

##OCSP装订
OCSP装订（OCSP Stapling），也称OCSP封套，是一个TLS证书状态查询扩展，作为在线证书状态协议的代替方法对X.509证书状态进行查询，目的是让证书使用者（例如浏览器）如何知道一个证书是否有效（证书颁发者有时候需要作废某些证书）。OCSP 响应本身经过了数字签名，无法伪造，所以 OCSP Stapling 技术既提高了握手效率，也不会影响安全性。

服务器在TLS握手时可以发送事先缓存的OCSP响应，用户只需验证该响应的有效性而不用再向数字证书认证机构（CA）发送请求。
# OCSP部署
为了传达给OCSP客户端一个知道的信息获取点，CA们可以在权威机构信息获取扩展（可以被检测用来使用OCSP）提供这样的能力。作为另外一种选择，也可以在OCSP客户端本地配置OCSP提供者获取地（信息）。支持OCSP服务的CA，无论是自身实现还是通过授权响应器来提供，都必须提供包括统一资源识别形式的获取地信息和在一个获取描述序列中的对象识别符号形式的获取方法。在主体证书的获取地域中的值定义了使用什么传输（例如HTTP）来获取OCSP响应器，并且可以包含其他传输相关信息（例如URL）。
CA给证书签名的时候我们已经通过扩展将ocsp_url的信息写入到了证书里：
```
       X509v3 extensions:
            X509v3 Basic Constraints: 
                CA:FALSE
            Authority Information Access: 
                OCSP - URI:http://192.168.43.178:1234

            X509v3 Authority Key Identifier: 
                DirName:/C=CN/ST=JIANGSU/O=Example/CN=myCA
                serial:01
```

**1.生成OCSP证书**
```
openssl req -new -newkey rsa:2048 -subj "/C=CN/O=Example/CN=OCSP CA Responder" -keyout private/myca-ocsp.key -out myca-ocsp.csr
openssl ca -in myca-ocsp.csr -out myca-ocsp.pem -config ./myca.cnf -extensions ocsp_ext -days 30
```
**2.开启OCSP服务响应器**
```
openssl ocsp -port 1234 -index index.txt -rsigner myca-ocsp.pem -rkey private/myca-ocsp.key -CA myca.pem -text
```
-index：ocsp通过查询 index.txt文件信息获取证书状态。
-port：指定1234号为ocsp的端口；
-text：打印相关信息
开启服务器之后，将会等待客户端的请求：
```
maohao@maohao-HP-15-Notebook-PC:/etc/ssl/myca$ sudo openssl ocsp -port 1234 -index index.txt -rsigner myca-ocsp.pem -rkey private/myca-ocsp.key -CA myca.pem -text
[sudo] maohao 的密码： 
Enter pass phrase for private/myca-ocsp.key:
Waiting for OCSP client connections...

```
所有部署完成后，CA的目录结构如下：
```
myca
├── index.txt
├── index.txt.attr
├── index.txt.attr.old
├── index.txt.old
├── myca.cnf
├── myca.csr
├── myca-ocsp.csr
├── myca-ocsp.pem
├── myca.pem
├── private
│   ├── cakey.pem
│   └── myca-ocsp.key
├── serial
├── serial.old
└── signedcerts
    ├── 01.pem
    ├── 02.pem
    ├── 03.pem
    └── 04.pem
2 directories, 17 files
```
# 测试
## 单向认证
导入CA根证书到浏览器
![](/images/ca-import1.png) 
![](/images/ca-impoet2.png) 
打开浏览器的OCSP服务：
![](/images/ocsp-on.png) 
访问web server
![](/images/2017-12-03-12-26-59.png) 
访问正常。

## 双向认证
在/etc/apache2/中的网站配置文件中打开服务器认证客户端证书的功能：
```
                #   SSLCertificateFile directive is needed.
                SSLCertificateFile      /var/www/myzoo/myzoo_server.pem
                SSLCertificateKeyFile /var/www/myzoo/privateKey.key
                
                SSLCACertificateFile /etc/ssl/myca/myca.pem
                SSLVerifyCLient require
                SSLVerifyDepth  10

```

再重新加载配置文件，并重启apache2，再访问https://127.0.0.1:4391/myzoo/
![](/images/client_no_mycert.png) 
浏览器报错：SSL 对等端无法协商出一个可接受的安全参数设置。因为还没有导入客户端证书到浏览器中，服务器无法获取到客户端证书，不会与客户端进行密钥协商。
现在，将自己的客户端证书导入到浏览器中：
![](/images/2017-12-0.png) 
再次访问，成功！
![](/images/2017-12-03-17-43-59.png) 
## OCSP吊销
现在吊销web server的证书：
```
openssl ca -revoke signedcerts/02.pem -config myca.cnf -crl_reason keyCompromise
```
-crl_reason keyCompromise，指定吊销原因为密钥泄露
查看index.txt文件的变化
```
V	271130140538Z		01	unknown	/C=CN/ST=JIANGSU/O=Example/CN=myCA
R	271130140543Z	171202141227Z,keyCompromise	02	unknown	/C=CN/ST=JIANGSU/O=USTC/OU=Asensio/CN=127.0.0.1/emailAddress=emilsinclair@163.com
V	180101140556Z		03	unknown	/C=CN/O=Example/CN=OCSP CA Responder
```
可以看见02.pem状态变为了R(Revoke)。
再访问https://127.0.0.1:4391/myzoo/
![](/images/asdasdas.png) 
显示服务器证书已被吊销。
# PKCS
PKCS 全称是 Public-Key Cryptography Standards ，是由 RSA 实验室与其它安全系统开发商为促进公钥密码的发展而制订的一系列标准，PKCS 目前共发布过 15 个标准。 常用的有：
```
PKCS#7
	Cryptographic Message Syntax Standard
PKCS#10
	 Certification Request Standard
PKCS#12
	 Personal Information Exchange Syntax Standard
X.509
	是常见通用的证书格式。所有的证书都符合为Public Key Infrastructure (PKI) 
	制定的 ITU-T X509 国际标准。
	X.509 DER 编码(ASCII)的后缀是： .DER .CER .CRT
	X.509 PAM 编码(Base64)的后缀是： .PEM .CER .CRT
	.cer/.crt是用于存放证书，它是2进制形式存放的，不含私钥。
	.pem跟crt/cer的区别是它以Ascii来表示。
PKCS#7
	常用的后缀是： .P7B .P7C .SPC
PKCS#12 
	常用的后缀有： .P12 .PFX
	pfx/p12用于存放个人证书/私钥，他通常包含保护密码，2进制方式
p10
	是证书请求
p7r
	是CA对证书请求的回复，只用于导入
p7b
	以树状展示证书链(certificate chain)，同时也支持单个证书，不含私钥。
```