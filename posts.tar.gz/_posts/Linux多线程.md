---
title: Linux多线程
date: 2018-03-05 20:31:56
categories: Linux
tags:
copyright:
---
进程是系统中程序执行和资源分配的基本单位。每个进程有自己的数据段、代码段和堆栈段。这就造成进程在进行切换等操作时都需要有比较负责的上下文切换等动作。为了进一步减少处理器的空转时间支持多处理器和减少上下文切换开销,也就出现了线程。
线程通常叫做轻量级进程。线程是在共享内存空间中并发执行的多道执行路径,是一个更加接近于执行体的概念,拥有独立的执行序列,是进程的基本调度单元,每个进程至少都有一个 main 线程。**它与同进程中的其他线程共享进程空间{堆 代码 数据 文件描述符 信号等},只拥有自己的栈空间**,大大减少了上下文切换的开销。
<!--more-->
# 线程的优缺点
**优点:**
１．使用多线程的理由之一是和进程相比，它是一种**花销小，切换快**，更"节俭"的多任务操作方式。在Linux系统下，启动一个新的进程必须分配给它独立的地址空间，建立众多的数据表来维护它的代码段、堆栈段和数据段，这是一种"昂贵"的多任务工作方式。而运行于一个进程中的多个线程，它们彼此之间使用相同的地址空间，共享大部分数据，启动一个线程所花费的空间远远小于启动一个进程所花费的空间，而且，线程间彼此切换所需的时间也远远小于进程间切换所需要的时间。
2.使用多线程的理由之二是线程间**方便的通信机制**。对不同进程来说，它们具有独立的数据空间，要进行数据的传递只能通过通信的方式进行，这种方式不仅费时，而且很不方便。线程则不然，由于同一进程下的线程之间共享数据空间，所以一个线程的数据可以直接为其它线程所用，这不仅快捷，而且方便。当然，数据的共享也带来其他一些问题，有的变量不能同时被两个线程所修改，有的子程序中声明为static的数据更有可能给多线程程序带来灾难性的打击，这些正是编写多线程程序时最需要注意的地方。
3.**提高应用程序响应**。这对图形界面的程序尤其有意义，当一个操作耗时很长时，整个系统都会等待这个操作，此时程序不会响应键盘、鼠标、菜单的操作，而使用多线程技术，将耗时长的操作（time consuming）置于一个新的线程，可以避免这种尴尬的情况。
4.**使多CPU系统更加有效**。操作系统会保证当线程数不大于CPU数目时，不同的线程运行于不同的CPU上。
5.**改善程序结构**。一个既长又复杂的进程可以考虑分为多个线程，成为几个独立或半独立的运行部分，这样的程序会利于理解和修改。
**缺点：**
1.线程之间的同步和加锁控制比较麻烦；
2.一个线程的崩溃可能影响到整个程序的稳定性；
3.线程的增加，线程本身调度的难度也相应增加；
# 线程的创建和退出
创建线程实际上就是确定调用该线程函数的入口点,线程的创建采用函数 pthread_create。**在线程创建以后,就开始运行相关的线程函数,在该函数运行完之后,线程就退出,这也是线程退出的一种方式。另一种线程退出的方式是使用函数 pthread_exit()函数,这是线程主动退出行为。**这里要注意的是,在使用线程函数时,不能随意使用 exit 退出函数进行出错处理,由于 exit 的作用是使调用进程终止,往往一个进程包括了多个线程,所以在线程中通常使用 pthread_exit 函数来代替进程中的退出函数 exit。
由于一个进程中的多个线程是共享数据段的,因此通常在线程退出之后,退出线程所占用的资源并不会随着线程的终止而得到释放。正如进程之间可以通过 wait()函数系统调用来同步终止并释放资源一样,线程之间也有类似的机制,那就是 pthread_join 函数。**pthread_join 函数可以用于将当前线程挂起,等待线程的结束。这个函数是一个线程阻塞函数,调用它的函数将一直等待直到被等待的线程结束为止,当函数返回时,被等待线程的资源被回收（不回收堆内存）。**
函数原型:
~~~c
#include <pthread.h>
int pthread_create(pthread_t* thread, pthread_attr_t * attr, void *(*start_routine)(void *), void * arg);
void pthread_exit(void *retval);
~~~
通常的形式为:
~~~c
pthread_t pthid;
pthread_create(&pthid,NULL,pthfunc,NULL);或 pthread_create(&pthid,NULL,pthfunc,(void*)3);
pthread_exit(NULL);或 pthread_exit((void*)3);//3 作为返回值被 pthread_join 函数捕获。
~~~
函数 pthread_create 用来创建线程。返回值:成功,则返回 0;失败,则返回对应错误码。各参数描述如下:
* 参数 thread 是传出参数,保存新线程的标识;
* 参数 attr 是一个结构体指针,结构中的元素分别指定新线程的运行属性,attr 可以用 pthread_attr_init 等函数设置各成员的值,但通常传入为 NULL 即可;
* 参数 start_routine 是一个函数指针,指向新线程的入口点函数,线程入口点函数带有一个 **void *的参数由 pthread_create 的第 4 个参数传入**;
* 参数 arg 用于传递给第 3 个参数指向的入口点函数的参数,可以为 NULL,表示不传递。

函数 pthread_exit 表示线程的退出。其参数可以被其它线程用 pthread_join 函数捕获。

示例：
~~~c
#include <stdio.h>
#include <pthread.h>
void *ThreadFunc(void *pArg)
//参数的值为 123
{
        int i = 0;
        for(; i<10; i++){
                        printf("Hi,I'm child thread,arg is:%d\n", (int)pArg);
                sleep(1);
        }
        pthread_exit(NULL);
}

int main()
{
	pthread_t thdId;
	pthread_create(&thdId, NULL, ThreadFunc, (void *)123 );
	int i = 0;
	for(; i<10; i++)
	{
		printf("Hi,I'm main thread,child thread id is:%x\n", thdId);
		sleep(1);
	}
	return 0;
}
~~~

输出：
```
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
Hi,I'm child thread,arg is:123
Hi,I'm main thread,child thread id is:2732a700
```

# 线程的等待和退出
## 等待线程退出
线程从入口点函数自然返回,或者主动调用 pthread_exit()函数,都可以让线程正常终止。**线程从入口点函数自然返回时,函数返回值可以被其它线程用 pthread_join 函数获取;如果线程通过调用 pthread_exit()终止,则pthread_exit()中的参数相当于自然返回值,照样可以被其它线程用 pthread_join 获取到。**
pthread_join 原型为:
~~~c
#include <pthread.h>
int pthread_join(pthread_t th, void **thread_return);
~~~
1.该函数是一个阻塞函数,一直等到参数 th 指定的线程返回;与多进程中的 wait 或 waitpid 类似。
示例：
~~~c
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
void *ThreadFunc(void *pArg)
{
	int iArg = (int)pArg; //将 void*转换为 int
	sleep(iArg);
	if(iArg < 3)
		return (void *)(iArg*2);
	else
	pthread_exit((void *)(iArg*2)); //和 reaturn 达到的效果一样,都可以用于正常返回
}
int main()
{
	pthread_t thdId;
	int iRet = 0;
	pthread_create(&thdId, NULL, ThreadFunc, (void *)2 ); //传递参数值为 2
	pthread_join(thdId,(void **)&iRet); //接收子线程的返回值
	printf("The first child thread ret is:%d\n",iRet);
	pthread_create(&thdId, NULL, ThreadFunc, (void *)4 );
	pthread_join(thdId,(void **)&iRet);
	printf("The second child thread ret is:%d\n",iRet);
	return 0;
}	
~~~	
输出：
~~~c
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
The first child thread ret is:4
The second child thread ret is:8
~~~
2.该函数还有一个非常重要的作用,由于一个进程中的多个线程共享数据段,因此通常在一个线程退出后,退出线程所占用的资源并不会随线程结束而释放。如果 th 线程类型并不是自动清理资源类型的,则 th 线程退出后,线程本身的资源必须通过其它线程调用 pthread_join 来清除,这相当于多进程程序中的 waitpid。
示例:子线程释放空间
~~~c
#include <stdio.h>
#include <pthread.h>
#include <malloc.h>
void* threadfunc(void *args)
{
	char *p = (char*)malloc(10);
	//自己分配了堆内存
	int i = 0;
	for(; i < 10; i++)
	{
		printf("hello,my name is asensio!\n");
		sleep(1);
	}
	free(p); //如果父线程中没有调用 pthread_cancel,此处将会执行
	printf("p is freed\n");
	pthread_exit((void*)3);
}
int main()
{
	pthread_t pthid;
	pthread_create(&pthid, NULL, threadfunc, NULL);
	int i = 1;
	for(; i < 5; i++)
	//父线程的运行次数比子线程的要少,当父线程结束的时候,如果没有pthread_join 函数等待子线程执行的话,子线程也会退出。
	{
		printf("hello,nice to meet you!\n");
		sleep(1);
		// if(i % 3 == 0)
		//pthread_cancel(pthid); //表示当 i%3==0 的时候就取消子线程,该函数将导致子线程直接退出(retvalue的返回值为-1),不会执行上面的 free 部分的代码,即释放空间失败。要想释放指针类型的变量p,此时必须要用 pthread_cleanup_push 和 pthread_cleanup_pop 函数释放空间,见后面的例子
	}
	int retvalue = 0;
	pthread_join(pthid,(void**)&retvalue); //等待子线程释放空间,并获取子线程的返回值
	printf("return value is :%d\n",retvalue);
	return 0;
}
~~~
pthread_join 不回收堆内存的,只回收线程的栈内存和内核中的 struct task_struct 结构占用的内存。
输出：
```
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
hello,nice to meet you!
hello,my name is wangxiao!
hello,nice to meet you!
hello,my name is wangxiao!
hello,nice to meet you!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,nice to meet you!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,my name is wangxiao!
p is freed
return value is :3
```
## 线程终止清理函数
一般来说，Posix的线程终止有两种情况：正常终止和非正常终止。
* 正常退出：线程主动调用pthread_exit()或者从线程函数中return都将使线程正常退出，这是可预见的退出方式；
* 非正常终止：非正常终止是线程在其他线程的干预下，或者由于自身运行出错（比如访问非法地址）而退出，这种退出方式是不可预见的。
不论是可预见的线程终止还是异常终止,都会存在资源释放的问题,在不考虑因运行出错而退出的前提下,如何保证线程终止时能顺利的释放掉自己所占用的资源,特别是锁资源,就是一个必须考虑解决的问题。
最经常出现的情形是资源独占锁的使用:线程为了访问临界共享资源而为其加上锁,但在访问过程中该线程被外界取消,或者发生了中断,则该临界资源将永远处于锁定状态得不到释放。外界取消操作是不可预见的,因此的确需要一个机制来简化用于资源释放的编程。
在 POSIX 线程 API 中提供了一个** pthread_cleanup_push()/pthread_cleanup_pop()**函数对用于自动释放资源--从 pthread_cleanup_push()的调用点到 pthread_cleanup_pop()之间的程序段中的终止动作都将执行 pthread_cleanup_push()所指定的清理函数。API 定义如下:
~~~c
void pthread_cleanup_push(void (*routine) (void *), void *arg)
void pthread_cleanup_pop(int execute)
~~~
pthread_cleanup_push()/pthread_cleanup_pop()采用先入后出的栈结构管理.
void routine(void *arg)函数在调用 pthread_cleanup_push()时压入清理函数栈,多次对pthread_cleanup_push()的调用将在清理函数栈中形成一个函数链,在执行该函数链时按照压栈的相反顺序弹出。execute 参数表示执行到 pthread_cleanup_pop()时是否在弹出清理函数的同时执行该函数,为 0 表示不执行,非 0 为执行,但这个参数并不影响`异常终止`时清理函数的执行( execute 如果为非 0 值,则按栈的顺序注销掉一个原来注册的清理函数,并执行该函数;当为 0 时,仅仅在线程调用 pthread_exit 函数或者其它线程对本线程调用 pthread_cancel 函数时,才在弹出“清理函数”的同时执行该“清理函数")。
**通俗地讲：pthread_cleanup_push注册一个回调函数，如果你的线程在对应的pthread_cleanup_pop之前异常退出(return是正常退出，其他是异常)，那么系统就会执行这个回调函数(回调函数要做什么你自己决定)。但是如果在pthread_cleanup_pop之前没有异常退出，pthread_cleanup_pop就把对应的回调函数取消了**
pthread_cleanup_push()/pthread_cleanup_pop()是以宏方式实现的,这是 pthread.h 中的宏定义:
~~~c
#define pthread_cleanup_push(routine,arg) \
{
	struct _pthread_cleanup_buffer _buffer; \
	_pthread_cleanup_push (&_buffer, (routine), (arg));
#define pthread_cleanup_pop(execute) \
	_pthread_cleanup_pop (&_buffer, (execute));
}
~~~
**可见,pthread_cleanup_push()带有一个"{",而 pthread_cleanup_pop()带有一个"}",因此这两个函数必须成对出现,且必须位于程序的同一级别的代码段中才能通过编译。**
示例：
~~~c
#include <stdio.h>
#include <pthread.h>
void CleanFunc(void *pArg)
{
	printf("CleanFunc(%d)\n",(int)pArg);
}
void *ThreadFunc(void *pArg)
{
	pthread_cleanup_push(CleanFunc,(void *)1);
	pthread_cleanup_push(CleanFunc,(void *)2);
	sleep(2);
	pthread_cleanup_pop(1);
	pthread_cleanup_pop(1);
}
int main()
{
	pthread_t thdId;
	pthread_create(&thdId, NULL, ThreadFunc, (void *)2);
	pthread_join(thdId,NULL);
	return 0;
}
~~~
运行结果为：
	CleanFunc(2)
	CleanFunc(1)
Example:用 pthread_cleanup_push 和 pthread_cleanup_pop 来释放子线程分配的内存空间
~~~c
#include <stdio.h>
#include <pthread.h>
#include <malloc.h>
void freemem(void * args)
{
	free(args);
	printf("clean up the memory!\n");
}
void* threadfunc(void *args)
{
	char *p = (char*)malloc(10);
	//自己分配了内存
	pthread_cleanup_push(freemem,p);
	int i = 0;
	for(; i < 10; i++)
	{
		printf("hello,my name is wangxiao!\n");
		sleep(1);
	}
	pthread_exit((void*)3);
	pthread_cleanup_pop(0);
}
int main()
{
	pthread_t pthid;
	pthread_create(&pthid, NULL, threadfunc, NULL);
	int i = 1;
	for(; i < 5; i++)
	//父线程的运行次数比子线程的要少,当父线程结束的时候,如果没pthread_join 函数等待子线程执行的话,子线程也会退出,即子线程也只执行了 4 次。
	{
		printf("hello,nice to meet you!\n");
		sleep(1);
		if(i % 3 == 0)
pthread_cancel(pthid); //表示当 i%3==0 的时候就取消子线程,该函数将导致子线程异常退出。要想释放指针类型的变量 p,必须要用 pthread_cleanup_push 和 pthread_cleanup_pop 函数释放空间
	}
	int retvalue = 0;
	printf("return value is :%d\n",retvalue);
	return 0;
}
~~~
输出结果为：
~~~c
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
hello,nice to meet you!
hello,my name is wangxiao!
hello,nice to meet you!
hello,my name is wangxiao!
hello,nice to meet you!
hello,my name is wangxiao!
hello,my name is wangxiao!
hello,nice to meet you!
clean up the memory!
return value is :0
~~~
# 线程的同步和互斥
## 线程的互斥
在 Posix Thread 中定义了一套专门用于线程互斥的 mutex 函数。mutex 是一种简单的加锁的方法来控制对共享资源的存取,这个互斥锁只有两种状态(上锁和解锁),可以把互斥锁看作某种意义上的全局变量。为什么需要加锁,就是因为多个线程共用进程的资源,要访问的是公共区间时(全局变量),当一个线程访问的时候,需要加上锁以防止另外的线程对它进行访问,实现资源的独占。在一个时刻只能有一个线程掌握某个互斥锁,拥有上锁状态的线程能够对共享资源进行操作。若其他线程希望上锁一个已经上锁了的互斥锁,则该线程就会挂起,直到上锁的线程释放掉互斥锁为止。
**1.创建和销毁锁**
有两种方法创建互斥锁,静态方式和动态方式。
* 静态方式:
POSIX 定义了一个宏 PTHREAD_MUTEX_INITIALIZER 来静态初始化互斥锁,方法如下:
~~~c
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
~~~
在 Linux Threads 实现中,pthread_mutex_t 是一个结构,而 PTHREAD_MUTEX_INITIALIZER 则是一个宏常量。
* 动态方式:
动态方式是采用 pthread_mutex_init()函数来初始化互斥锁,API 定义如下:
```c
#include <pthread.h>
int pthread_mutex_init(pthread_mutex_t *mutex, const pthread_mutexattr_t *mutexattr)
```
其中 mutexattr 用于指定互斥锁属性(见下),如果为 NULL 则使用缺省属性。通常为 NULL。
pthread_mutex_destroy()用于注销一个互斥锁,API 定义如下:
~~~c
int pthread_mutex_destroy(pthread_mutex_t *mutex);
~~~
销毁一个互斥锁即意味着释放它所占用的资源,且要求锁当前处于开放状态。由于在 Linux 中,互斥锁并不占用任何资源,因此 Linux Threads 中的 pthread_mutex_destroy()除了检查锁状态以外(锁定状态则返回 EBUSY)没有其他动作。


**2. 互斥锁属性**
互斥锁属性结构体的定义为:
~~~c
typedef struct
{
int __mutexkind;
//注意这里是两个下划线
} pthread_mutexattr_t;
~~~
互斥锁的属性在创建锁的时候指定,在 LinuxThreads 实现中仅有一个锁类型属性__mutexkind,不同的锁类型在试图对一个已经被锁定的互斥锁加锁时表现不同也就是是否阻塞等待。有三个值可供选择:
* PTHREAD_MUTEX_TIMED_NP,这是缺省值(直接写 NULL 就是表示这个缺省值),也就是普通锁(或快速锁)。当一个线程加锁以后,其余请求锁的线程将形成一个阻塞等待队列,并在解锁后按优先级获得锁。这种锁策略保证了资源分配的公平性示例:初始化一个快速锁。
~~~c
pthread_mutex_t lock;
pthread_mutex_init(&lock, NULL);
~~~

* PTHREAD_MUTEX_RECURSIVE_NP,嵌套锁,允许同一个线程对同一个锁成功获得多次,并通过多次 unlock 解锁。如果是不同线程请求,则在加锁线程解锁时重新竞争。
示例:初始化一个嵌套锁。
~~~c
pthread_mutex_t lock;
pthread_mutexattr_t mutexattr;
mutexattr.__mutexkind = PTHREAD_MUTEX_RECURSIVE_NP;
pthread_mutex_init(&lock, &mutexattr);
~~~
* PTHREAD_MUTEX_ERRORCHECK_NP,检错锁 ,如果同一个 线程请求同一个锁,则返回EDEADLK,否则与 PTHREAD_MUTEX_TIMED_NP 类型动作相同。这样就保证当不允许多次加锁时不会出现最简单情况下的死锁。如果锁的类型是快速锁,一个线程加锁之后,又加锁,则此时就是死锁。
示例:初始化一个检错锁。
~~~c
pthread_mutex_t lock;
pthread_mutexattr_t mutexattr;
mutexattr.__mutexkind = PTHREAD_MUTEX_ERRORCHECK_NP;
pthread_mutex_init(&lock, &mutexattr);
~~~
**3.锁操作**
锁操作主要包括
加锁
int pthread_mutex_lock(pthread_mutex_t *mutex)
解锁
int pthread_mutex_unlock(pthread_mutex_t *mutex)
测试加锁
int pthread_mutex_trylock(pthread_mutex_t *mutex)
* pthread_mutex_lock:加锁,不论哪种类型的锁,都不可能被两个不同的线程同时得到,而必须等待解锁。**对于普通锁类型,解锁者可以是同进程内任何线程;而检错锁则必须由加锁者解锁才有效,否则返回 EPERM;**对于嵌套锁,文档和实现要求必须由加锁者解锁,但实验结果表明并没有这种限制,这个不同目前还没有得到解释。在同一进程中的线程,如果加锁后没有解锁,则任何其他线程都无法再获得锁。
* pthread_mutex_unlock:根据不同的锁类型,实现不同的行为:
对于快速(普通锁)锁,pthread_mutex_unlock 解除锁定;
对于递规锁,pthread_mutex_unlock 使锁上的引用计数减 1;
对于检错锁,如果锁是当前线程锁定的,则解除锁定,否则什么也不做。
* pthread_mutex_trylock:语义与 pthread_mutex_lock()类似,不同的是在锁已经被占据时返回 EBUSY而不是挂起等待。
Example:比较 pthread_mutex_trylock()与 pthread_mutex_lock()
~~~c
#include <stdio.h>
#include <pthread.h>
pthread_mutex_t lock;
void* pthfunc(void *args)
{
	pthread_mutex_lock(&lock);
	//先加一次锁
	pthread_mutex_lock(&lock);
	//再用 lock 加锁,会挂起阻塞
	//pthread_mutex_trylock(&lock); //用 trylock 加锁,则不会挂起阻塞
	printf("hello\n");
	sleep(1);
	pthread_exit(NULL);
}
main()
{
	pthread_t pthid = 0;
	pthread_mutex_init(&lock,NULL);//普通锁
	pthread_create(&pthid,NULL,pthfunc,NULL);
	pthread_join(pthid,NULL);
	pthread_mutex_destroy(&lock);
}
~~~
**4.加锁注意事项**
如果线程在加锁后解锁前被取消,锁将永远保持锁定状态,因此如果在关键区段内有取消点存在,
则必须在退出回调函数 pthread_cleanup_push/pthread_cleanup_pop 中解锁。
**5.互斥锁实例**
Example:火车站售票(此处不加锁,则会出现卖出负数票的情况)
~~~c
#include <stdio.h>
#include <pthread.h>
int ticketcount = 20;
//火车票,公共资源(全局)
void* salewinds1(void* args)
//售票口 1
{
	while(ticketcount > 0)
	//如果有票,则卖票
	{
		printf("windows1 start sale ticket!the ticket is:%d\n",ticketcount);
		sleep(3);
		//卖一张票需要 3 秒的操作时间
		ticketcount --;
		//出票
		printf("sale ticket finish!,the last ticket is:%d\n",ticketcount);
	}
}
void* salewinds2(void* args)
//售票口 2
{
	while(ticketcount > 0)
	//如果有票,则卖票
	{
		printf("windows2 start sale ticket!the ticket is:%d\n",ticketcount);
		sleep(3);
		//卖一张票需要 3 秒的操作时间
		ticketcount --;
		//出票
		printf("sale ticket finish!,the last ticket is:%d\n",ticketcount);
	}
}
int main()
{
	pthread_t pthid1 = 0;
	pthread_t pthid2 = 0;
	pthread_create(&pthid1,NULL,salewinds1,NULL);
	pthread_create(&pthid2,NULL,salewinds2,NULL);
	//线程 1
	//线程 2
	pthread_join(pthid1,NULL);
	pthread_join(pthid2,NULL);
	return 0;
}
~~~
Example:加锁之后的火车售票
~~~c
#include <stdio.h>
#include <pthread.h>
int ticketcount = 20;
pthread_mutex_t lock;
void* salewinds1(void* args)
{
	while(1)
	{
		pthread_mutex_lock(&lock); //因为要访问全局的共享变量,所以就要加锁
		if(ticketcount > 0) //如果有票
		{
			printf("windows1 start sale ticket!the ticket is:%d\n",ticketcount);
			sleep(3);//卖一张票需要 3 秒的操作时间
			ticketcount --;//出票
			printf("sale ticket finish!,the last ticket is:%d\n",ticketcount);
		}
		else		//如果没有票
		{
			pthread_mutex_unlock(&lock);	//解锁
			pthread_exit(NULL);//退出线程

		}
		pthread_mutex_unlock(&lock);//解锁
		sleep(1);//要放到锁的外面,让另一个线程有时间锁
	}
}
void* salewinds2(void* args)
{
	while(1)
	{
		pthread_mutex_lock(&lock); //因为要访问全局的共享变量,所以就要加锁
		if(ticketcount>0) //如果有票
		{
			printf("windows2 start sale ticket!the ticket is:%d\n",ticketcount);
			sleep(3);//卖一张票需要 3 秒的操作时间
			ticketcount --;//出票
			printf("sale ticket finish!,the last ticket is:%d\n",ticketcount);
		}
		else//如果没有票
		{
			pthread_mutex_unlock(&lock);//解锁
			pthread_exit(NULL);//退出线程
		}
		pthread_mutex_unlock(&lock);//解锁
		sleep(1);//要放到锁的外面,让另一个有时间锁
	}
}
int main()
{
	pthread_t pthid1 = 0;
	pthread_t pthid2 = 0;
	pthread_mutex_init(&lock,NULL); //初始化锁
	pthread_create(&pthid1,NULL,salewinds1,NULL);//线程 1
	pthread_create(&pthid2,NULL,salewinds2,NULL);//线程 2
	pthread_join(pthid1,NULL);
	pthread_join(pthid2,NULL);
	pthread_mutex_destroy(&lock);//销毁锁
	return 0;
}
~~~
总结:线程互斥 mutex:加锁步骤如下:
* 1. 定义一个全局的 pthread_mutex_t lock; 或者用pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER; //则 main 函数中不用 init
* 2. 在 main 中调用 pthread_mutex_init 函数进行初始化
* 3. 在子线程函数中调用 pthread_mutex_lock 加锁
* 4. 在子线程函数中调用 pthread_mutex_unlock 解锁
* 5. 最后在 main 中调用 pthread_mutex_destroy 函数进行销毁
## 线程的同步
### 条件变量
条件变量与互斥锁不同，互斥锁是防止多线程同时访问共享的互斥变量来保护临界区。条件变量是多线程间可以通过它来告知其他线程某个状态发生了改变，让等待在这个条件变量的线程继续执行。通俗一点来讲：设置一个条件变量让线程1等待在一个临界区的前面，当其他线程给这个变量执行通知操作时，线程1才会被唤醒，继续向下执行。
条件变量总是和互斥量一起使用，互斥量保护着条件变量，防止多个线程对条件变量产生竞争。等会写个小例子，看它们如何一起合作！
**1、 创建和注销**
条件变量和互斥锁一样,都有静态、动态两种创建方式:
静态方式使用 PTHREAD_COND_INITIALIZER 常量,如下:
~~~c
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
~~~
动态方式调用 pthread_cond_init()函数,API 定义如下:
~~~c
int pthread_cond_init(pthread_cond_t *cond, pthread_condattr_t *cond_attr);
~~~
尽管 POSIX 标准中为条件变量定义了属性,但在 Linux Threads 中没有实现,因此 cond_attr 值通常为 NULL,且被忽略。

注销一个条件变量需要调用** pthread_cond_destroy()**,只有在没有线程在该条件变量上等待的时候能注销这个条件变量,否则返回 EBUSY。因为 Linux 实现的条件变量没有分配什么资源,所以注销动作只包括检查是否有等待线程。API 定义如下:
~~~c
int pthread_cond_destroy(pthread_cond_t *cond);
~~~

**2、 等待和激发**
等待条件有两种方式:无条件等待 pthread_cond_wait()和计时等待 pthread_cond_timedwait():
~~~c
int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);
int pthread_cond_timedwait(pthread_cond_t *cond, pthread_mutex_t *mutex, const struct timespec *abstime);
~~~
线程解开 mutex 指向的锁并被条件变量 cond 阻塞。 其中计时等待方式表示 经历 abstime 段时间后,即使条件变量不满足,阻塞也被解除。 无论哪种等待方式,都必须和一个互斥锁配合,以防止多个线程同时请求 pthread_cond_wait()(或 pthread_cond_timedwait(),下同)的竞争条件(Race Condition)。mutex互斥锁必须是普通锁(PTHREAD_MUTEX_TIMED_NP),且在调用 pthread_cond_wait()前必须由本线程加锁(pthread_mutex_lock()),而在更新条件等待队列以前,mutex 保持锁定状态,并在线程挂起进入等待前解锁。在条件满足从而离开 pthread_cond_wait()之前,mutex 将被重新加锁,以与进入pthread_cond_wait()前的加锁动作对应。(也就是说在做 pthread_cond_wait 之前,往往要用pthread_mutex_lock 进行加锁,而调用 pthread_cond_wait 函数会将锁解开,然后将线程挂起阻塞。直到条件被 pthread_cond_signal 激发,再将锁状态恢复为锁定状态,最后再用 pthread_mutex_unlock 进行解锁)。

激发条件有两种形式,pthread_cond_signal()激活一个等待该条件的线程,存在多个等待线程时按入队顺序激活其中一个;而 pthread_cond_broadcast()则激活所有等待线程
**3、 其他**
pthread_cond_wait()和 pthread_cond_timedwait()都被实现为取消点,也就是说如果pthread_cond_wait()被取消,则退出阻塞,然后将锁状态恢复,则此时 mutex 是保持锁定状态的,而当前线程已经被取消掉,那么解锁的操作就会得不到执行,此时锁得不到释放,就会造成死锁,因而需要定义退出回调函数来为其解锁。
以下示例集中演示了互斥锁和条件变量的结合使用,以及取消对于条件等待动作的影响。在例子中,有两个线程被启动,并等待同一个条件变量,如果不使用退出回调函数(见范例中的注释部分),则 tid2 将在 pthread_mutex_lock()处永久等待。如果使用回调函数,则 tid2 的条件等待及主线程的条件激发都能正常工作。