---
layout: post
title: Nginx-HTTP配置项的合并
draft: false
date: 2018-11-04 21:15:51
categories: Nginx
tags: 
- Nginx
permalink:
description:
cover_img:
toc-disable:
comments:
---
对于某一个http模块中的某一个命令来说，它可能出现的区域有http{} server{} locaton{},如果在某一个server{}块内没有这个命令 那么它就需要从http{}中继承这个命令，如果某个server{}中存在这个命令，那么就不需要从http{}中继承；如果server{}中的某一个location{}中没有这个命令，那么就需要从上层（server{}层或者location{}层）继承。怎么合并（使用函数merge_srv_conf和merge_loc_conf函数回调）也是模块本身定义的。
<!--more-->


主要是http、server、location，http作用域最大、server其次、location最精细化。合并的主要流程是，同一个模块中的上下文变量可以存在在不同的作用域，可以在配置文件中的http作用域，也可以在server作用域，还可以写在location作用域，如果该变量在server作用域没有设置，但是http作用域配置文件中设置了该值，那么server作用域的该值，就会被http作用域的合并掉，使用http作用的值，同理location和server合并。

```c++
static char *
ngx_http_block(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
    ...
    /*
     * init http{} main_conf's, merge the server{}s' srv_conf's
     * and its location{}s' loc_conf's
     */

    cmcf = ctx->main_conf[ngx_http_core_module.ctx_index];
    cscfp = cmcf->servers.elts;

    for (m = 0; cf->cycle->modules[m]; m++) {
        if (cf->cycle->modules[m]->type != NGX_HTTP_MODULE) {
            continue;
        }

        module = cf->cycle->modules[m]->ctx;
        mi = cf->cycle->modules[m]->ctx_index;

        /* init http{} main_conf's */

        if (module->init_main_conf) {
            rv = module->init_main_conf(cf, ctx->main_conf[mi]);
            if (rv != NGX_CONF_OK) {
                goto failed;
            }
        }

        rv = ngx_http_merge_servers(cf, cmcf, module, mi);
        if (rv != NGX_CONF_OK) {
            goto failed;
        }
    }

	...
}
```

ngx_http_merge_servers核心的两个函数是merge_srv_conf和merge_loc_conf,merge_srv_conf主要合并http和server server上下文，merge_loc_conf主要合并http和server的loc上下文

```c++
/*
ctx_index指的是该模块在同一类型中的位置
*/
static char *
ngx_http_merge_servers(ngx_conf_t *cf, ngx_http_core_main_conf_t *cmcf,
    ngx_http_module_t *module, ngx_uint_t ctx_index)
{
    char                        *rv;
    ngx_uint_t                   s;
    ngx_http_conf_ctx_t         *ctx, saved;
    ngx_http_core_loc_conf_t    *clcf;
    ngx_http_core_srv_conf_t   **cscfp;

    cscfp = cmcf->servers.elts;                     // cscfp指向所有http块下的所有server块
    ctx = (ngx_http_conf_ctx_t *) cf->ctx;          // ctx指向http块的ngx_http_conf_ctx_t结构
    saved = *ctx;
    rv = NGX_CONF_OK;
    //遍历http块下有所有server块
    for (s = 0; s < cmcf->servers.nelts; s++) {

        /* merge the server{}s' srv_conf's */
        
        ctx->srv_conf = cscfp[s]->ctx->srv_conf;    // 指向每一个server块中的srv_conf结构
        // 如果该模块实现了merge_srv_conf方法，则调用该方法来合并main级别和srv级别的server相关的结构体；
        if (module->merge_srv_conf) {
            //将http块中的某个server与server块中的某个server进行合并
			//saved.srv_conf[ctx_index]是http块下的srv_conf中某个元素
			//cscfp[s]->ctx->srv_conf[ctx_index]是server块下的srv_conf中某个元素
            rv = module->merge_srv_conf(cf, saved.srv_conf[ctx_index],
                                        cscfp[s]->ctx->srv_conf[ctx_index]);
            if (rv != NGX_CONF_OK) {
                goto failed;
            }
        }
        // 如果该模块实现了merge_loc_conf方法，先将main级别和srv级别的location相关的结构体合并，然后将srv级别和loc级别的location相关的结构体合并。
        if (module->merge_loc_conf) {

            /* merge the server{}'s loc_conf */

            ctx->loc_conf = cscfp[s]->ctx->loc_conf;
			// 首先将http{}块下main级别与server{}块下srv级别的location相关的结构体合并
            rv = module->merge_loc_conf(cf, saved.loc_conf[ctx_index],
                                        cscfp[s]->ctx->loc_conf[ctx_index]);
            if (rv != NGX_CONF_OK) {
                goto failed;
            }

            /* merge the locations{}' loc_conf's */

            clcf = cscfp[s]->ctx->loc_conf[ngx_http_core_module.ctx_index];
			// 调用ngx_http_merge_location方法，将server{}块与其所包含的location{}块下的结构体进行合并
            rv = ngx_http_merge_locations(cf, clcf->locations,
                                          cscfp[s]->ctx->loc_conf,
                                          module, ctx_index);
            if (rv != NGX_CONF_OK) {
                goto failed;
            }
        }
    }

failed:

    *ctx = saved;

    return rv;
}
```

```c++
static char *
ngx_http_merge_locations(ngx_conf_t *cf, ngx_queue_t *locations,
    void **loc_conf, ngx_http_module_t *module, ngx_uint_t ctx_index)
{
    char                       *rv;
    ngx_queue_t                *q;
    ngx_http_conf_ctx_t        *ctx, saved;
    ngx_http_core_loc_conf_t   *clcf;
    ngx_http_location_queue_t  *lq;

    // 如果location为空，表明当前server块下没有location块，则立刻返回
    if (locations == NULL) {
        return NGX_CONF_OK;
    }

    ctx = (ngx_http_conf_ctx_t *) cf->ctx;
    saved = *ctx;
    // 遍历location双向链表，即遍历该server{}块下的所有location{}块，server{}下的所有location{}块逐个和loc_conf[ctx_index]合并。
    for (q = ngx_queue_head(locations);
         q != ngx_queue_sentinel(locations);
         q = ngx_queue_next(q))
    {
        lq = (ngx_http_location_queue_t *) q;

        clcf = lq->exact ? lq->exact : lq->inclusive;
        ctx->loc_conf = clcf->loc_conf;

        rv = module->merge_loc_conf(cf, loc_conf[ctx_index],
                                    clcf->loc_conf[ctx_index]);
        if (rv != NGX_CONF_OK) {
            return rv;
        }
        // 处理嵌套的location{}块
        rv = ngx_http_merge_locations(cf, clcf->locations, clcf->loc_conf,
                                      module, ctx_index);
        if (rv != NGX_CONF_OK) {
            return rv;
        }
    }

    *ctx = saved;

    return NGX_CONF_OK;
}
```


