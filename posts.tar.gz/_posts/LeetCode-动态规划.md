---
title: LeetCode-动态规划
date: 2017-09-13 19:55:32
categories: LeetCode
tags: 
- LeetCode
- 动态规划
- 算法
copyright: true
---
# Unique Paths
## Description
A robot is located at the top-left corner of a m x n grid (marked 'Start' in the diagram below).

The robot can only move either down or right at any point in time. The robot is trying to reach the bottom-right corner of the grid (marked 'Finish' in the diagram below).

How many possible unique paths are there?
Above is a 3 x 7 grid. How many possible unique paths are there?

Note: m and n will be at most 100.
<!--more-->
## 思路
### 动态规划
对于任意一点(x,y)，要么是从(x,y)的左相邻点(x,y-1)过来，要么是从(x,y)的上相邻点(x-1,y)过来
所以，状态转移方程：dp[i][j] = dp[i-1][j] + dp[i][j-1]
初始化第一行和第一列，dp[0][j] = dp[i][0] = 1
优化：
其实不需要用m*n那么大的矩阵，只需要O(min(m,n))大小的一个一维数组就可以了，这样能把动态规划的空间复杂度再优化一下。
### 排列组合
m*n的棋盘，向下是m-1步，向上是n-1步。
在所有的m+n-2步中选择m-1步向下，因此总走法是C(m+n-2, m-1)
## 实现
```c++
//1.动态规划解法
class Solution { 
    public: 
    int uniquePaths(int m, int n) { 
        int dp[m][n]; 
        for (int i = 0; i < m; i++) { 
            dp[i][0] = 1; 
        } 
        for (int j = 0; j < n; j++) { 
            dp[0][j] = 1; 
        } 
        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) { 
                dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
            }
        } 
        return dp[m-1][n-1];
    } 
};

//２ 动态规划 , 空间复杂度由O(m*n)变化为O(min(m,n));  
class Solution {  
public:  
    int uniquePaths(int m, int n) {  
        int s=(m<n)?m:n;  
        int l=(m>n)?m:n;  
        int * arr= new int [s];  
        for(int j=0;j<s;j++)  
            arr[j]=1;  
        for(int i=1;i<l;i++){  
            for(int j=1;j<s;j++){  
                arr[j]+=arr[j-1];  
            }  
        }  
        return arr[s-1];  
    }  
};

//3.排列组合解法
class Solution {
public:
    // 一共走（m-1）+（n-1）步, 从其中选择m-1步向下
    // 所以总的走法是C(m+n-2, m-1)
    int uniquePaths(int m, int n) {
        m--; n--;
        long long mn = m + n;
        long long mn_max = max(m, n);
        long long mn_min = min(m, n);
        long long c = 1;
        for (int i = mn_max + 1; i <= mn; i++) {
            c *= i;
        }
        for (int j = 2; j <= mn_min; j++) {
            c /= j;
        }
        return c;
    }
};
```
# Maximum Subarray
## Description
 Find the contiguous subarray within an array (containing at least one number) which has the largest sum.

For example, given the array [-2,1,-3,4,-1,2,1,-5,4],
the contiguous subarray [4,-1,2,1] has the largest sum = 6. 
## 思路
当从头到尾遍历这个数组的时候，对于数组中的一个整数，它只要有两种选择：１．加入之前的Subarrya；２．自己另起一个Subarray．
如果之前的Subarray的总体和大于０的话，我们认为其对后续结果时有贡献的，这种情况下将其加入倒之前的Subarray.
如果之前的Subarray的总体和为０或者小于０的话，我们认为其对后续结果是没有贡献的，甚至是有害的．这种情况下我们选择以这个数字开始，另起一个Subarray.

设状态费f[i]，表示S[j]结尾的最大连续子序列和，则状态转移方程如下：
f[j]=max(f[j-1]+s[j],s[j])
target=max(f[j])
## 实现
```
class Solution {
public:
    int maxSubArray(vector<int>& nums) {
        int result = INT_MIN;
        int f=0;
        for(int i=0;i<nums.size();i++){
            f=max(f+nums[i],nums[i]);
            result=max(result,f);
        }
        return result;
    }
};
```
# Decode ways
## Description
 A message containing letters from A-Z is being encoded to numbers using the following mapping:

'A' -> 1
'B' -> 2
...
'Z' -> 26

Given an encoded message containing digits, determine the total number of ways to decode it.

For example,
Given encoded message "12", it could be decoded as "AB" (1 2) or "L" (12).

The number of ways decoding "12" is 2. 
## 思路
解码是有规律的，所以我们可以尝试动态规划。假设数组dp[i]表示从头到字符串的第i位，一共有多少种解码方法的话，那么如果字符串的第i-1位和第i位能组成一个10到26的数字，说明我们是在第i-2位的解码方法上继续解码。如果字符串的第i-1位和第i位不能组成有效二位数字，而且第i位不是0的话，说明我们是在第i-1位的解码方法上继续解码。所以，如果两个条件都符合，则dp[i]=dp[i-1]+dp[i-2]，否则dp[i]=dp[i-1]。
## 实现
```
class Solution {
public:
    int numDecodings(string s) {
        if (s.empty() || (s.size() > 1 && s[0] == '0')) return 0;
        vector<int> dp(s.size() + 1, 0);
        dp[0] = 1;
        for (int i = 1; i < dp.size(); ++i) {
            dp[i] = (s[i - 1] == '0') ? 0 : dp[i - 1];
            if (i > 1 && (s[i - 2] == '1' || (s[i - 2] == '2' && s[i - 1] <= '6'))) {
                dp[i] += dp[i - 2];
            }
        }
        return dp.back();
    }
};
```
# Interleaving String
## Description
 Given s1, s2, s3, find whether s3 is formed by the interleaving of s1 and s2.

For example,
Given:
s1 = "aabcc",
s2 = "dbbca",

When s3 = "aadbbcbcac", return true.
When s3 = "aadbbbaccc", return false. 
## 思路
dp[i][j] 表示 s2 的前 i 个字符和 s1 的前 j 个字符是否匹配 s3 的前 i+j 个字符。

初始化dp[0][0]=0，dp[0][j]表示s1的前j个字符是否匹配s3的前j个字符；dp[i][0]表示s2的前i个字符，是否匹配s3的前i个字符。

动规方程：dp[i][j] = dp[i - 1][j] && s2[i - 1] == s3[i + j - 1]  ||  dp[i][j - 1] && s1[i][j - 1] == s3[i + j - 1] ，意思是如果s2的前i-1个字符和s1的前j个字符已经和s3的前i+j-1个字符匹配且s2的第i个字符等于s3的第i+j个字符，或者，s2的前i个字符和s1的前j-1个字符已经和s3的前i+j-1个字符匹配且s1的第j个字符等于s3的第i+j个字符，那么s2的前i个字符和s1的前j个字符能否与s3的前i+j-1个字符匹配。
示例：s1="aa",s2="ab",s3="aaba"。标1的为可行。最终返回右下角。
```
     0  a  b

0   1  1  0

a   1  1  1

a   1  0  1
```
## 实现
```c++
class Solution {
public:
    bool isInterleave(string s1, string s2, string s3) {
        int m = s1.size();
        int n = s2.size();
        if(m+n != s3.size())
            return false;
        vector<vector<bool> > path(m+1, vector<bool>(n+1, false));
        for(int i = 0; i < m+1; i ++)
        {
            for(int j = 0; j < n+1; j ++)
            {
                if(i == 0 && j == 0)
                // start
                    path[i][j] = true;
                else if(i == 0)
                    path[i][j] = path[i][j-1] & (s2[j-1]==s3[j-1]);
                else if(j == 0)
                    path[i][j] = path[i-1][j] & (s1[i-1]==s3[i-1]);
                else
                    path[i][j] = (path[i][j-1] & (s2[j-1]==s3[i+j-1])) || (path[i-1][j] & (s1[i-1]==s3[i+j-1]));
            }
        }
        return path[m][n];
    }
};
```
# Climbing Stairs
## Description
You are climbing a stair case. It takes n steps to reach to the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?

Note: Given n will be a positive integer.

Example 1:
```
Input: 2
Output: 2
Explanation: There are two ways to climb to the top.
1. 1 step + 1 step
2. 2 steps
```
Example 2:
```
Input: 3
Output: 3
Explanation: There are three ways to climb to the top.
1. 1 step + 1 step + 1 step
2. 1 step + 2 steps
3. 2 steps + 1 step
```
## 实现
```
class Solution {
public:
    int climbStairs(int n) {
        if(n == 1)
            return 1;
        if(n == 2)
            return 2;
        vector<int> array;
        array.push_back(1);
        array.push_back(2);
        for(int i=2; i<n; i++) {
            array.push_back(array[i-1] + array[i-2]);
        }
        
        return array[n-1];
    }
};
```
# Min Cost Climbing Stairs
## Descriptiom
 On a staircase, the i-th step has some non-negative cost cost[i] assigned (0 indexed).

Once you pay the cost, you can either climb one or two steps. You need to find minimum cost to reach the top of the floor, and you can either start from the step with index 0, or the step with index 1.

Example 1:
```
Input: cost = [10, 15, 20]
Output: 15
Explanation: Cheapest is start on cost[1], pay that cost and go to the top.
```
Example 2:
```
Input: cost = [1, 100, 1, 1, 1, 100, 1, 1, 100, 1]
Output: 6
Explanation: Cheapest is start on cost[0], and only step on 1s, skipping cost[3].
```
Note:
```
    cost will have a length in the range [2, 1000].
    Every cost[i] will be an integer in the range [0, 999].
```
## 实现
```
class Solution {
public:
    int minCostClimbingStairs(vector<int>& cost) {
        for(int i = 2; i<cost.size(); i++) {
            cost[i] += min(cost[i-1], cost[i-2]);
        }
        
        return min(cost[cost.size()-1], cost[cost.size()-2]);
    }
};
```
