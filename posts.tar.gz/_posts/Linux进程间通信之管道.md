---
title: Linux进程间通信之管道
date: 2018-02-20 20:32:20
categories: Linux
tags: 
copyright:
---
转自：[https://www.ibm.com/developerworks/cn/linux/l-ipc/](https://www.ibm.com/developerworks/cn/linux/l-ipc/) 
 
 linux下进程间通信的几种主要手段简介：
* 管道（Pipe）及有名管道（named pipe）：管道可用于具有亲缘关系进程间的通信，有名管道克服了管道没有名字的限制，因此，除具有管道所具有的功能外，它还允许无亲缘关系进程间的通信；
* 信号（Signal）：信号是比较复杂的通信方式，用于通知接受进程有某种事件发生，除了用于进程间通信外，进程还可以发送信号给进程本身；linux除了支持Unix早期信号语义函数sigal外，还支持语义符合Posix.1标准的信号函数sigaction（实际上，该函数是基于BSD的，BSD为了实现可靠信号机制，又能够统一对外接口，用sigaction函数重新实现了signal函数）；
* 报文（Message）队列（消息队列）：消息队列是消息的链接表，包括Posix消息队列system V消息队列。有足够权限的进程可以向队列中添加消息，被赋予读权限的进程则可以读走队列中的消息。消息队列克服了信号承载信息量少，管道只能承载无格式字节流以及缓冲区大小受限等缺点。
* 共享内存：使得多个进程可以访问同一块内存空间，是最快的可用IPC形式。是针对其他通信机制运行效率较低而设计的。往往与其它通信机制，如信号量结合使用，来达到进程间的同步及互斥。
* 信号量（semaphore）：主要作为进程间以及同一进程不同线程之间的同步手段。
* 套接口（Socket）：更为一般的进程间通信机制，可用于不同机器之间的进程间通信。起初是由Unix系统的BSD分支开发出来的，但现在一般可以移植到其它类Unix系统上：Linux和System V的变种都支持套接字。
<!--more-->
# 管道
在本系列序中作者概述了linux 进程间通信的几种主要手段。其中**管道**和**有名管道**是最早的进程间通信机制之一，管道可用于具有亲缘关系进程间的通信，有名管道克服了管道没有名字的限制，因此，除具有管道所具有的功能外，它还允许无亲缘关系进程间的通信。认清管道和有名管道的读写规则是在程序中应用它们的关键，本文在详细讨论了管道和有名管道的通信机制的基础上，用实例对其读写规则进行了程序验证，这样做有利于增强读者对读写规则的感性认识，同时也提供了应用范例。
## 管道概述及相关API应用
### 管道相关的关键概念
管道是Linux支持的最初Unix IPC形式之一，具有以下特点：
* 管道是半双工的，数据只能向一个方向流动；需要双方通信时，需要建立起两个管道；
* 只能用于父子进程或者兄弟进程之间（具有亲缘关系的进程）；
* 单独构成一种独立的文件系统：管道对于管道两端的进程而言，就是一个文件，但它不是普通的文件，它不属于某种文件系统，而是自立门户，单独构成一种文件系统，并且只存在与内存中。
* 数据的读出和写入：一个进程向管道中写的内容被管道另一端的进程读出。写入的内容每次都添加在管道缓冲区的末尾，并且每次都是从缓冲区的头部读出数据。
### 管道的创建
~~~c
#include <unistd.h>
int pipe(int fd[2])
~~~
该函数创建的管道的两端处于一个进程中间，在实际应用中没有太大意义，因此**，一个进程在由pipe()创建管道后，一般再fork一个子进程，然后通过管道实现父子进程间的通信**（因此也不难推出，只要两个进程中存在亲缘关系，这里的亲缘关系指的是**具有共同的祖先**，都可以采用管道方式来进行通信。
### 管道的读写规则
管道两端可分别用描述字fd[0]以及fd[1]来描述，需要注意的是，管道的两端是固定了任务的。即**一端只能用于读，由描述字fd[0]表示，称其为管道读端；另一端则只能用于写，由描述字fd[1]来表示，称其为管道写端。**如果试图从管道写端读取数据，或者向管道读端写入数据都将导致错误发生。一般文件的I/O函数都可以用于管道，如close、read、write等等。
向管道中写入数据：
向管道中写入数据时，linux将不保证写入的原子性，管道缓冲区一有空闲区域，写进程就会试图向管道写入数据。如果读进程不读走管道缓冲区中的数据，那么写操作将一直阻塞。 
    注：只有在管道的读端存在时，向管道中写入数据才有意义。否则，向管道中写入数据的进程将收到内核传来的SIFPIPE信号，应用程序可以处理该信号，也可以忽略（默认动作则是应用程序终止）。
**关于管道的读规则验证：**
~~~c
/**************
 * readtest.c *
 **************/
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
main()
{
       int pipe_fd[2];
       pid_t pid;
       char r_buf[100];
       char w_buf[4];
       char* p_wbuf;
       int r_num;
       int cmd;
       memset(r_buf,0,sizeof(r_buf));
       memset(w_buf,0,sizeof(r_buf));
       p_wbuf=w_buf;
       if(pipe(pipe_fd)<0)
       {
              printf("pipe create error\n");
              return -1;
       }
       if((pid=fork())==0)
       {
              printf("\n");
              close(pipe_fd[1]);
              sleep(3);//确保父进程关闭写端
              r_num=read(pipe_fd[0],r_buf,100);
              printf( "read num is %d   the data read from the pipe is %d\n",r_num,atoi(r_buf));
              close(pipe_fd[0]);
              exit(0);
       }
       else if(pid>0)
       {
       close(pipe_fd[0]);//read
       strcpy(w_buf,"111");
       if(write(pipe_fd[1],w_buf,4)!=-1)
              printf("parent write over\n");
       close(pipe_fd[1]);//write
       printf("parent close fd[1] over\n");
       sleep(10);
       }
}
~~~
fork()函数通过系统调用创建一个与原来进程几乎完全相同的进程，这个新产生的进程称为子进程。一个进程调用fork（）函数后，系统先给新的进程分配资源，例如存储数据和代码的空间。然后把原来的进程的所有值都复制到新的新进程中，只有少数值与原来的进程的值不同。相当于克隆了一个自己。需要注意的一点：就是调用fork函数之后，一定是两个进程同时执行的代码段是fork函数之后的代码，而之前的代码以及由父进程执行完毕。两个进程并发执行，谁先税后没有规律，由操作系统调度决定。
fork函数返回两个值:
* 返回一个大于0的值给父进程
* 返回0给子进程
* 返回其他值说明fork失败了
输出：
~~~
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
parent write over
parent close fd[1] over

read num is 4   the data read from the pipe is 111
~~~
附加结论：管道写端关闭后，写入的数据将一直存在，直到读出为止.
**对管道的写规则的验证2：linux不保证写管道的原子性验证**
~~~c
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
main(int argc,char**argv)
{
       int pipe_fd[2];
       pid_t pid;
       char r_buf[4096];
       char w_buf[4096*2];
       int writenum;
       int rnum;
       memset(r_buf,0,sizeof(r_buf));    
       if(pipe(pipe_fd)<0)
       {
              printf("pipe create error\n");
              return -1;
       }
       if((pid=fork())==0)
       {
              close(pipe_fd[1]);
              while(1)
              {
              	sleep(1); 
              	rnum=read(pipe_fd[0],r_buf,1000);
              	printf("child: readnum is %d\n",rnum);
              }
              close(pipe_fd[0]);
              exit(0);
       }
       else if(pid>0)
       {
       close(pipe_fd[0]);//write
       memset(r_buf,0,sizeof(r_buf));    
       if((writenum=write(pipe_fd[1],w_buf,1024))==-1)
              printf("write to pipe error\n");
       else 
              printf("the bytes write to pipe is %d \n", writenum);
       writenum=write(pipe_fd[1],w_buf,4096);
       close(pipe_fd[1]);
       }    
}
~~~
输出：
~~~
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ ./test
the bytes write to pipe is 1024 
maohao@maohao-HP-15-Notebook-PC:~/Documents/blog$ child: readnum is 1000
child: readnum is 1000
child: readnum is 1000
child: readnum is 1000
child: readnum is 1000
child: readnum is 120
child: readnum is 0
child: readnum is 0
child: readnum is 0
child: readnum is 0
^C
~~~
### 管道应用实例
实例:  用于shell
管道可用于输入输出重定向，它将一个命令的输出直接定向到另一个命令的输入。比如，当在某个shell程序（Bourneshell或C shell等）键入who│wc -l后，相应shell程序将创建who以及wc两个进程和这两个进程间的管道。考虑下面的命令行：
~~~
maohao@maohao-HP-15-Notebook-PC:~$ ls | grep Documents
Documents
~~~
### 管道的局限性
管道的主要局限性正体现在它的特点上：
* 只支持单向数据流；
* 只能用于具有亲缘关系的进程之间；
* 没有名字；
* 管道的缓冲区是有限的（管道制存在于内存中，在管道创建时，为缓冲区分配一个页面大小）；
* 管道所传送的是无格式字节流，这就要求管道的读出方和写入方必须事先约定好数据的格式，比如多少字节算作一个消息（或命令、或记录）等等；

## 有名管道概述及相关API应用
### 有名管道相关的关键概念
管道应用的一个重大限制是它没有名字，因此，只能用于具有亲缘关系的进程间通信，在有名管道（named pipe或FIFO）提出后，该限制得到了克服。FIFO不同于管道之处在于它提供一个路径名与之关联，以FIFO的文件形式存在于文件系统中。这样，即使与FIFO的创建进程不存在亲缘关系的进程，只要可以访问该路径，就能够彼此通过FIFO相互通信（能够访问该路径的进程以及FIFO的创建进程之间），因此，通过FIFO不相关的进程也能交换数据。值得注意的是，FIFO严格遵循先进先出（first in first out），对管道及FIFO的读总是从开始处返回数据，对它们的写则把数据添加到末尾。它们不支持诸如lseek()等文件定位操作。
### 有名管道的创建
~~~c
#include <sys/types.h>
#include <sys/stat.h>
int mkfifo(const char * pathname, mode_t mode)
~~~
该函数的第一个参数是一个普通的路径名，也就是创建后FIFO的名字。第二个参数与打开普通文件的open()函数中的mode 参数相同。如果mkfifo的第一个参数是一个已经存在的路径名时，会返回EEXIST错误，所以一般典型的调用代码首先会检查是否返回该错误，如果确实返回该错误，那么只要调用打开FIFO的函数就可以了。一般文件的I/O函数都可以用于FIFO，如close、read、write等等。
### 有名管道的打开规则
有名管道比管道多了一个打开操作：open。
**FIFO的打开规则：**
如果当前打开操作是为读而打开FIFO时，若已经有相应进程为写而打开该FIFO，则当前打开操作将成功返回；否则，可能阻塞直到有相应进程为写而打开该FIFO（当前打开操作设置了阻塞标志）；或者，成功返回（当前打开操作没有设置阻塞标志）。
如果当前打开操作是为写而打开FIFO时，如果已经有相应进程为读而打开该FIFO，则当前打开操作将成功返回；否则，可能阻塞直到有相应进程为读而打开该FIFO（当前打开操作设置了阻塞标志）；或者，返回ENXIO错误（当前打开操作没有设置阻塞标志）。