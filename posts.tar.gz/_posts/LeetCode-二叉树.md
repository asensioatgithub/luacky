---
layout: post
title: LeetCode-二叉树
draft: false
date: 2018-05-05 22:18:26
categories: LeetCode
tags:
- LeetCode
- 二叉树
- 算法
permalink:
description:
cover_img:
toc-disable:
comments:
---
# Maximum Depth of Binary Tree
## Description
Given a binary tree, find its maximum depth.

The maximum depth is the number of nodes along the longest path from the root node down to the farthest leaf node.

Note: A leaf is a node with no children.

Example:
```
Given binary tree [3,9,20,null,null,15,7],

    3
   / \
  9  20
    /  \
   15   7
```
return its depth = 3.
## 思路
1. 递归左右子树，从叶节点开始从下往上计算，父节点的高度等于左右子树的最大值加一
2. BFS层次遍历，整棵树的层数，即二叉树的最大深度。
## 实现
```c
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    /* DFS */
    int maxDepth(TreeNode* root) {
        if(root == NULL) return 0;
        int left = maxDepth(root->left);
        int right = maxDepth(root->right);
        return left>right?(left+1):(right+1);
    }
    /* BFS */
    int maxDepth(TreeNode* root)
    {
        if(!root)   return 0;
        queue<TreeNode*> Q;

        int nCount=1;    //某一层节点的个数
        int nDepth=0;    //层数

        //基于BFS，引入两个计数器
        Q.push(root);
        while(!Q.empty())
        {
            TreeNode* pCur=Q.front();
            Q.pop();
            nCount--;

            if(pCur->left)
                Q.push(pCur->left);
            if(pCur->right)
                Q.push(pCur->right);
            
            if(!nCount)     //保证遍历某一层时，深度不增加
            {
                nDepth++;
                nCount=Q.size();
            }
        }
        return nDepth;
    }
};
```
# Balanced Binary Tree
## Description
Given a binary tree, determine if it is height-balanced.

For this problem, a height-balanced binary tree is defined as:

    a binary tree in which the depth of the two subtrees of every node never differ by more than 1.

Example 1:
```
Given the following tree [3,9,20,null,null,15,7]:

    3
   / \
  9  20
    /  \
   15   7
```
Return true.
## 思路
1. 利用AVL的性质：它是一 棵空树或它的左右两个子树的高度差的绝对值不超过1，并且左右两个子树都是一棵平衡二叉树。算法复杂度O(n^2)。
2. 递归左右子树，从叶节点开始从下往上判断是否属于AVL。算法时间复杂度O(n)
## 实现
```c
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
   //思路1
    bool isBalanced(TreeNode* root) {
        if(root == NULL) return true;
        int left = depth(root->left);
        int right = depth(root->right);
        return abs(left-right)<=1 && isBalanced(root->left) && isBalanced(root->right);
    }
    int depth(TreeNode* node){
        if(node == NULL) return 0;
        return max(depth(node->left), depth(node->right)) + 1;
    }
    
    //思路2
    bool isBalanced(TreeNode* root) {
        if(root == NULL) return true;
        return helper(root)!=-1;
    }
    int helper(TreeNode* node){
        if(node == NULL) return 0;
        int left = helper(node->left);
        if(left == -1) return -1; //左子树非AVL，返回-1
        int right = helper(node->right);
        if(right == -1) return -1; //右子树非AVL，返回-1
        if(abs(left-right)<=1) return max(left,right)+1; /* 如果以node节点的子树属于AVL,则返回node的树高*/
        else return -1;  /*不属于AVL，返回-1*/
    }
    
};
```
# Invert Binary Tree
## Description
Invert a binary tree.
```
     4
   /   \
  2     7
 / \   / \
1   3 6   9
```
to
```
     4
   /   \
  7     2
 / \   / \
9   6 3   1
```
## 思路
交换left和right的指针，然后递归左右子树。
## 实现
```c
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    TreeNode* invertTree(TreeNode* root) {
        if(root == NULL) return root;
        helper(root);
        return root;
    }
    
    void helper(TreeNode *node){
        if(node == NULL) return;
        
        TreeNode* tmp = node->left;
        node->left = node->right;
        node->right = tmp;
        
        helper(node->left);
        helper(node->right);
    }
};
```

# Kth Smallest Element in a BST
## Description
Given a binary search tree, write a function kthSmallest to find the kth smallest element in it.

Note:
You may assume k is always valid, 1 ≤ k ≤ BST's total elements.
## 思路
中序遍历
## 实现
```c
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    int retval;
    int kthSmallest(TreeNode* root, int k) {
        if(root == NULL) return 0;
        helper(root, k);
        return retval;
    }
    void helper(TreeNode* node, int &k){
        if(node == NULL) return ;
        helper(node->left, k);
        k--;/*回退*/
        if(k == 0) retval = node->val;
        helper(node->right, k);
    }
    
    /*非递归版*/
    int kthSmallest(TreeNode* root, int k) {
        if(root == NULL) return 0;
        stack<TreeNode *> s;
        TreeNode *cur = root;
        while(cur || !s.empty()){
            while(cur){
                s.push(cur);
                cur = cur->left;
            }
            cur = s.top();
            s.pop();
            k--;
            if(k==0)
                return cur->val;
            cur = cur->right;
        }
    }

};
```
# Validate Binary Search Tree
## Description
Given a binary tree, determine if it is a valid binary search tree (BST).
Assume a BST is defined as follows:
- The left subtree of a node contains only nodes with keys less than the node's key.
- The right subtree of a node contains only nodes with keys greater than the node's key.
- Both the left and right subtrees must also be binary search trees.

Example 1:
```
Input:
    2
   / \
  1   3
Output: true
```
Example 2:
```
    5
   / \
  1   4
     / \
    3   6
Output: false
Explanation: The input is: [5,1,4,null,null,3,6]. The root node's value
             is 5 but its right child's value is 4.
```
## 思路
中序遍历
## 实现
```c
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    TreeNode * pre = NULL;
    bool isValidBST(TreeNode* root) {
        if(root == NULL) return true;
        if(!isValidBST(root->left)) return false; /* 左子树不是*/
        if(pre && pre->val >= root->val)
            return false;
        pre = root;
        return isValidBST(root->right);
    }
    /*非递归版*/
    TreeNode * pre = NULL;
    bool isValidBST(TreeNode* root) {
        if(root == NULL) return true;
        stack<TreeNode *> s;
        TreeNode *cur = root;
        while(cur || !s.empty()){
            while(cur){
                s.push(cur);
                cur = cur->left;
            }
            cur = s.top();
            s.pop();
            if(pre && pre->val >= cur->val)
                return false;
            pre = cur;
            cur = cur->right;
        }
        return true;
    }
};
```
# Sum Root to Leaf Numbers
## Description
Given a binary tree containing digits from 0-9 only, each root-to-leaf path could represent a number.

An example is the root-to-leaf path 1->2->3 which represents the number 123.

Find the total sum of all root-to-leaf numbers.

Note: A leaf is a node with no children.

Example:
```
Input: [1,2,3]
    1
   / \
  2   3
Output: 25
Explanation:
The root-to-leaf path 1->2 represents the number 12.
The root-to-leaf path 1->3 represents the number 13.
Therefore, sum = 12 + 13 = 25.
```
Example 2:
```
Input: [4,9,0,5,1]
    4
   / \
  9   0
 / \
5   1
Output: 1026
Explanation:
The root-to-leaf path 4->9->5 represents the number 495.
The root-to-leaf path 4->9->1 represents the number 491.
The root-to-leaf path 4->0 represents the number 40.
Therefore, sum = 495 + 491 + 40 = 1026.
```
## 思路
先序遍历，root->node的numbers等于root->parent的number*10+node->val，如果node结点为叶节点，则将root->node的numbers加入到最后的返回结果中。
## 实现
```c
class Solution {
public:
    int sumNumbers(TreeNode* root) {
        if(root == NULL) return 0;
        int sum = 0;
        helper(root, 0, sum);
        return sum;
    }
    void helper(TreeNode* node, int parent_path, int &sum){
        if(node == NULL) return ;
        int cur_path =  parent_path*10 + node->val;
        if(!node->left && !node->right)
            sum += cur_path;
        helper(node->left, cur_path, sum);
        helper(node->right, cur_path, sum);
        
        
    }
};
```
# Symmetric Tree
## Description
Given a binary tree, check whether it is a mirror of itself (ie, symmetric around its center).

For example, this binary tree [1,2,2,3,4,4,3] is symmetric:
```
    1
   / \
  2   2
 / \ / \
3  4 4  3
```
But the following [1,2,2,null,3,null,3] is not:
```
    1
   / \
  2   2
   \   \
   3    3
```
## 思路
维护两个指针，分别指向父结点的左右孩子结点：
- 如果两个点都是null，那么它们是相等的。
- 如果一个点是null，另外一个不是null，那么它们不相等，返回false （ base case， 表示一边已经走到底了，需要返回）
- 如果两个点都不是null，但是它们的值不相等， 返回false 
- 如果两个点相等，那么我们需要继续往下走，来判断接下去的点：根据对称的特性，这里需要pass 两个情况返回function：（function 代入的是两个点，左边和右边）
　　　　　　1- 把 左边点的左边，和右边点的右边 返回function；
　　　　　　2- 把 左边点的右边，和右边点的左边 返回funciton。
## 实现
```
class Solution {
public:
    bool isSymmetric(TreeNode* root) {
        if(root == NULL) return true;
        return helper(root->left, root->right);
    }
    
    bool helper(TreeNode* node1, TreeNode* node2){
        if(node1 == NULL && node2 == NULL) return true;
        if(node1 && node2 && (node1->val == node2->val))
            return helper(node1->left, node2->right) && helper(node1->right, node2->left);
        else return false;
    }
};
```
# Lowest Common Ancestor of a Binary Search Tree
## Description
 Given a binary search tree (BST), find the lowest common ancestor (LCA) of two given nodes in the BST.

According to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes v and w as the lowest node in T that has both v and w as descendants (where we allow a node to be a descendant of itself).”
```
        _______6______
       /              \
    ___2__          ___8__
   /      \        /      \
   0      _4       7       9
         /  \
         3   5
```
For example, the lowest common ancestor (LCA) of nodes 2 and 8 is 6. Another example is LCA of nodes 2 and 4 is 2, since a node can be a descendant of itself according to the LCA definition.
## 思路
1. 两个节点均在root的左子树，此时对root->left递归求解；
2. 两个节点均在root的右子树，此时对root->right递归求解；
3. 两个节点分别位于root的左右子树，此时LCA为root。
## 实现
```c
class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        if(root == p || root == q) return root;
        if((root->val < max(p->val, q->val)) && (root->val > min(p->val, q->val)) ) return root;
        
        if(root->val > max(p->val, q->val)) return lowestCommonAncestor(root->left, p, q);
        if(root->val < max(p->val, q->val)) return lowestCommonAncestor(root->right, p, q);
    }
};
```
# Lowest Common Ancestor of a Binary Tree
## Decription
 Given a binary tree, find the lowest common ancestor (LCA) of two given nodes in the tree.

According to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes v and w as the lowest node in T that has both v and w as descendants (where we allow a node to be a descendant of itself).”
```
        _______3______
       /              \
    ___5__          ___1__
   /      \        /      \
   6      _2       0       8
         /  \
         7   4
```
For example, the lowest common ancestor (LCA) of nodes 5 and 1 is 3. Another example is LCA of nodes 5 and 4 is 5, since a node can be a descendant of itself according to the LCA definition.
## 思路
从上往下走，第一种情况是两个节点是在公共祖先的左右两侧，第二种情况是都在树的左侧，第三种情况是都在树的右侧，如果是第二，第三种情况的话，公共祖先就在给定的两个点中比较上面的那一个。
## 实现
```
class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
        if(root == NULL) return NULL;   
        if(root == p || root == q) return root; //如果碰到了pq中的一个直接返回，在判断右子树是否存在p或q，如果不存在，则left就是LCA，如果存在，则LCA就是root。
        TreeNode* left = lowestCommonAncestor(root->left, p, q);
        TreeNode* right = lowestCommonAncestor(root->right, p, q);
        if(left && right) return root;  
        return left != NULL ? left : right;
    }
};
```
上述代码可以进行优化一下，在找完左子树的共同父节点时如果结果存在，且不是p或q，那么不用再找右子树了，直接返回这个结果即可，同理，对找完右子树的结果做同样处理，参见代码如下：
```
class Solution {
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
       if (!root || p == root || q == root) return root;
       TreeNode *left = lowestCommonAncestor(root->left, p, q);
       if (left && left != p && left != q) return left;
       TreeNode *right = lowestCommonAncestor(root->right, p , q);
       if (right && right != p && right != q) return right;
       if (left && right) return root;
       return left ? left : right;
    }
};
```

# Merge Two Binary Trees
## Decription
Given two binary trees and imagine that when you put one of them to cover the other, some nodes of the two trees are overlapped while the others are not.

You need to merge them into a new binary tree. The merge rule is that if two nodes overlap, then sum node values up as the new value of the merged node. Otherwise, the NOT null node will be used as the node of new tree.

Example 1:
```
Input: 
	Tree 1                     Tree 2                  
          1                         2                             
         / \                       / \                            
        3   2                     1   3                        
       /                           \   \                      
      5                             4   7                  
Output: 
Merged tree:
	     3
	    / \
	   4   5
	  / \   \ 
	 5   4   7
```
Note: The merging process must start from the root nodes of both trees.
## 实现
```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    TreeNode* mergeTrees(TreeNode* t1, TreeNode* t2) {
        if(t1 == NULL && t2 == NULL )
            return NULL;
        if(!t1)
            return t2;
        if(!t2)
            return t1;
        TreeNode *rootNode = new TreeNode(t1->val + t2->val);
        rootNode->left = mergeTrees(t1->left, t2->left);
        rootNode->right = mergeTrees(t1->right, t2->right);
        
        return rootNode;
    }
};
```
# Path Sum
## Decription
Given a binary tree and a sum, determine if the tree has a root-to-leaf path such that adding up all the values along the path equals the given sum.

Note: A leaf is a node with no children.

Example:
```
Given the below binary tree and sum = 22,

      5
     / \
    4   8
   /   / \
  11  13  4
 /  \      \
7    2      1

return true, as there exist a root-to-leaf path 5->4->11->2 which sum is 22.
```
## 实现
```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    bool hasPathSum(TreeNode* root, int sum) {
        if(root == NULL)
            return false;
        if(root->left == NULL && root->right == NULL && root->val == sum)
            return true;
        return hasPathSum(root->left, sum-root->val) || hasPathSum(root->right, sum-root->val);
    }
};
```

# Path Sum II
## Decription
Given a binary tree and a sum, find all root-to-leaf paths where each path's sum equals the given sum.

Note: A leaf is a node with no children.

Example:

Given the below binary tree and sum = 22,
```
      5
     / \
    4   8
   /   / \
  11  13  4
 /  \    / \
7    2  5   1
```
Return:
```
[
   [5,4,11,2],
   [5,8,4,5]
]
```
## 实现
```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    vector<vector<int>> pathSum(TreeNode* root, int sum) {
        vector<vector<int>> ret;
        if(root == NULL) {
            return ret;
        }
        
        vector<int> curPath;
        curPath.push_back(root->val);
        helper(root, sum, ret, curPath, root->val);
        return ret;
    }
    
    void helper(TreeNode* root, int sum, vector<vector<int>>& ret, vector<int>& curPath, int curSum) {
        if(root->left == NULL && root->right == NULL && curSum == sum) {
            ret.push_back(curPath);
            return;
        }
        
        if(root->left) {
            curPath.push_back(root->left->val);
            helper(root->left, sum, ret, curPath, curSum + root->left->val);
            curPath.pop_back();
        }
        
        if(root->right) {
            curPath.push_back(root->right->val);
            helper(root->right, sum, ret, curPath, curSum + root->right->val);
            curPath.pop_back();
        }
    
    }
};
```

# Path Sum III
## Decription
You are given a binary tree in which each node contains an integer value.

Find the number of paths that sum to a given value.

The path does not need to start or end at the root or a leaf, but it must go downwards (traveling only from parent nodes to child nodes).

The tree has no more than 1,000 nodes and the values are in the range -1,000,000 to 1,000,000.

Example:
```
root = [10,5,-3,3,2,null,11,3,-2,null,1], sum = 8

      10
     /  \
    5   -3
   / \    \
  3   2   11
 / \   \
3  -2   1

Return 3. The paths that sum to 8 are:

1.  5 -> 3
2.  5 -> 2 -> 1
3. -3 -> 11
```
## 实现
```
class Solution {
public:
    int pathSum(TreeNode* root, int sum) {
        if(root == NULL)
            return 0;
        return hasPathSum(root, sum) + pathSum(root->left, sum) + pathSum(root->right, sum); 
    }
    
    int hasPathSum(TreeNode* root, int sum) {
        if(root == NULL)
            return 0;
        // root->val == sum :单节点等于sum也计入结果
        return (root->val == sum) + hasPathSum(root->left, sum - root->val) + hasPathSum(root->right, sum - root->val);
    }
};
```

# Find Largest Value in Each Tree Row
## Decription
You need to find the largest value in each row of a binary tree.

Example:
```
Input: 

          1
         / \
        3   2
       / \   \  
      5   3   9 

Output: [1, 3, 9]
```
## 实现
```
/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode(int x) : val(x), left(NULL), right(NULL) {}
 * };
 */
class Solution {
public:
    vector<int> largestValues(TreeNode* root) {
        vector<int> ret;
        if(root == NULL) {
            return ret;
        }
        queue<TreeNode*> q;
        q.push(root);
        TreeNode* last = root;
        int max = INT_MIN;
        while(!q.empty()) {
            TreeNode* node = q.front();
            q.pop();
            
            if(max < node->val) {
                max = node->val;
            }
            
            if(node->left) {
                q.push(node->left);
            }
            if(node->right) {
                q.push(node->right);
            }
            
            if(node == last) {
                last = q.back();
                ret.push_back(max);
                max = INT_MIN;
            }
        }
        
        return ret;
    }
};
```