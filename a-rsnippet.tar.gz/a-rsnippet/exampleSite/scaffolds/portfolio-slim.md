---
layout: portfolio-slim
title: {{ title }}
categories:
tag:
date: {{ date }}
subtitle: "Personal Projects"
project:
-
	"title": "Awesome Checklist Checklist"
	"subtitle": "A Curated List of Checklists"
	"date": "2017.12"
	"img_link": Awesome-Checklist-Checklist.png
	"project_link": http://checklist.yingjiehu.com/
	"button-text": "View"
	"use":
		- BootStrap
		- JavaScript
		- jQuery
		- Gulp
	"description": "Checklists included can span every field of life, such as programming, traveling, games. Over 1700 stars on GitHub. The website is automatically updated when I update README.md."
-
	"title": ""
	"subtitle": ""
	"date": ""
	"img_link": 
	"project_link":
	"button-text": ""
	"use":
		- 
		- 
		- 
	"description": ""
---