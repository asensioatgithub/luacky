---
layout: leetcode
number: 
title: {{ title }}
leetcodeURL: ""
date: {{ date }}
draft: false
field: "algorithm"
difficulty: "medium"
time: ""
space: ""
isfree: true
categories: 
- ["language", "python"]
- ["field", "algorithm"]
tags: ["leetcode"]
permalink: 
cover_img: 
toc-disable:
comments:
---